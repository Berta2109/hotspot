package br.com.sabesp.sabesphotsitesolicitacoes.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.ResourceBundle;

import javax.ejb.EJB;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.context.FacesContext;
import javax.faces.event.ComponentSystemEvent;
import javax.faces.event.PhaseId;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.myfaces.extensions.cdi.core.api.scope.conversation.ViewAccessScoped;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import br.com.sabesp.sabesphotsitesolicitacoes.business.ConfiguracaoBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.EmailBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.IntegracaoWsBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.RgiBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.SolicitacaoBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.VulneravelBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Assunto;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.AtendimentoComercial;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Atestado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Beneficio;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.CadastroUnidadeConsumo;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Comentario;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosBancarios;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosCadastro;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosLeitura;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DoacaoContaAgua;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.FaleConosco;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Fornecimento;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.PesquisaSatisfacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SolicitacaoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TarifaSocialDesempregado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TarifaSocialUnifamiliar;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoAtestado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoBeneficio;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoHabitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoOng;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoSupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Feedback;
import br.com.sabesp.sabesphotsitesolicitacoes.util.SabespSession;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatFile;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
import br.com.sabesp.sabesphotsitesolicitacoes.util.ValidacaoException;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Anexo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.ChecagemAvisosDocumentacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.ServicoSolicitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Solicitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoDesassociacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoDoacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoFaleConosco;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoUnidadeConsumo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Solicitante;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Termo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.TipoAnexo;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

@Named
@ViewAccessScoped
public class EntradaController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 178663007895695947L;

	public static final String PF = "PF";
	public static final String PJ = "PJ";
	public static final String FORNECIMENTO = "1";

	@EJB
	private RgiBusiness rgiBusiness;

	@EJB
	private ConfiguracaoBusiness configuracao;

	@EJB
	private SolicitacaoBusiness business;

	@EJB
	private IntegracaoWsBusiness wsBusiness;
	
	@EJB
	private VulneravelBusiness vulneravelBusiness;

	@EJB
	private EmailBusiness emailBusiness;

	@Inject
	private SabespSession session;

	private Boolean informaCompetencia;
	private Boolean doacaoAcordado = false;
	private Boolean deAcordoDesassociacao = false;
	private Boolean elegivel = false;
	private Boolean nelegivel = false;
	private boolean tipoPessoaDesassociacaoSelecionado;
	private boolean tipoResponsavelContaSelecionado;
	private Solicitacao filtro;
	private Solicitacao edicao;
	private SolicitacaoDoacao edicaoDoacao;
	private SolicitacaoFaleConosco edicaoFaleConosco;
	private SolicitacaoDesassociacao edicaoDesassociacao;
	private Collection<Integer> anos;
	private Collection<Anexo> edicaoAnexos;
	private Collection<Anexo> edicaoAnexosDesassociacao;
	private Collection<TipoAtestado> tiposAtestado;
	private Collection<TipoBeneficio> tiposBeneficio;
	private Collection<TipoSupressaoReligacao> tiposSupressao;
	private ServicoSolicitacao[] servicoSolicitacao;
	private Collection<TipoHabitacao> tiposHabitacao;

	private Collection<TipoOng> entidadesOng;
	private Collection<Integer> valoresPossiveisDoacao;

	private Integer notaFeedback;
	private Boolean habilitaFeedback;
	private String comentarioFeedback;

	private Boolean liberaOk;

	private Integer tipoSolicitante;

	private String mensagemTelaSolicitacao = "";
	private String mensagemTelaSolicitacao2 = "";

	private SolicitacaoUnidadeConsumo edicaoUnidadeConsumo;

	private boolean exibeAlternativasSituacao;

	private String situacao;
	private Termo termo;

	private String descricaoNomeSupressao;
	private String descricaoDocumentoSupressao;
	private Boolean check1Supressao;
	private Boolean check2Supressao;

	private Boolean check1Ts;
	private Boolean check2Ts;
	private Boolean check3Ts;
	private Boolean check4Ts;
	private Boolean check5Ts;

	private String informacoesAdicionaisRestituicao;
	private String descricaoNomeAlteraResp;
	private String termoResponsAlteraResp;
	private Boolean dataNascimentoStr;
	private StreamedContent file;
	private Boolean exibeRepresentanteSupressao;

	private String fornecimentoPde;
	
	public String index(boolean fluxo) {
		if (fluxo) {
			salvarPesquisa();
		}

		filtro = null;
		edicao = null;
		edicaoDoacao = null;
		edicaoDesassociacao = null;
		edicaoAnexos = null;
		edicaoFaleConosco = null;
		edicaoAnexosDesassociacao = null;
		edicaoUnidadeConsumo = null;

		return "entrada";
	}

	/**
	 * M�todo respons�vel por salvar a pesquisa de satisfa��o
	 */
	private void salvarPesquisa() {
		try {
			PesquisaSatisfacao pesquisaSatisfacao = new PesquisaSatisfacao();

			pesquisaSatisfacao.setSolicitacao(business.obterSolicitacao(edicao.getProtocolo()));
			if (getNotaFeedback().equals(11)) {
				setNotaFeedback(0);
			}
			pesquisaSatisfacao.setNotaPesquisa(getNotaFeedback());
			pesquisaSatisfacao.setJustificativaPesquisa(getComentarioFeedback());

			business.salvarPesquisaSatisfacao(pesquisaSatisfacao);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}

	/**
	 * link documentacao do capctha https://www.google.com/recaptcha/admin
	 * <p>
	 * <p>
	 * Metodo responsavel por validar o RGI informado
	 *
	 * @return
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 7 de abr de 2020 (Projeto)
	 */
	public String validarRGI() {
		edicao = null;
		edicaoDoacao = null;
		edicaoFaleConosco = null;
		edicaoDesassociacao = null;
		edicaoUnidadeConsumo = null;

		try {
			
			if(getFiltro().getDados().getNumero().equals(null) || getFiltro().getDados().getNumero().equals("")) {
				
				if(getFornecimentoPde().equals(FORNECIMENTO)) {
					Feedback.jsfWarning("mensagem.validacao.fornecimento");
					return null;
					
				} else {
					Feedback.jsfWarning("mensagem.validacao.pde");
					return null;
				}
				
			}
			
			if(getFornecimentoPde().equals(FORNECIMENTO)) {
				Fornecimento fornecimento = buscarDadosFornecimento(getFiltro().getDados().getNumero());
				
				if(fornecimento != null && fornecimento.getPde() == null ) {
					PrimeFaces.current().ajax().addCallbackParam("naoEncontrado", true);
					return null;
				} else {
					
					getFiltro().getDados().setNumero(fornecimento.getPde());
					getEdicao().setFornecimento(fornecimento.getFornecimento());
					
				}
			}
			
			DadosRGI rgi = rgiBusiness.consultar(session.getAutenticacaoWs(), getFiltro().getDados().getNumero());
			if (rgi == null) {
				PrimeFaces.current().ajax().addCallbackParam("naoEncontrado", true);
				return null;
			}
			AtendimentoComercial unidade = business.definirAtendimentoComercial(rgi);
			if (unidade == null) {
				PrimeFaces.current().ajax().addCallbackParam("naoEncontrado", true);
				return null;
			}
			getEdicao().setDados(rgi);
			return "servicos";
		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
		return null;
	}
	
	private Fornecimento buscarDadosFornecimento(String numero) {

		try {
			
			return rgiBusiness.buscarDadosFornecimento(numero);
			
		} catch (Exception e) {
		}
	
		return null;
		
	}

	public String irParaPrimeiraLigacao() {
		return "/pages/publico/index_primeira_lig";
	}

	/**
	 * Acoes para atendimento dos servicos
	 *
	 * @return
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 9 de abr de 2020 (Projeto)
	 */
	public String restituicaoValoresPagosDuplicidade() {
		return prepararEdicaoTipoServico(TipoServico.RESTITUICAO_VALORES_PAGOS_DUPLICIDADE);
	}

	/**
	 * Metodo responsavel por tratar quando o servico foi selecionado pelo usuario
	 *
	 * @param tipo
	 * @return
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 14 de abr de 2020 (Projeto)
	 */
	public String escolherServico(TipoServico tipo) {
		return prepararEdicaoTipoServico(tipo);
	}

	/**
	 * FIM SERVICOS mapeamento
	 */

	/**
	 * Metodo responsavel por tratar quando o tipo do solicitante trocado
	 *
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 9 de abr de 2020 (Projeto)
	 */
	public void tipoSolicitanteTrocado() {

		edicaoAnexos = configuracao
				.listarDocumentosTransferenciaTitularidadeDebitos(getEdicao().getSolicitante().getTipo());
		termo = new Termo();
		getEdicao().getSolicitante().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setDocumentoRepresentateLegal(new Anexo(TipoAnexo.PROCURACAOCOMFIRMARECONHECIDA, true));
	}

	public void tipoSolicitanteUnidadeConsumoTrocado() {
		edicaoAnexos = configuracao.listarDocumentosUnidadeConsumo(getEdicao().getSolicitante().getTipo());
		getEdicao().getSolicitante().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
	}

	public void tipoSolicitanteAtualizarDadosCadastrais() {
		edicaoAnexos = configuracao.listarDocumentosAtualizarDadosCadastrais(getEdicao().getSolicitante().getTipo(),
				getTipoSolicitante());
		getEdicao().getSolicitante().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
	}

	public void tipoAtestadoTrocado() {
		informaCompetencia = !(getEdicao().getAtestado().getTipo() == null
				|| getEdicao().getAtestado().getTipo().getId() != 6);
		getEdicao().getAtestado().setAno(null);
	}

	/**
	 * Metodo responsavel por tratar quando se solicitante eh o representante legal
	 * ou nao
	 *
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 9 de abr de 2020 (Projeto)
	 */
	public void tipoRepresentanteTrocado() {
		if (getEdicao().getSolicitante().getRepresentanteLegal()) {
			return;
		}
		limparAnexo(getEdicao().getSolicitante().getDocumentoRepresentateLegal());
	}

	public void tipoRepresentanteDesassociacaoTrocado() {
		if (getEdicaoDesassociacao().getRepresentateLegal()) {
			return;
		}
		limparAnexo(getEdicaoDesassociacao().getDocumentoRepresentateLegal());
	}

	public void tipoRepresentanteTrocadoUnidade() {
		if (getEdicaoUnidadeConsumo().getRepresentanteLegal()) {

			getEdicaoUnidadeConsumo().setDocumentoRepresentanteLegal(configuracao.procuracaoComFirmaReconhecida());
			return;
		}
		limparAnexo(getEdicaoUnidadeConsumo().getDocumentoRepresentanteLegal());
	}

	public void tipoEntidadePublicaTrocado() {
		if (getEdicaoUnidadeConsumo().getEntidadePublica()) {
			return;
		}
		limparAnexo(getEdicaoUnidadeConsumo().getDocumentoEntidadePublica());
	}

	public void estatalFederalTrocado() {
		if (getEdicaoDesassociacao().getEstatalFederal()) {
			return;
		}
		limparAnexo(getEdicaoDesassociacao().getDocumentoEstatalFederal());
	}

	public void tipoCadastroCategoriaTrocado() {
		if (getEdicaoUnidadeConsumo().getCadastroCategoria() != null
				&& "E".equals(getEdicaoUnidadeConsumo().getCadastroCategoria())) {
			getEdicaoUnidadeConsumo().setEntidadePublica(true);
			return;
		}
		getEdicaoUnidadeConsumo().setEntidadePublica(false);
		limparAnexo(getEdicaoUnidadeConsumo().getDocumentoEntidadePublica());
	}

	public void tipoHabitacaoTrocado() {
		if (getEdicao().getSolicitante().getTipoHabitacao() != null) {
			getEdicao().getSolicitante().setDocumentoTipoHabitacao(
					configuracao.documentoTipoHabitacao(getEdicao().getSolicitante().getTipoHabitacao().getId()));
			return;
		}
		limparAnexo(getEdicao().getSolicitante().getDocumentoTipoHabitacao());
	}

	public void tipoSupressaoTrocado() {
		//supresao a pedido demolido 2 e unificado 3 anexos 
		//TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_1
		//RGCPFOUCNHOPCIONAL
		//representante legal
		
		Collection<Anexo> anexos = new ArrayList<Anexo>();
 		if (getEdicao().getSupressao().getTipo()!= null && (getEdicao().getSupressao().getTipo().getId().equals(2) || getEdicao().getSupressao().getTipo().getId().equals(3))) {
			anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_1, false));
			anexos.add(new Anexo(TipoAnexo.RGCPFOUCNHOPCIONAL, false));
			exibeRepresentanteSupressao = true;
			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
		} else {
			exibeRepresentanteSupressao = false;
			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, true));
		}
		
		edicaoAnexos = anexos;

		if (getEdicao().getSupressao().getTipo().getId().equals(1)
				|| getEdicao().getSupressao().getTipo().getId().equals(4)) {
			setDescricaoNomeSupressao("A");
			setDescricaoDocumentoSupressao("A");
		} else if (getEdicao().getSupressao().getTipo().getId().equals(2)
				|| getEdicao().getSupressao().getTipo().getId().equals(3)) {
			setDescricaoNomeSupressao("C");
			setDescricaoDocumentoSupressao("C");
		}
	}

	public void tipoPessoaDesassociacaoTrocado() {
		if (getEdicaoDesassociacao().getPFouPJ().equals("1")) {
			setDescricaoNomeSupressao("A");
			setDescricaoDocumentoSupressao("A");
			setTipoPessoaDesassociacaoSelecionado(true);
			edicaoAnexosDesassociacao = configuracao
					.listarDocumentosDesassociacao(getEdicaoDesassociacao().getPFouPJ());
		} else {
			setDescricaoNomeSupressao("B");
			setDescricaoDocumentoSupressao("B");
			setTipoPessoaDesassociacaoSelecionado(true);
			edicaoAnexosDesassociacao = configuracao
					.listarDocumentosDesassociacao(getEdicaoDesassociacao().getPFouPJ());
		}
	}

	public void tipoResponsavelContaTrocado() {
		if (getEdicao().getResponsavelConta().equals("1")) {
			setDescricaoNomeAlteraResp("Nome");
			setDescricaoNomeSupressao("A");
			setDescricaoDocumentoSupressao("A");
			setTipoResponsavelContaSelecionado(true);
			setDataNascimentoStr(true);
			setTermoResponsAlteraResp(
					"Declaro ser inquilino de todas as unidades consumidoras localizadas neste endere�o e abastecidas por este PDE, sendo, portanto, "
							+ "respons�vel pelo pagamento das contas de consumo da liga��o de �gua e/ou esgoto que as abastece. Estou ciente de que, "
							+ "caso deixe de ser respons�vel pelo pagamento das contas do im�vel, ser� necess�rio entrar em contato com a Sabesp "
							+ "para solicitar o encerramento da rela��o contratual, sob pena de se manter respons�vel pelos d�bitos caso n�o avise.");

			Collection<Anexo> anexos = new ArrayList<Anexo>();

			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_2, Boolean.TRUE));

			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());

			edicaoAnexos = anexos;

		} else if (getEdicao().getResponsavelConta().equals("2")) {
			setDescricaoNomeAlteraResp("Nome da Empresa");
			setDescricaoNomeSupressao("B");
			setDescricaoDocumentoSupressao("B");
			setTipoResponsavelContaSelecionado(true);
			setDataNascimentoStr(false);
			setTermoResponsAlteraResp(
					"Declaro que a empresa acima qualificada � a atual inquilina de todas as unidades consumidoras localizadas "
							+ "neste endere�o e abastecidas por este PDE, sendo, portanto, respons�vel pelo pagamento das contas de consumo da liga��o de "
							+ "�gua e/ou esgoto que as abastece. Estou ciente de que, caso a empresa deixe de ser respons�vel pelo pagamento das contas do im�vel, "
							+ "ser� necess�rio entrar em contato com a Sabesp para solicitar o encerramento da rela��o contratual, sob pena de se manter respons�vel "
							+ "pelos d�bitos caso n�o avise.");

			Collection<Anexo> anexos = new ArrayList<Anexo>();

			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNHSOCIO, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.CARTAOCNPJ, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.CONTRATOSOCIAL, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUALSEHOUVER, Boolean.FALSE));
			anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_2, Boolean.TRUE));

			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());

			edicaoAnexos = anexos;

		} else if (getEdicao().getResponsavelConta().equals("3")) {
			setDescricaoNomeAlteraResp("Nome");
			setDescricaoNomeSupressao("A");
			setDescricaoDocumentoSupressao("A");
			setTipoResponsavelContaSelecionado(true);
			setDataNascimentoStr(true);
			setTermoResponsAlteraResp(
					"Declaro ser propriet�rio de todas as unidades consumidoras localizadas neste endere�o e abastecidas por este PDE, sendo, "
							+ "portanto, respons�vel pelo pagamento das contas de consumo da liga��o de �gua e/ou esgoto que as abastece. Estou ciente de que, caso deixe "
							+ "de ser respons�vel pelo pagamento das contas do im�vel, ser� necess�rio entrar em contato com a Sabesp para solicitar o encerramento da "
							+ "rela��o contratual, sob pena de se manter respons�vel pelos d�bitos caso n�o avise.");

			Collection<Anexo> anexos = new ArrayList<Anexo>();

			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_IPTU_CONTRATO, Boolean.TRUE));

			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());

			edicaoAnexos = anexos;

		} else if (getEdicao().getResponsavelConta().equals("4")) {
			setDescricaoNomeAlteraResp("Nome da Empresa");
			setDescricaoNomeSupressao("B");
			setDescricaoDocumentoSupressao("B");
			setTipoResponsavelContaSelecionado(true);
			setDataNascimentoStr(false);
			setTermoResponsAlteraResp(
					"Declaro que a empresa acima qualificada � propriet�ria de todas as unidades consumidoras localizadas neste endere�o e "
							+ "abastecidas por este PDE, sendo, portanto, respons�vel pelo pagamento das contas de consumo da liga��o de �gua e/ou esgoto que as abastece. "
							+ "Estou ciente de que, caso a empresa deixe de ser respons�vel pelo pagamento das contas do im�vel, ser� necess�rio entrar em contato com a "
							+ "Sabesp para solicitar o encerramento da rela��o contratual, sob pena de se manter respons�vel pelos d�bitos caso n�o avise.");

			Collection<Anexo> anexos = new ArrayList<Anexo>();

			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNHSOCIO, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.CARTAOCNPJ, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.CONTRATOSOCIAL, Boolean.TRUE));
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUALSEHOUVER, Boolean.FALSE));
			anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_IPTU_CONTRATO, Boolean.TRUE));

			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());

			edicaoAnexos = anexos;
		}
	}

	public void tipoServicoSolicitacaoTrocado() {
		edicaoAnexos = configuracao.adicionarAnexosServicoSolicitacao(getEdicao().getServicoSolicitacao());
	}

	/**
	 * Metodo responsavel por efetuar o upload do arquivo selecionado pelo usuario
	 *
	 * @param event
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 8 de abr de 2020 (Projeto)
	 */
	public void uploadArquivoSolicitacao(FileUploadEvent event) {
		if (!PhaseId.INVOKE_APPLICATION.equals(event.getPhaseId())) {
			event.setPhaseId(PhaseId.INVOKE_APPLICATION);
			event.queue();
			return;
		}
		Anexo anexo = (Anexo) event.getComponent().getAttributes().get("anexo");
		if (anexo == null) {
			return;
		}
		try {
			byte[] data = event.getFile().getContents();
			File caminho = TreatFile.saveTempFile("sabesp_as", data);
			anexo.setNomeUnico(TreatString
					.convertStringToUrl(event.getComponent().getAttributes().get("labelAnexo").toString(), "-"));
			anexo.setNome(event.getFile().getFileName());
			anexo.setCaminhoTemporario(caminho.getAbsolutePath());

		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}

	/**
	 * Metodo responsavel por excluir anexo
	 *
	 * @param anexo
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 8 de abr de 2020 (Projeto)
	 */
	public void limparAnexo(Anexo anexo) {
		if (anexo != null) {
			TreatFile.deleteFile(anexo.getCaminhoTemporario());
			anexo.setNome(null);
			anexo.setCaminhoTemporario(null);

			if (anexo.getTipo().equals(TipoAnexo.ESCRITURAESPECIFICACAO)) {
				setExibeAlternativasSituacao(true);
			}
		}
	}

	/**
	 * Metodo responsavel por tratar acao de enviar a solicitacao
	 *
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 12 de abr de 2020 (Projeto)
	 */
	public void salvarSolicitacao() {
		try {
			if (validarSolicitacaoServico()) {
				business.validarPreenchimento(getEdicao(), getEdicaoAnexos());
				getEdicao().setIp(Feedback.getIP());
				SolicitacaoServico solicitacaoSalva = business.salvarSolicitacao(getEdicao(), getEdicaoAnexos());
				getEdicao().setProtocolo(solicitacaoSalva.getProtocolo());
				solicitacaoSalva.setNrFornecimento(getEdicao().getFornecimento());
				AtendimentoComercial atendimentoComercial = business
						.definirAtendimentoComercial(getEdicao().getDados());
				if (getEdicao().getTipoServico().getTransferenciaDebitos() && termo != null) {
					termo.setTipo(getEdicao().getSolicitante().getTipo());
				}
				emailBusiness.enviarEmailCadastroSolicitacao(Feedback.getI18nResourceBundle(), atendimentoComercial,
						solicitacaoSalva, termo);
			} else {
				Feedback.jsfError18n("msg.carencia");
			}
		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}
	
	public void salvarSolicitacaoVulneravel() {
		try {
			if(getEdicao().getFornecimento() != null && !getEdicao().getFornecimento().trim().equals("")) {
				if(validarCpfElegivel()) {
					salvarSolicitacao();
				}
			}
		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}

	public void validarNrFornecimento() {
		if(vulneravelBusiness.validarFornecimento(getEdicao().getDados().getNumero(), getEdicao().getFornecimento())){
			getEdicao().setFornecimento(null);
			Feedback.jsfWarning("msg.fornecimento");
			return;
		} 
	}

	private Boolean validarCpfElegivel() {
		try {
			if(vulneravelBusiness.verificarCpfVulneravel(TreatString.filterOnlyNumber(getEdicao().getSolicitante().getCpfCnpj()))){
				elegivel = Boolean.TRUE;
				nelegivel = Boolean.FALSE;
				return Boolean.TRUE;
			} else {
				elegivel = Boolean.FALSE;
				nelegivel = Boolean.TRUE;
				return Boolean.FALSE;
			}
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
			e.printStackTrace();
		}
		return Boolean.FALSE;
	}

	public void salvarSolicitacaoDesassociacao() {
		try {
			if (deAcordoDesassociacao) {
				if (validarSolicitacaoServico()) {

					if (getEdicao().getTipoServico().equals(TipoServico.DESASSOCIACAO_TITUL_PJ_E_PF)) {

						for (Anexo anexo : getEdicaoAnexosDesassociacao()) {
							if (anexo.getObrigatorio() && !anexo.getIsInformado()) {
								Feedback.jsfError18n("msg.anexo.obrigatorio");
								return;
							}
						}

					}

					business.validarPreenchimento(getEdicao(), getEdicaoAnexos());

					getEdicao().setIp(Feedback.getIP());
					SolicitacaoServico solicitacaoSalva = business.salvarDesassociacao(getEdicaoDesassociacao(),
							getEdicao(), getEdicaoAnexosDesassociacao());

					getEdicao().setProtocolo(solicitacaoSalva.getProtocolo());

					AtendimentoComercial atendimentoComercial = business
							.definirAtendimentoComercial(getEdicao().getDados());

					emailBusiness.enviarEmailCadastroSolicitacao(Feedback.getI18nResourceBundle(), atendimentoComercial,
							solicitacaoSalva, null);
				} else {
					Feedback.jsfError18n("msg.carencia");
				}
			} else {
				Feedback.jsfError18n("msg.deacordo.desassociacao");
			}

		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}

	public void salvarSolicitacaoDoacao() {
		try {
			if (doacaoAcordado) {
				salvarSolicitacaoDoacaoContaAgua();
			} else {
				Feedback.jsfError18n("msg.termo.naoconcordado");
			}
		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}

	private void salvarSolicitacaoDoacaoContaAgua() {
//        if (cpfCnpjIgualVinculadoRgi()) {
		edicaoDoacao.setDados(edicao.getDados());

		DoacaoContaAgua doacaoAguaSalva = business.salvarSolicitacaoDoacaoAgua(edicaoDoacao);

		edicaoDoacao.setProtocolo(doacaoAguaSalva.getProtocolo());
//        } else {
//            throw new ValidacaoException("msg.cpfCnpj.rgi.naocorrespondente");
//        }
	}

	public void salvarSolicitacaoFaleConosco() {
		edicaoFaleConosco.setDados(edicao.getDados());

		FaleConosco faleConosco = business.salvarSolicitacaoFaleConosco(edicaoFaleConosco);

		edicaoFaleConosco.setProtocolo(faleConosco.getProtocolo());

		emailBusiness.enviarEmailFaleConosco(Feedback.getI18nResourceBundle(), faleConosco);
	}

	public void salvarSolicitacaoUnidadeConsumo() {
		try {

			if (!validarSolicitacaoServicoUnidCons()) {
				Feedback.jsfError18n("msg.carencia");
				return;
			}

			if (edicaoUnidadeConsumo.getTipoUnidade().equals("A") && !edicaoUnidadeConsumo.getDeclaroVeracidade()) {
				Feedback.jsfError18n("msg.termo.cadastrounicon");
			} else {

				for (Anexo anexo : getEdicaoAnexos()) {
					if (anexo.getTipo().equals(TipoAnexo.ESCRITURAESPECIFICACAO)) {
						anexo.setObrigatorio(getSituacao().equals("situacao1"));
					}
				}

				business.validarPreenchimento(edicaoUnidadeConsumo, getEdicaoAnexos());
				getEdicao().setIp(Feedback.getIP());
				SolicitacaoServico solicitacaoSalva = business.salvarUnidadeConsumo(edicaoUnidadeConsumo, getEdicao(),
						getEdicaoAnexos());
				getEdicao().setProtocolo(solicitacaoSalva.getProtocolo());

				AtendimentoComercial atendimentoComercial = business
						.definirAtendimentoComercial(getEdicao().getDados());

				emailBusiness.enviarEmailCadastroSolicitacao(Feedback.getI18nResourceBundle(), atendimentoComercial,
						solicitacaoSalva, null);
			}
		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}

	public void informarSituacao() {
		setSituacao(edicaoUnidadeConsumo != null ? edicaoUnidadeConsumo.getSituacao() : null);
	}

	/*
	 * private boolean cpfCnpjIgualVinculadoRgi() { if (edicaoDoacao.getCpfCnpj() ==
	 * null) { return false; } else { String cpfCnpj =
	 * TreatString.removeSpecialChar(edicaoDoacao.getCpfCnpj());
	 * 
	 * if (getEdicao().getDados() == null ||
	 * getEdicao().getDados().getCpfCnpjVinculado() == null) {
	 * 
	 * return false; } else { long numeroCpfCnpj = Long.valueOf(cpfCnpj); long
	 * numeroCpfCnpjOrigemServico =
	 * Long.valueOf(getEdicao().getDados().getCpfCnpjVinculado());
	 * 
	 * return numeroCpfCnpj == numeroCpfCnpjOrigemServico; } } }
	 */
	/**
	 * Metodo responsavel por tratar restricao fluxo telas caso o RGI n tenha sido
	 * validado
	 *
	 * @param e
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @since 8 de abr de 2020 (Projeto)
	 */
	public void isRgiNaoInformado(ComponentSystemEvent e) {
		if (!getEdicao().getDados().isNaoValidado()) {
			FacesContext fc = FacesContext.getCurrentInstance();
			ConfigurableNavigationHandler nav = (ConfigurableNavigationHandler) fc.getApplication()
					.getNavigationHandler();
			nav.performNavigation("entrada");
		}
	}

	public void setEdicaoDoacao(SolicitacaoDoacao edicaoDoacao) {
		this.edicaoDoacao = edicaoDoacao;
	}

	public SolicitacaoDoacao getEdicaoDoacao() {
		if (edicaoDoacao == null) {
			edicaoDoacao = new SolicitacaoDoacao();
		}

		return edicaoDoacao;
	}

	public SolicitacaoDesassociacao getEdicaoDesassociacao() {
		if (edicaoDesassociacao == null) {
			edicaoDesassociacao = new SolicitacaoDesassociacao();
		}
		return edicaoDesassociacao;
	}

	public void setEdicaoDesassociacao(SolicitacaoDesassociacao edicaoDesassociacao) {
		this.edicaoDesassociacao = edicaoDesassociacao;
	}

	public Solicitacao getEdicao() {
		if (edicao == null) {
			edicao = new Solicitacao();
		}

		if (edicao.getSolicitante() == null) {
			edicao.setSolicitante(new Solicitante());
		}
		if (edicao.getDados() == null) {
			edicao.setDados(new DadosRGI());
		}
		if (edicao.getSolicitante().getDadosBancarios() == null) {
			edicao.getSolicitante().setDadosBancarios(new DadosBancarios());
		}
		if (edicao.getDadosLeitura() == null) {
			edicao.setDadosLeitura(new DadosLeitura());
		}
		if (edicao.getAtestado() == null) {
			edicao.setAtestado(new Atestado());
		}
		if (edicao.getBeneficio() == null) {
			edicao.setBeneficio(new Beneficio());
		}
		if (edicao.getSupressao() == null) {
			edicao.setSupressao(new SupressaoReligacao());
		}
		if (edicao.getCadastroUnidadeConsumo() == null) {
			edicao.setCadastroUnidadeConsumo(new CadastroUnidadeConsumo());
		}

		if (edicao.getSolicitante().getDadosCadastro() == null) {
			edicao.getSolicitante().setDadosCadastro(new DadosCadastro());
		}

		if (edicao.getTarifaSocialUnifamiliar() == null) {
			edicao.setTarifaSocialUnifamiliar(new TarifaSocialUnifamiliar());
		}

		if (edicao.getTarifaSocialDesempregado() == null) {
			edicao.setTarifaSocialDesempregado(new TarifaSocialDesempregado());
		}

		if (edicao.getChecagemAvisosDocumentacao() == null) {
			edicao.setChecagemAvisosDocumentacao(new ChecagemAvisosDocumentacao());
		}

		return edicao;
	}

	public void setEdicao(Solicitacao edicao) {
		this.edicao = edicao;
	}

	public Collection<Anexo> getEdicaoAnexos() {
		if (edicaoAnexos == null) {
			edicaoAnexos = new ArrayList<Anexo>();
		}
		return edicaoAnexos;
	}

	public void setEdicaoAnexos(Collection<Anexo> edicaoAnexos) {
		this.edicaoAnexos = edicaoAnexos;
	}

	public Collection<Anexo> getEdicaoAnexosDesassociacao() {
		if (edicaoAnexosDesassociacao == null) {
			edicaoAnexosDesassociacao = new ArrayList<Anexo>();
		}
		return edicaoAnexosDesassociacao;
	}

	public void setEdicaoAnexosDesassociacao(Collection<Anexo> edicaoAnexosDesassociacao) {
		this.edicaoAnexosDesassociacao = edicaoAnexosDesassociacao;
	}

	public Solicitacao getFiltro() {
		if (filtro == null) {
			filtro = new Solicitacao();
		}
		if (filtro.getDados() == null) {
			filtro.setDados(new DadosRGI());
		}
		return filtro;
	}

	public void setFiltro(Solicitacao filtro) {
		this.filtro = filtro;
	}

	public Collection<Integer> getAnos() {
		this.anos = new ArrayList<Integer>();
		int ano = Calendar.getInstance().get(Calendar.YEAR) - 1;
		for (int i = ano; i > ano - 4; i--) {
			this.anos.add(i);
		}
		return this.anos;
	}

	public Collection<TipoAtestado> getTiposAtestado() {
		if (tiposAtestado == null) {
			tiposAtestado = new ArrayList<TipoAtestado>(0);
		}
		return tiposAtestado;
	}

	public void setTiposAtestado(Collection<TipoAtestado> tiposAtestado) {
		this.tiposAtestado = tiposAtestado;
	}

	public Collection<TipoBeneficio> getTiposBeneficio() {
		if (tiposBeneficio == null) {
			tiposBeneficio = new ArrayList<TipoBeneficio>(0);
		}
		return tiposBeneficio;
	}

	public void setTiposBeneficio(Collection<TipoBeneficio> tiposBeneficio) {
		this.tiposBeneficio = tiposBeneficio;
	}

	public Collection<TipoSupressaoReligacao> getTiposSupressao() {
		if (tiposSupressao == null) {
			tiposSupressao = new ArrayList<TipoSupressaoReligacao>(0);
		}
		return tiposSupressao;
	}

	public void setTiposSupressao(Collection<TipoSupressaoReligacao> tiposSupressao) {
		this.tiposSupressao = tiposSupressao;
	}

	public ServicoSolicitacao[] getServicoSolicitacao() {
		servicoSolicitacao = ServicoSolicitacao.values();
		return servicoSolicitacao;
	}

	public void setServicoSolicitacao(ServicoSolicitacao[] servicoSolicitacao) {
		this.servicoSolicitacao = servicoSolicitacao;
	}

	private String prepararEdicaoTipoServico(TipoServico tipo) {

		getEdicao().setSolicitante(null);
		getEdicao().setTipoServico(tipo);

		edicaoAnexos = null;
		tiposAtestado = null;
		tiposBeneficio = null;
		tiposSupressao = null;
		tiposHabitacao = null;
		entidadesOng = null;
		exibeAlternativasSituacao = false;
		exibeRepresentanteSupressao = false;

		comentarioFeedback = null;
		habilitaFeedback = null;
		notaFeedback = null;
		liberaOk = null;
		mensagemTelaSolicitacao = "";
		mensagemTelaSolicitacao2 = "";
		if (tipo.getNecessarioDocumentacao() && !tipo.getUsaAnexosCondicionais()) {
			edicaoAnexos = configuracao.listarDocumentosServico(tipo);
		}

//		if (tipo.equals(TipoServico.ATUALIZAR_DADOS_CADASTRAIS)) {
//			setCheck1Supressao(false);
//			configurarFluxoAtualizaDados(false, false, false);
//		}

		if (tipo.getUsaTiposAtestado()) {
			edicaoAnexos = configuracao.listarDocumentosServico(tipo);
			tiposAtestado = configuracao.listarTiposAtestado();
			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
		}

		if (tipo.getUsaTiposBeneficio()) {
			tiposBeneficio = configuracao.listarTiposBeneficio();
		}

		if (tipo.getUsaTiposHabitacao()) {
			return configurarFluxoUnidadeConsumo(tipo, false, false, false, false);
		}

		if (tipo.getUsaTiposSupressao()) {
			exibeRepresentanteSupressao = Boolean.FALSE;
			tiposSupressao = configuracao.listarTiposSupressao();
		}

		if (tipo.getUsaServicosSolicitacao()) {
			mensagemTelaSolicitacao = "!Obrigat�ria a instala��o da Caixa UMA sempre que houver viabilidade t�cnica!";
			mensagemTelaSolicitacao2 = "! Servi�o realizado mediante vistoria e aprova��o de or�amento pr�vio, conforme Tabela de Pre�o e Prazos de Servi�os da ARSESP!";

			servicoSolicitacao = configuracao.listarServicoSolicitacao();
			getEdicao().getSolicitante().setRepresentanteLegal(false);
			getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
		}

//		TODO:DEMANDA1313
//		if (tipo.getVulneravel()) {
//			return configurarFluxoVulneravel();
//		}

		if (tipo.getUsaTiposDoacao()) {
			return configurarFluxoDoacao();
		}

		if (tipo.getUsaTiposFaleConosco()) {
			return configurarFluxoFaleConosco();
		}

		if (tipo.getUsaDesassociacao()) {

			return configurarFluxoDesassociacao(tipo);
		}

		if (tipo.getInformaPagamento()) {
			configurarFluxoInformarPagamento(true, true, true, true);
		}

		if (tipo.getUsaDadosBancariosSolicitante()) {
			configurarFluxoRestituicao(true, true, true);
		}

		if (tipo.getUsaServicosSolicitacao()) {
			configurarFluxoModificacaoAguaEsgoto(false, true);
		}

		if (tipo.getTransferenciaDebitos()) {
			termo = new Termo();
		}

		if (tipo.getAlterarResponsavelContaPFPJ()) {
			setTipoResponsavelContaSelecionado(false);
			getEdicao().setResponsavelConta(null);
			setCheck1Supressao(false);
			return "/pages/publico/servicos/edicao_solicitacao_alterarrespconta";
		}

		if (tipo.getTarifaAssistenciaSocial()) {
			setCheck1Supressao(false);
		}

		if (tipo.getTarifaSocialDesempregado()) {
			setCheck1Supressao(false);
			setCheck1Ts(false);
			setCheck2Ts(false);
			setCheck3Ts(false);
			setCheck4Ts(false);
		}
		
		//TODO:DEMANDA1314
		if(tipo.getPedidoCaixaDagua()) {
			setCheck1Ts(false);
			setCheck2Ts(false);
			setCheck3Ts(false);
			setCheck4Ts(false);
		}

		return "/pages/publico/servicos/edicao_solicitacao";
	}

	private void configurarFluxoAtualizaDados(boolean rg, boolean cpfcnpj, boolean inscricao) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();

		anexos.add(new Anexo(TipoAnexo.RGRNECPFCNHSOCIO, Boolean.TRUE));
		anexos.add(new Anexo(TipoAnexo.CARTAOCNPJ, Boolean.TRUE));
		anexos.add(new Anexo(TipoAnexo.CONTRATOSOCIAL, Boolean.TRUE));
		anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUALSEHOUVER, Boolean.FALSE));

		getEdicao().getSolicitante().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());

		edicaoAnexos = anexos;
	}

	private void configurarFluxoModificacaoAguaEsgoto(boolean rg, boolean cpfcnpj) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();

		anexos.add(new Anexo(TipoAnexo.RG, true));
		anexos.add(new Anexo(TipoAnexo.CPFCNPJ, true));

		edicaoAnexos = anexos;
	}

	private void configurarFluxoRestituicao(boolean rg, boolean cpfCnpj, boolean inscricaoEstadual) {
		edicaoAnexos = configuracao.listaAnexoRestituicao(rg, cpfCnpj, inscricaoEstadual);

		getEdicao().getSolicitante().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());

	}

	private void configurarFluxoInformarPagamento(boolean rg, boolean cpfcnpj, boolean inscricao, boolean comprovante) {
		mensagemTelaSolicitacao = "!N�o s�o aceitos comprovantes de agendamento de pagamento!";

		Collection<Anexo> anexosInformarPagamento = new ArrayList<Anexo>();

		anexosInformarPagamento.add(new Anexo(TipoAnexo.CONTARECLAMADA, true));
//    	anexosInformarPagamento.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, inscricao));
		anexosInformarPagamento.add(new Anexo(TipoAnexo.COMPROVANTEPAGAMENTOAUTENTICADOBANCO, comprovante));
		anexosInformarPagamento.add(new Anexo(TipoAnexo.EXTRATOCONTACORRENTEDATAPAGAMENTO10DIAS, false));
		anexosInformarPagamento.add(new Anexo(TipoAnexo.RGRNECPFCNH, true));

		edicaoAnexos = anexosInformarPagamento;
	}

	private String configurarFluxoDesassociacao(TipoServico tipo) {
		mensagemTelaSolicitacao = "!N�o possuir d�bitos!";

		getEdicaoDesassociacao().setTipoServico(tipo);
		getEdicaoDesassociacao().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
		getEdicaoDesassociacao().setDocumentoEstatalFederal(new Anexo(TipoAnexo.OFICIO, true));
		getEdicaoDesassociacao().setRepresentateLegal(false);
		getEdicaoDesassociacao().setEstatalFederal(false);
		setTipoPessoaDesassociacaoSelecionado(false);
		deAcordoDesassociacao = false;

		return "/pages/publico/servicos/edicao_solicitacao_desassociacao";
	}

//	private void configurarAnexoUnidadeConsumo(boolean rg, boolean cpfcnpj, boolean inscricao) {
//    	Collection<Anexo> anexosUnidadeConsumo = new ArrayList<Anexo>();
//    	
//    	anexosUnidadeConsumo.add(new Anexo(TipoAnexo.RG, rg));
//    	anexosUnidadeConsumo.add(new Anexo(TipoAnexo.CPFCNPJ, cpfcnpj));
//    	anexosUnidadeConsumo.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, inscricao));
//    	anexosUnidadeConsumo.add(new Anexo(TipoAnexo.ESCRITURAESPECIFICACAO));
//		
//    	edicaoAnexos = anexosUnidadeConsumo;
//	}

	private String configurarFluxoVulneravel() {
		return "/pages/publico/servicos/edicao_solicitacao_vulneravel";
	}

	private String configurarFluxoDoacao() {
		entidadesOng = configuracao.listarOngs();
		return "/pages/publico/servicos/edicao_solicitacao_doacao";
	}

	private String configurarFluxoFaleConosco() {
		return "/pages/publico/servicos/edicao_fale_conosco";
	}

	private String configurarFluxoUnidadeConsumo(TipoServico tipo, boolean rg, boolean cpfcnpj, boolean inscricao,
			boolean escrituraespec) {
		edicaoUnidadeConsumo = new SolicitacaoUnidadeConsumo();
		edicaoUnidadeConsumo.setSolicitante(new Solicitante());
		tiposHabitacao = configuracao.listarTiposHabitacao();

		Collection<Anexo> anexos = new ArrayList<Anexo>();

		anexos.add(new Anexo(TipoAnexo.RG, rg));
		anexos.add(new Anexo(TipoAnexo.CPFCNPJ, cpfcnpj));
		anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, inscricao));
		anexos.add(new Anexo(TipoAnexo.ESCRITURAESPECIFICACAO, escrituraespec));

		edicaoAnexos = anexos;

		setExibeAlternativasSituacao(true);

		getEdicaoUnidadeConsumo().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setRepresentanteLegal(false);
		getEdicao().getSolicitante().setDocumentoRepresentateLegal(configuracao.procuracaoComFirmaReconhecida());
		getEdicaoUnidadeConsumo().setEntidadePublica(false);
		getEdicaoUnidadeConsumo().setDocumentoEntidadePublica(new Anexo(TipoAnexo.OFICIO, true));

		return "/pages/publico/servicos/edicao_solicitacao_unidade_consumo";
	}

	private void configurarAnexosFluxoUnidadeConsumo(boolean rg, boolean cpfcnpj, boolean inscricao,
			boolean escrituraespec) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();

		anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, true));
		anexos.add(new Anexo(TipoAnexo.CNPJSEHOUVER, false));
		anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUALSEHOUVER, false));

		if (edicaoUnidadeConsumo.getTipoUnidade().equals("A")) {
			anexos.add(new Anexo(TipoAnexo.ESCRITURAESPECIFICACAO, true));
		}
		edicaoAnexos = anexos;
	}

	public void atualizarAnexosUnidCons() {
		configurarAnexosFluxoUnidadeConsumo(false, false, false, false);
	}

	public void exibirAnexo(Integer codigoAnexo) {
		for (Anexo anexo : getEdicaoAnexos()) {

			if (TipoAnexo.COMPROVANTERENDAFAMILIARATE3SALARIOSMINIMOS.getCodigo().equals(codigoAnexo)) {
				if (TipoAnexo.COMPROVANTERENDAFAMILIARATE3SALARIOSMINIMOS.equals(anexo.getTipo())) {
					anexo.setExibeAnexo(!edicao.getTarifaSocialUnifamiliar().getTrabalhadorInformal());
					anexo.setObrigatorio(!edicao.getTarifaSocialUnifamiliar().getTrabalhadorInformal());
				}
			} else if (TipoAnexo.COMPROVANTERENDAULTIMOSALRIOATE3MESES.getCodigo().equals(codigoAnexo)) {
				if (TipoAnexo.COMPROVANTERENDAULTIMOSALRIOATE3MESES.equals(anexo.getTipo())) {
					anexo.setExibeAnexo(!edicao.getTarifaSocialDesempregado().getTrabalhadorInformal());
					anexo.setObrigatorio(!edicao.getTarifaSocialDesempregado().getTrabalhadorInformal());
				}
			} else if (TipoAnexo.COMPROVANTEAREAUTILDOIMOVELATE60METROSQUADRADOS.getCodigo().equals(codigoAnexo)) {
				if (TipoAnexo.COMPROVANTEAREAUTILDOIMOVELATE60METROSQUADRADOS.equals(anexo.getTipo())) {
					anexo.setExibeAnexo(!edicao.getTarifaSocialUnifamiliar().getNaoPossuiComprovante());
					anexo.setObrigatorio(!edicao.getTarifaSocialUnifamiliar().getNaoPossuiComprovante());
				}
			}
		}
	}

	public Collection<TipoHabitacao> getTiposHabitacao() {
		return tiposHabitacao;
	}

	public void setTiposHabitacao(Collection<TipoHabitacao> tiposHabitacao) {
		this.tiposHabitacao = tiposHabitacao;
	}

	public Boolean getInformaCompetencia() {
		return informaCompetencia;
	}

	public Collection<TipoOng> getEntidadesOng() {
		return entidadesOng;
	}

	public String getKey18nAntesAnexos() {
		return this.edicao.getTipoServico().getKey18nAntesAnexos(getEdicao().getSupressao().getTipo());
	}

	public void setEntidadesOng(Collection<TipoOng> entidadesOng) {
		this.entidadesOng = entidadesOng;
	}

	public Collection<Integer> getValoresPossiveisDoacao() {
		if (valoresPossiveisDoacao == null) {
			valoresPossiveisDoacao = Arrays.asList(1, 5, 10);
		}

		return valoresPossiveisDoacao;
	}

	public void setValoresPossiveisDoacao(Collection<Integer> valoresPossiveisDoacao) {
		this.valoresPossiveisDoacao = valoresPossiveisDoacao;
	}

	public Boolean getDoacaoAcordado() {
		return doacaoAcordado;
	}

	public void atualizarMascara() {
		String cpfCnpj = getEdicao().getSolicitante().getCpfCnpj();
		cpfCnpj = TreatString.filterOnlyNumber(cpfCnpj);
		if (cpfCnpj.length() == 11) {
			getEdicao().getSolicitante().setCpfCnpj(BrasilUtils.formatarCPF(cpfCnpj));
			setTipoSolicitante(1);

			if (getEdicao().getTipoServico().equals(TipoServico.INFORMAR_PAGAMENTO_CONTAS_SUPERIOR10DIAS)) {
				configurarFluxoInformarPagamento(true, true, false, true);
			}

			if (getEdicao().getTipoServico().equals(TipoServico.RESTITUICAO_VALORES_PAGOS_DUPLICIDADE)) {
				configurarFluxoRestituicao(true, true, false);
			}

			if (getEdicao().getTipoServico().equals(TipoServico.CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS)) {
				configurarAnexosFluxoUnidadeConsumo(true, true, false, false);
			}

//			if(getEdicao().getTipoServico().equals(TipoServico.MODIFICACAO_NA_LIGACAO_AGUA_ESGOTO)) {
//		        configurarFluxoModificacaoAguaEsgoto(true, true);
//			}

//			if (getEdicao().getTipoServico().equals(TipoServico.ATUALIZAR_DADOS_CADASTRAIS)) {
//				configurarFluxoAtualizaDados(true, true, false);
//			}

		} else {
			getEdicao().getSolicitante().setCpfCnpj(BrasilUtils.formatarCNPJ(cpfCnpj));
			setTipoSolicitante(2);

			if (getEdicao().getTipoServico().equals(TipoServico.INFORMAR_PAGAMENTO_CONTAS_SUPERIOR10DIAS)) {
				configurarFluxoInformarPagamento(true, true, true, true);
			}

			if (getEdicao().getTipoServico().equals(TipoServico.RESTITUICAO_VALORES_PAGOS_DUPLICIDADE)) {
				configurarFluxoRestituicao(false, true, true);
			}

			if (getEdicao().getTipoServico().equals(TipoServico.CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS)) {
				configurarAnexosFluxoUnidadeConsumo(false, true, true, false);
			}

//			if(getEdicao().getTipoServico().equals(TipoServico.MODIFICACAO_NA_LIGACAO_AGUA_ESGOTO)) {
//		        configurarFluxoModificacaoAguaEsgoto(false, true);
//			}

//			if (getEdicao().getTipoServico().equals(TipoServico.ATUALIZAR_DADOS_CADASTRAIS)) {
//				configurarFluxoAtualizaDados(false, true, true);
//			}
		}

	}

	public void atualizarMascaraDesassociacao() {
		String cpfCnpj = getEdicao().getSolicitante().getCpfCnpj();

		if (getEdicao().getTipoServico().getAtualizarDadosCadastrais()) {
			tipoSolicitanteAtualizarDadosCadastrais();
		}
		cpfCnpj = TreatString.filterOnlyNumber(cpfCnpj);
		if (cpfCnpj.length() == 11) {
			getEdicao().getSolicitante().setCpfCnpj(BrasilUtils.formatarCPF(cpfCnpj));
			edicaoAnexosDesassociacao = configuracao
					.listarDocumentosDesassociacao(getEdicaoDesassociacao().getPFouPJ());
		} else {
			getEdicao().getSolicitante().setCpfCnpj(BrasilUtils.formatarCNPJ(cpfCnpj));
			edicaoAnexosDesassociacao = configuracao
					.listarDocumentosDesassociacao(getEdicaoDesassociacao().getPFouPJ());
		}
	}

	public void setFile(StreamedContent file) {
		this.file = file;
	}

	public StreamedContent getFile() throws FileNotFoundException {

		String caminhoWebInf = FacesContext.getCurrentInstance().getExternalContext()
				.getRealPath("/resources/modelos/FE-MR0111-V.1.pdf");
		InputStream stream = new FileInputStream(caminhoWebInf); // Caminho onde est�
																	// salvo o arquivo.
		file = new DefaultStreamedContent(stream, "application/pdf", "edital.pdf");

		return file;
	}

	public Integer getNotaFeedback() {
		ResourceBundle bundle = Feedback.getI18nResourceBundle();

		if (notaFeedback == null) {
			this.notaFeedback = Integer.parseInt(bundle.getObject("valor.padr�o.feedback").toString());
		}
		return notaFeedback;
	}

	public void setDoacaoAcordado(Boolean doacaoAcordado) {
		this.doacaoAcordado = doacaoAcordado;
	}

	public void setNotaFeedback(Integer notaFeedback) {
		this.notaFeedback = notaFeedback;
	}

	public Boolean getHabilitaFeedback() {
		if (this.habilitaFeedback == null) {
			this.habilitaFeedback = Boolean.FALSE;
		}
		return habilitaFeedback;
	}

	public void setHabilitaFeedback(Boolean habilitaFeedback) {
		this.habilitaFeedback = habilitaFeedback;
	}

	public Boolean getLiberaOk() {
		if (this.liberaOk == null) {
			this.liberaOk = Boolean.FALSE;
		}
		return liberaOk;
	}

	public void setLiberaOk(Boolean liberaOk) {
		this.liberaOk = liberaOk;
	}

	public Integer getTipoSolicitante() {
		if (this.tipoSolicitante == null) {
			this.tipoSolicitante = 1; // PF
		}
		return tipoSolicitante;
	}

	public void setTipoSolicitante(Integer tipoSolicitante) {
		this.tipoSolicitante = tipoSolicitante;
	}

	public String getComentarioFeedback() {
		if (this.comentarioFeedback == null) {
			this.comentarioFeedback = "";
		}
		return comentarioFeedback;
	}

	public void setComentarioFeedback(String comentarioFeedback) {
		this.comentarioFeedback = comentarioFeedback;
	}

	public void habilitarDescricaoFeedback() {
		System.out.println(getNotaFeedback());

		if (getNotaFeedback().equals(0)) {
			this.liberaOk = Boolean.TRUE;
		} else {
			this.liberaOk = Boolean.FALSE;
		}

		if ((getNotaFeedback() < 7 || getNotaFeedback().equals(11)) && getNotaFeedback() != 0) {
			this.habilitaFeedback = Boolean.TRUE;
		} else {
			this.habilitaFeedback = Boolean.FALSE;
		}

	}

	public Comentario[] getComentarios() {
		return Comentario.values();
	}

	public Assunto[] getAssuntos() {
		return Assunto.values();
	}

	public SolicitacaoFaleConosco getEdicaoFaleConosco() {
		if (edicaoFaleConosco == null) {
			edicaoFaleConosco = new SolicitacaoFaleConosco();
		}
		return edicaoFaleConosco;
	}

	public SolicitacaoUnidadeConsumo getEdicaoUnidadeConsumo() {
		if (edicaoUnidadeConsumo == null) {
			edicaoUnidadeConsumo = new SolicitacaoUnidadeConsumo();
		}
		return edicaoUnidadeConsumo;
	}

	public void setEdicaoUnidadeConsumo(SolicitacaoUnidadeConsumo edicaoUnidadeConsumo) {
		this.edicaoUnidadeConsumo = edicaoUnidadeConsumo;
	}

	public Boolean getDeAcordoDesassociacao() {
		return deAcordoDesassociacao;
	}

	public void setEdicaoFaleConosco(SolicitacaoFaleConosco edicaoFaleConosco) {
		this.edicaoFaleConosco = edicaoFaleConosco;
	}

	public void setDeAcordoDesassociacao(Boolean deAcordoDesassociacao) {
		this.deAcordoDesassociacao = deAcordoDesassociacao;
	}
	
	public Boolean getElegivel() {
		return elegivel;
	}

	public void setElegivel(Boolean elegivel) {
		this.elegivel = elegivel;
	}

	public Boolean getNelegivel() {
		return nelegivel;
	}

	public void setNelegivel(Boolean nelegivel) {
		this.nelegivel = nelegivel;
	}

	public String getMensagemTelaSolicitacao() {
		return mensagemTelaSolicitacao;
	}

	public void setMensagemTelaSolicitacao(String mensagemTelaSolicitacao) {
		this.mensagemTelaSolicitacao = mensagemTelaSolicitacao;
	}

	public String getMensagemTelaSolicitacao2() {
		return mensagemTelaSolicitacao2;
	}

	public void setMensagemTelaSolicitacao2(String mensagemTelaSolicitacao2) {
		this.mensagemTelaSolicitacao2 = mensagemTelaSolicitacao2;
	}

	public boolean isExibeAlternativasSituacao() {
		PrimeFaces.current().ajax().update("form-unidade-consumo:alternativasSituacao");
		return exibeAlternativasSituacao;
	}

	public void setExibeAlternativasSituacao(boolean exibeAlternativasSituacao) {
		this.exibeAlternativasSituacao = exibeAlternativasSituacao;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getDescricaoDocumento() {

		String modelo = "";

		if (getEdicao().getTipoServico().equals(TipoServico.SUPRESSAO_PEDIDO_RELIGACAO_IMOVEL)
				&& getDescricaoDocumentoSupressao() != null && !getDescricaoDocumentoSupressao().equals("")) {
			modelo = getDescricaoDocumentoSupressao();
		} else if (getEdicao().getTipoServico().equals(TipoServico.DESASSOCIACAO_TITUL_PJ_E_PF)
				&& getDescricaoDocumentoSupressao() != null && !getDescricaoDocumentoSupressao().equals("")) {
			modelo = getDescricaoDocumentoSupressao();
		} else {
			modelo = getEdicao().getTipoServico().getModeloIdCliente();
		}

		if (modelo.equals("A")) {
			return "CPF do Titular ";
		} else if (modelo.equals("B")) {
			return "CPF do Solicitante ";
		} else if (modelo.equals("C")) {
			return "CPF do Propriet�rio ";
		} else if (modelo.equals("D")) {
			return "CPF/CNPJ do Titular";
		} else {
			return "CPF/CNPJ";
		}
	}

	public String getDescricaoNome() {

		String modelo = "";

		if (getEdicao().getTipoServico().equals(TipoServico.SUPRESSAO_PEDIDO_RELIGACAO_IMOVEL)
				&& getDescricaoNomeSupressao() != null && !getDescricaoNomeSupressao().equals("")) {
			modelo = getDescricaoNomeSupressao();
		} else if (getEdicao().getTipoServico().equals(TipoServico.DESASSOCIACAO_TITUL_PJ_E_PF)
				&& getDescricaoNomeSupressao() != null && !getDescricaoNomeSupressao().equals("")) {
			modelo = getDescricaoNomeSupressao();
		} else {
			modelo = getEdicao().getTipoServico().getModeloIdCliente();
		}

		if (modelo.equals("A")) {
			return "Nome do Titular ";
		} else if (modelo.equals("B")) {
			return "Nome do Solicitante ";
		} else if (modelo.equals("C")) {
			return "Nome  do Propriet�rio ";
		} else if (modelo.equals("D")) {
			return "Nome do Solicitante";
		} else {
			return "Nome";
		}
	}

	public Boolean validarSolicitacaoServico() {
		if (getEdicao().getSolicitante().getCpfCnpj() != null
				&& !getEdicao().getSolicitante().getCpfCnpj().trim().equals("")
				&& getEdicao().getSolicitante().getNome() != null
				&& !getEdicao().getSolicitante().getNome().trim().equals("")) {
			if (business.buscarSolitacaoRecente(getEdicao(), -5)) {
				return false;
			}
		}
		return true;
	}

	public Boolean validarSolicitacaoServicoUnidCons() {
		if (getEdicao().getSolicitante().getCpfCnpj() != null
				&& !getEdicao().getSolicitante().getCpfCnpj().trim().equals("")
				&& getEdicaoUnidadeConsumo().getNomeSolicitante() != null
				&& !getEdicaoUnidadeConsumo().getNomeSolicitante().trim().equals("")) {
			if (business.buscarSolitacaoRecente(getEdicao(), -5)) {
				return false;
			}
		}
		return true;
	}

	public Termo getTermo() {
		return termo;
	}

	public void setTermo(Termo termo) {
		this.termo = termo;
	}

	public String getDescricaoNomeSupressao() {
		return descricaoNomeSupressao;
	}

	public void setDescricaoNomeSupressao(String descricaoNomeSupressao) {
		this.descricaoNomeSupressao = descricaoNomeSupressao;
	}

	public String getDescricaoDocumentoSupressao() {
		return descricaoDocumentoSupressao;
	}

	public void setDescricaoDocumentoSupressao(String descricaoDocumentoSupressao) {
		this.descricaoDocumentoSupressao = descricaoDocumentoSupressao;
	}

	public Boolean getCheck1Supressao() {
		return check1Supressao;
	}

	public void setCheck1Supressao(Boolean check1Supressao) {
		this.check1Supressao = check1Supressao;
	}

	public Boolean getCheck2Supressao() {
		return check2Supressao;
	}

	public void setCheck2Supressao(Boolean check2Supressao) {
		this.check2Supressao = check2Supressao;
	}

	public String getInformacoesAdicionaisRestituicao() {
		return informacoesAdicionaisRestituicao;
	}

	public void setInformacoesAdicionaisRestituicao(String informacoesAdicionaisRestituicao) {
		this.informacoesAdicionaisRestituicao = informacoesAdicionaisRestituicao;
	}

	public Boolean getCheck1Ts() {
		return check1Ts;
	}

	public void setCheck1Ts(Boolean check1Ts) {
		this.check1Ts = check1Ts;
	}

	public Boolean getCheck2Ts() {
		return check2Ts;
	}

	public void setCheck2Ts(Boolean check2Ts) {
		this.check2Ts = check2Ts;
	}

	public Boolean getCheck3Ts() {
		return check3Ts;
	}

	public void setCheck3Ts(Boolean check3Ts) {
		this.check3Ts = check3Ts;
	}

	public Boolean getCheck4Ts() {
		return check4Ts;
	}

	public void setCheck4Ts(Boolean check4Ts) {
		this.check4Ts = check4Ts;
	}

	public Boolean getCheck5Ts() {
		return check5Ts;
	}

	public void setCheck5Ts(Boolean check5Ts) {
		this.check5Ts = check5Ts;
	}

	public boolean isTipoPessoaDesassociacaoSelecionado() {
		return tipoPessoaDesassociacaoSelecionado;
	}

	public void setTipoPessoaDesassociacaoSelecionado(boolean tipoPessoaDesassociacaoSelecionado) {
		this.tipoPessoaDesassociacaoSelecionado = tipoPessoaDesassociacaoSelecionado;
	}

	public boolean isTipoResponsavelContaSelecionado() {
		return tipoResponsavelContaSelecionado;
	}

	public void setTipoResponsavelContaSelecionado(boolean tipoResponsavelContaSelecionado) {
		this.tipoResponsavelContaSelecionado = tipoResponsavelContaSelecionado;
	}

	public String getDescricaoNomeAlteraResp() {
		return descricaoNomeAlteraResp;
	}

	public void setDescricaoNomeAlteraResp(String descricaoNomeAlteraResp) {
		this.descricaoNomeAlteraResp = descricaoNomeAlteraResp;
	}

	public String getTermoResponsAlteraResp() {
		return termoResponsAlteraResp;
	}

	public void setTermoResponsAlteraResp(String termoResponsAlteraResp) {
		this.termoResponsAlteraResp = termoResponsAlteraResp;
	}

	public Boolean getDataNascimentoStr() {
		return dataNascimentoStr;
	}

	public void setDataNascimentoStr(Boolean dataNascimentoStr) {
		this.dataNascimentoStr = dataNascimentoStr;
	}
	
	//TODO:1314
	
	public Boolean getExibeRepresentanteSupressao() {
		return exibeRepresentanteSupressao;
	}

	public void setExibeRepresentanteSupressao(Boolean exibeRepresentanteSupressao) {
		this.exibeRepresentanteSupressao = exibeRepresentanteSupressao;
	}

	public String getFornecimentoPde() {
		return fornecimentoPde;
	}

	public void setFornecimentoPde(String fornecimentoPde) {
		this.fornecimentoPde = fornecimentoPde;
	}

}
