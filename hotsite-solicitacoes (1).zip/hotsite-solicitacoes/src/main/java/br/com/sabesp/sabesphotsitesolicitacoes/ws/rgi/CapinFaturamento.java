
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for capinFaturamento complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="capinFaturamento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="agencia" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="banco" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="beneficioDataFim" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="beneficioDataInicio" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="beneficioMotivo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ciclo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="contaCorrente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="creditoAnterior" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="creditoAtual" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="diaVencimento" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="formaPagamento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="grupo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="tipo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="tipoCobranca" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoCobrancaCodigo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="tipoCobrancaDescricao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoDescricao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "capinFaturamento", propOrder = {
    "agencia",
    "banco",
    "beneficioDataFim",
    "beneficioDataInicio",
    "beneficioMotivo",
    "ciclo",
    "contaCorrente",
    "creditoAnterior",
    "creditoAtual",
    "diaVencimento",
    "formaPagamento",
    "grupo",
    "tipo",
    "tipoCobranca",
    "tipoCobrancaCodigo",
    "tipoCobrancaDescricao",
    "tipoDescricao"
})
public class CapinFaturamento {

    protected String agencia;
    protected Integer banco;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar beneficioDataFim;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar beneficioDataInicio;
    protected String beneficioMotivo;
    protected Integer ciclo;
    protected String contaCorrente;
    protected String creditoAnterior;
    protected String creditoAtual;
    protected Integer diaVencimento;
    protected String formaPagamento;
    protected Integer grupo;
    protected Integer tipo;
    protected String tipoCobranca;
    protected Integer tipoCobrancaCodigo;
    protected String tipoCobrancaDescricao;
    protected String tipoDescricao;

    /**
     * Gets the value of the agencia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgencia() {
        return agencia;
    }

    /**
     * Sets the value of the agencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgencia(String value) {
        this.agencia = value;
    }

    /**
     * Gets the value of the banco property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBanco() {
        return banco;
    }

    /**
     * Sets the value of the banco property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBanco(Integer value) {
        this.banco = value;
    }

    /**
     * Gets the value of the beneficioDataFim property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBeneficioDataFim() {
        return beneficioDataFim;
    }

    /**
     * Sets the value of the beneficioDataFim property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBeneficioDataFim(XMLGregorianCalendar value) {
        this.beneficioDataFim = value;
    }

    /**
     * Gets the value of the beneficioDataInicio property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBeneficioDataInicio() {
        return beneficioDataInicio;
    }

    /**
     * Sets the value of the beneficioDataInicio property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBeneficioDataInicio(XMLGregorianCalendar value) {
        this.beneficioDataInicio = value;
    }

    /**
     * Gets the value of the beneficioMotivo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficioMotivo() {
        return beneficioMotivo;
    }

    /**
     * Sets the value of the beneficioMotivo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficioMotivo(String value) {
        this.beneficioMotivo = value;
    }

    /**
     * Gets the value of the ciclo property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCiclo() {
        return ciclo;
    }

    /**
     * Sets the value of the ciclo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCiclo(Integer value) {
        this.ciclo = value;
    }

    /**
     * Gets the value of the contaCorrente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContaCorrente() {
        return contaCorrente;
    }

    /**
     * Sets the value of the contaCorrente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContaCorrente(String value) {
        this.contaCorrente = value;
    }

    /**
     * Gets the value of the creditoAnterior property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditoAnterior() {
        return creditoAnterior;
    }

    /**
     * Sets the value of the creditoAnterior property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditoAnterior(String value) {
        this.creditoAnterior = value;
    }

    /**
     * Gets the value of the creditoAtual property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditoAtual() {
        return creditoAtual;
    }

    /**
     * Sets the value of the creditoAtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditoAtual(String value) {
        this.creditoAtual = value;
    }

    /**
     * Gets the value of the diaVencimento property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDiaVencimento() {
        return diaVencimento;
    }

    /**
     * Sets the value of the diaVencimento property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDiaVencimento(Integer value) {
        this.diaVencimento = value;
    }

    /**
     * Gets the value of the formaPagamento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormaPagamento() {
        return formaPagamento;
    }

    /**
     * Sets the value of the formaPagamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormaPagamento(String value) {
        this.formaPagamento = value;
    }

    /**
     * Gets the value of the grupo property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getGrupo() {
        return grupo;
    }

    /**
     * Sets the value of the grupo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setGrupo(Integer value) {
        this.grupo = value;
    }

    /**
     * Gets the value of the tipo property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTipo() {
        return tipo;
    }

    /**
     * Sets the value of the tipo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTipo(Integer value) {
        this.tipo = value;
    }

    /**
     * Gets the value of the tipoCobranca property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoCobranca() {
        return tipoCobranca;
    }

    /**
     * Sets the value of the tipoCobranca property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoCobranca(String value) {
        this.tipoCobranca = value;
    }

    /**
     * Gets the value of the tipoCobrancaCodigo property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTipoCobrancaCodigo() {
        return tipoCobrancaCodigo;
    }

    /**
     * Sets the value of the tipoCobrancaCodigo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTipoCobrancaCodigo(Integer value) {
        this.tipoCobrancaCodigo = value;
    }

    /**
     * Gets the value of the tipoCobrancaDescricao property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoCobrancaDescricao() {
        return tipoCobrancaDescricao;
    }

    /**
     * Sets the value of the tipoCobrancaDescricao property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoCobrancaDescricao(String value) {
        this.tipoCobrancaDescricao = value;
    }

    /**
     * Gets the value of the tipoDescricao property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoDescricao() {
        return tipoDescricao;
    }

    /**
     * Sets the value of the tipoDescricao property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoDescricao(String value) {
        this.tipoDescricao = value;
    }

}
