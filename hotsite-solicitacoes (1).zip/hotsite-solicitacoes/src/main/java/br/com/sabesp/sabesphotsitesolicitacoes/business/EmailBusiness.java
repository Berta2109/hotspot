package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.List;
import java.util.ResourceBundle;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.AnexoSolicitacaoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Assunto;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.AtendimentoComercial;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Atestado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Beneficio;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.CadastroUnidadeConsumo;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Comentario;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.ConfigEmail;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosBancarios;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosCadastro;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.FaleConosco;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SolicitacaoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TarifaSocialDesempregado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TarifaSocialUnifamiliar;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoPessoa;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoSupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TransferenciaTitularidadeDebitos;
import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.GenericRepository;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias.Propriedades;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatDate;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatFile;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Termo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.TipoAnexo;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

@Stateless
public class EmailBusiness implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -1950699026968704988L;

	private static final Logger LOG = LoggerFactory.getLogger(EmailBusiness.class);

	@EJB
	private GenericRepository repository;

	/**
	 * Metodo responsavel por realizar o envio do email ao AtendimentoComercial
	 *
	 * @since 17 de abr de 2020 (Projeto)
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @param bundle
	 * @param destinatario
	 * @param solicitacao
	 * @param termo 
	 */
//	@Asynchronous
	public void enviarEmailCadastroSolicitacao(ResourceBundle bundle, AtendimentoComercial destinatario, SolicitacaoServico solicitacao, Termo termo) {
		SolicitacaoServico edicao = repository.findById(SolicitacaoServico.class, solicitacao.getId());
		if (edicao == null) {
			LOG.error("Solicitacao [" + solicitacao + "] nao foi encontrada na base, talvez ocorreu uma falha para salva-la na base anteriormente");
			return;
		}
		try {
			if (destinatario == null) {
				throw new IllegalStateException("Solicitacao nao teve a AtendimentoComercial identificada");
			}
			TipoServico tipoServico = TipoServico.obter(edicao.getTipoServico());
			
			ConfigEmail configEmail = configEmail(tipoServico.getCodigo());
			
			if(configEmail != null) {
				destinatario.setEmail(configEmail.getEmail() != null ? configEmail.getEmail() : destinatario.getEmail());
			}
			enviarEmailAtendimentoComercial(bundle, tipoServico, destinatario, solicitacao, termo); 
			
			// sucesso envio
			solicitacao.setStatusEnvioEmail(2);
		} catch (Exception e) {
			LOG.error("Falha enviar email solicitacao [" + solicitacao + "]", e);
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			solicitacao.setErroEnvioEmail(TreatString.subString(errors.toString(), 1000));
			// falha no envio
			solicitacao.setStatusEnvioEmail(3);
		}
		edicao.setStatusEnvioEmail(solicitacao.getStatusEnvioEmail());
		edicao.setErroEnvioEmail(solicitacao.getErroEnvioEmail());
		repository.update(edicao);
	}
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public ConfigEmail configEmail(Integer idServico) {
		
		String sql = "SELECT * "
				+ "FROM CONFIG_EMAIL CE "
				+ "WHERE CE.ID_SERVICO = ?1 ";

		Query query = repository.getEntityManager().createNativeQuery(sql);
		query.setParameter(1, idServico);

		@SuppressWarnings("unchecked")
		List<Object[]> retorno = query.getResultList();
		if (retorno.isEmpty()) {
			return null;
		}

		for (Object[] objects : retorno) {
			ConfigEmail configEmail = new ConfigEmail();
			BigDecimal id = (BigDecimal) objects[0];
			configEmail.setId(id.intValue());
			
			String email = (String) objects[1];
			configEmail.setEmail(email);
			return configEmail;
		}

		return null;
	}

	private void enviarEmailAtendimentoComercial(ResourceBundle bundle, TipoServico tipoServico, AtendimentoComercial destinatario,
			SolicitacaoServico solicitacao, Termo termo) throws AddressException, MessagingException, NamingException, FileNotFoundException {

		String assunto = "Sabesp F�cil - Atendimento e Entrega Digital de Documentos " + " ["+ destinatario.getMunicipio() +"]" +  " " + bundle.getString(tipoServico.getKey18n());
		String[] destinatarios = new String[] { destinatario.getEmail() };

		StringBuilder template = null;
		
		if(tipoServico.equals(TipoServico.PLA)) {
			template = TreatFile.getContent("/templates-email/solicitacao-criada-pla.html");
			TreatString.replace("{dataCadastro}", template, TreatDate.formatDefaultDate(solicitacao.getDataCadastro()));
			TreatString.replace("{protocolo}", template,  solicitacao.getProtocolo());
			TreatString.replace("{municipio}", template,  destinatario.getMunicipio());
			TreatString.replace("{rgi}", template, solicitacao.getRgi());
			TreatString.replace("{cpf}", template, BrasilUtils.formatarCPF(solicitacao.getCpf()));
			TreatString.replace("{nome}", template, solicitacao.getNome());
			TreatString.replace("{email}", template, solicitacao.getEmail());
			TreatString.replace("{telefone}", template, BrasilUtils.formatarTelefoneComDDD(solicitacao.getTelefone()));
			
			TreatString.replace("{campoEndereco}", template, novoParagrafo(bundle, "endereco", solicitacao.getEndereco()));

		} else {
			template = TreatFile.getContent("/templates-email/solicitacao-criada.html");
			TreatString.replace("{servico}", template, bundle.getObject(tipoServico.getKey18n()));
			TreatString.replace("{dataCadastro}", template, TreatDate.formatDefaultDate(solicitacao.getDataCadastro()));
			TreatString.replace("{prazoResposta}", template, "5 dias &uacute;teis");
			TreatString.replace("{protocolo}", template,  solicitacao.getProtocolo());
			TreatString.replace("{municipio}", template,  destinatario.getMunicipio());
			TreatString.replace("{rgi}", template, solicitacao.getRgi());
			TreatString.replace("{cpf}", template, BrasilUtils.formatarCPF(solicitacao.getCpf()));
			TreatString.replace("{nome}", template, solicitacao.getNome());
			TreatString.replace("{email}", template, solicitacao.getEmail());
			TreatString.replace("{telefone}", template, BrasilUtils.formatarTelefoneComDDD(solicitacao.getTelefone()));
		}

		prepararCamposCondicionaisTemplate(bundle, tipoServico, solicitacao, template);

		prepararAnexos(bundle, tipoServico, solicitacao, template);
		
		prepararFotos(bundle, tipoServico, solicitacao, template);

		efetuarEnvioEmail(assunto, destinatarios, template, solicitacao.getEmail(), termo);
	}

	private void prepararAnexos(ResourceBundle bundle, TipoServico tipoServico, SolicitacaoServico solicitacao, StringBuilder template) {
		if (tipoServico.getNecessarioDocumentacao()) {
			Collection<AnexoSolicitacaoServico> anexos = repository.search(AnexoSolicitacaoServico.class, "select a from AnexoSolicitacaoServico a where a.solicitacao.id = ? order by a.id asc", solicitacao.getId());
			StringBuilder htmlCampos = new StringBuilder();
			String raizSite = Preferencias.get(Propriedades.URL);

			for (AnexoSolicitacaoServico anexo : anexos) {
				
				if(verificaFoto(anexo)) {
					continue;
				}
				
				TipoAnexo tipo = TipoAnexo.get(anexo.getTipo());
				if (tipo == null) {
					continue;
				}
				StringBuilder pCampo = TreatFile.getContent("/templates-email/paragrafo-anexo.html");
				String urlAnexo = raizSite + "publico/solicitacao/anexo?id=" + solicitacao.getId() + "&hash=" + anexo.getIdentificador();

				TreatString.replace("{url}", pCampo, urlAnexo);
				TreatString.replace("{titulo}", pCampo, bundle.getObject(tipo.getKey18n()));

				htmlCampos.append(pCampo);
			}
			StringBuilder secaoAnexos = novaSecao(bundle, "label.documentacaonecessariaserencaminhada");
			TreatString.replace("{htmlCampos}", secaoAnexos, htmlCampos.toString());

			TreatString.replace("{secaoAnexos}", template, secaoAnexos.toString());
		} else {
			TreatString.replace("{secaoAnexos}", template, "");
		}
	}
	
	private void prepararFotos(ResourceBundle bundle, TipoServico tipoServico, SolicitacaoServico solicitacao, StringBuilder template) {
		if (tipoServico.getNecessarioDocumentacao()) {
			Collection<AnexoSolicitacaoServico> anexos = repository.search(AnexoSolicitacaoServico.class, "select a from AnexoSolicitacaoServico a where a.solicitacao.id = ? order by a.id asc", solicitacao.getId());
			StringBuilder htmlCampos = new StringBuilder();
			String raizSite = Preferencias.get(Propriedades.URL);

			for (AnexoSolicitacaoServico anexo : anexos) {
				
				if(verificaFoto(anexo)) {
				
					TipoAnexo tipo = TipoAnexo.get(anexo.getTipo());
					if (tipo == null) {
						continue;
					}
					StringBuilder pCampo = TreatFile.getContent("/templates-email/paragrafo-anexo.html");
					String urlAnexo = raizSite + "publico/solicitacao/anexo?id=" + solicitacao.getId() + "&hash=" + anexo.getIdentificador();
	
					TreatString.replace("{url}", pCampo, urlAnexo);
					TreatString.replace("{titulo}", pCampo, bundle.getObject(tipo.getKey18n()));
	
					htmlCampos.append(pCampo);
				
				}
			}
			StringBuilder secaoFotos = novaSecao(bundle, "label.fotosnecessariaserencaminhada");
			TreatString.replace("{htmlCampos}", secaoFotos, htmlCampos.toString());

			TreatString.replace("{secaoFotos}", template, secaoFotos.toString());
		} else {
			TreatString.replace("{secaoFotos}", template, "");
		}
	}

	private boolean verificaFoto(AnexoSolicitacaoServico anexo) {
		
		Integer tipoAnexo = anexo.getTipo();

		if(tipoAnexo.equals(TipoAnexo.FOTO1.getCodigo()) || tipoAnexo.equals(TipoAnexo.FOTO2.getCodigo()) 
				|| tipoAnexo.equals(TipoAnexo.FOTO3.getCodigo()) || tipoAnexo.equals(TipoAnexo.FOTO4.getCodigo())
						|| tipoAnexo.equals(TipoAnexo.FOTO5.getCodigo()) || tipoAnexo.equals(TipoAnexo.FOTO6.getCodigo())
								|| tipoAnexo.equals(TipoAnexo.FOTO7.getCodigo()) || tipoAnexo.equals(TipoAnexo.FOTO8.getCodigo())) {
			return true;
		}
		
		return false;
	}

	private void emailRepresentanteLegal(ResourceBundle bundle, StringBuilder template, TransferenciaTitularidadeDebitos campo) {
		if (campo != null) {
			StringBuilder html = new StringBuilder();
			html.append(novoParagrafo(bundle, "solicitante.tipo", bundle.getString("solicitante.tipo." + campo.getTipo())));
			html.append(novoParagrafo(bundle, "solicitante.representanteLegal", campo.getRepresentateLegal() ? "Sim" : "N\u00e3o"));
			TreatString.replace("{campoTipoSolicitante}", template, html);
		}
	}

	private void emailRepresentanteLegal(ResourceBundle bundle, StringBuilder template, Atestado atestado) {
		if (atestado != null) {
			StringBuilder html = new StringBuilder();
			html.append(novoParagrafo(bundle, "solicitante.representanteLegal", atestado.getRepresentateLegal() ? "Sim" : "N\u00e3o"));
			TreatString.replace("{campoTipoSolicitante}", template, html);
		}
	}

	private void emailRepresentanteLegal(ResourceBundle bundle, StringBuilder template, CadastroUnidadeConsumo cadastroUnidadeConsumo) {
		if (cadastroUnidadeConsumo != null) {
			StringBuilder html = new StringBuilder();
			String solicitanteTipo = "";
			if(cadastroUnidadeConsumo.getTipo() != null ) {
				solicitanteTipo = cadastroUnidadeConsumo.getTipo().equals(4) ? "solicitante.tipo.proprietario" :
					cadastroUnidadeConsumo.getTipo().equals(5) ? "solicitante.tipo.representanteconstrutora" :
							cadastroUnidadeConsumo.getTipo().equals(6) ? "solicitante.tipo.sindico" : "";
				html.append(novoParagrafo(bundle, "solicitante.tipo", bundle.getString(solicitanteTipo)));
			}
			html.append(novoParagrafo(bundle, "solicitante.representanteLegal", cadastroUnidadeConsumo.getRepresentateLegal() ? "Sim" : "N\u00e3o"));
			TreatString.replace("{campoTipoSolicitante}", template, html);
		}
	}

	private void emailRepresentanteLegal(ResourceBundle bundle, StringBuilder template, DadosCadastro dadosCadastro) {
		if (dadosCadastro != null) {
			StringBuilder html = new StringBuilder();
			html.append(novoParagrafo(bundle, "solicitante.tipo", bundle.getString("solicitante.dadoscadastro.tipo." + dadosCadastro.getTipo())));
			html.append(novoParagrafo(bundle, "solicitante.representanteLegal", dadosCadastro.getRepresentanteLegal() ? "Sim" : "N\u00e3o"));
			TreatString.replace("{campoTipoSolicitante}", template, html);
		}
	}

	private void prepararCamposCondicionaisTemplate(ResourceBundle bundle, TipoServico tipoServico, SolicitacaoServico solicitacao,
			StringBuilder template) {
		if (tipoServico.getRepresentanteLegalEmail() ) {
			TransferenciaTitularidadeDebitos transferenciaTitularidadeDebitos = repository.searchUniqueResult(TransferenciaTitularidadeDebitos.class,"select t from TransferenciaTitularidadeDebitos t where t.solicitacao.id = ?", solicitacao.getId());
			emailRepresentanteLegal(bundle, template, transferenciaTitularidadeDebitos);
			Atestado atestado = repository.searchUniqueResult(Atestado.class, " select a from Atestado a where a.solicitacao.id = ? ", solicitacao.getId());
		    emailRepresentanteLegal(bundle, template, atestado);
		    CadastroUnidadeConsumo cadastroUnidadeConsumo = repository.searchUniqueResult(CadastroUnidadeConsumo.class, " select u from CadastroUnidadeConsumo u where u.solicitacao.id = ? ", solicitacao.getId());
		    emailRepresentanteLegal(bundle, template, cadastroUnidadeConsumo);
		    DadosCadastro cadastro = repository.searchUniqueResult(DadosCadastro.class, " select c from DadosCadastro c where c.solicitacao.id = ? ", solicitacao.getId());
		    emailRepresentanteLegal(bundle, template, cadastro);
		} else {
			TreatString.replace("{campoTipoSolicitante}", template, "");
		}

		if (tipoServico.getUsaTiposAtestado()) {
			Atestado atestado = repository.searchUniqueResult(Atestado.class, "select a from Atestado a where a.solicitacao.id = ?", solicitacao.getId());
			TreatString.replace("{campoAtestado}", template, novoParagrafo(bundle, "tipoAtestado", atestado.getTipo().getDescricao()));
		} else {
			TreatString.replace("{campoAtestado}", template, "");
		}
		
		if(tipoServico.getTarifaSocialUnifamiliar()) {
			TarifaSocialUnifamiliar tsu = repository.searchUniqueResult(TarifaSocialUnifamiliar.class, "select t from TarifaSocialUnifamiliar t where t.solicitacao.id = ?", solicitacao.getId());
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "trabalhadorInformal", tsu.getTrabalhadorInformal() ? "SIM" : "N�O"));
			htmlCampos.append(novoParagrafo(bundle, "naoPossuiComprovante", tsu.getNaoPossuiComprovante() ? "SIM" : "N�O"));
			
			TreatString.replace("{campoUnifamiliar}", template, htmlCampos.toString());
		} else {
			TreatString.replace("{campoUnifamiliar}", template, "");
		}
		
		if(tipoServico.getTarifaSocialDesempregado()) {
			TarifaSocialDesempregado tsd = repository.searchUniqueResult(TarifaSocialDesempregado.class, "select t from TarifaSocialDesempregado t where t.solicitacao.id = ?", solicitacao.getId());
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "trabalhadorInformal", tsd.getTrabalhadorInformal() ? "SIM" : "N�O"));
			
			TreatString.replace("{campoDesempregado}", template, htmlCampos.toString());
		} else {
			TreatString.replace("{campoDesempregado}", template, "");
		}

		if (tipoServico.getUsaTiposBeneficio()) {
			Beneficio beneficio = repository.searchUniqueResult(Beneficio.class, "select b from Beneficio b where b.solicitacao.id = ?", solicitacao.getId());
			TreatString.replace("{campoBeneficio}", template, novoParagrafo(bundle, "tipoBeneficio", beneficio.getTipo().getDescricao()));
		} else {
			TreatString.replace("{campoBeneficio}", template, "");
		}

		if (tipoServico.getUsaTiposSupressao()) {
			SupressaoReligacao supressao = repository.searchUniqueResult(SupressaoReligacao.class, "select s from SupressaoReligacao s where s.solicitacao.id = ?",
					solicitacao.getId());
			TreatString.replace("{campoSupressao}", template, novoParagrafo(bundle, "tipoSupressao", supressao.getTipo().getDescricao()));
		} else {
			TreatString.replace("{campoSupressao}", template, "");
		}

		if (tipoServico.getUsaDadosBancariosSolicitante()) {
			DadosBancarios dados = repository.searchUniqueResult(DadosBancarios.class, "select d from DadosBancarios d where d.solicitacao.id = ?",
					solicitacao.getId());
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "dadosBancarios.instituicao", dados.getInstituicao()));
			htmlCampos.append(novoParagrafo(bundle, "dadosBancarios.tipoConta", dados.getTipoConta().equals(1) ? "Conta corrente" : "Conta poupanca"));
			htmlCampos.append(novoParagrafo(bundle, "dadosBancarios.agencia", dados.getAgencia()));
			htmlCampos.append(novoParagrafo(bundle, "dadosBancarios.conta", dados.getConta()));

			StringBuilder secaoDadosBancarios = novaSecao(bundle, "label.dadosbancariospararestituicao");
			TreatString.replace("{htmlCampos}", secaoDadosBancarios, htmlCampos.toString());
			TreatString.replace("{secaoDadosBancarios}", template, secaoDadosBancarios.toString());
		} else {
			TreatString.replace("{secaoDadosBancarios}", template, "");
		}

		if (tipoServico.getAtualizarDadosCadastrais()) {
			DadosCadastro dadosCadastro =  repository.searchUniqueResult(DadosCadastro.class, " select c from DadosCadastro c where c.solicitacao.id = ? ", solicitacao.getId());
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.nome", dadosCadastro.getNome()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.telefoneCelular", BrasilUtils.formatarTelefoneComDDD(dadosCadastro.getTelefoneCelular())));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.telefoneFixo", BrasilUtils.formatarTelefoneComDDD(dadosCadastro.getTelefoneFixo())));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.dataNascimento", TreatDate.formatDefaultDate(dadosCadastro.getDataNascimento())));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.email", dadosCadastro.getEmail()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.logradouro", dadosCadastro.getLogradouro()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.numero", dadosCadastro.getNumero()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.complemento", dadosCadastro.getComplemento()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.bairro", dadosCadastro.getBairro()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.cep", dadosCadastro.getCep()));
			htmlCampos.append(novoParagrafo(bundle,"dadosCadastro.cidade", dadosCadastro.getCidade()));
			StringBuilder secaoDadosCadastro = novaSecao(bundle, "label.atualizardadoscadastrais");
			TreatString.replace("{htmlCampos}", secaoDadosCadastro, htmlCampos.toString());
			TreatString.replace("{secaoDadosCadastro}", template, secaoDadosCadastro.toString());
		} else {
        	TreatString.replace("{secaoDadosCadastro}", template, "");
		}

		/*
		 * if (!tipoServico.is(TipoServico.CORRECAO_LEITURA_POR_MEDIA)) { DadosLeitura
		 * dados = repository.searchUniqueResult(DadosLeitura.class,
		 * "select d from DadosLeitura d where d.solicitacao.id = ?",
		 * solicitacao.getId()); StringBuilder htmlCampos = new StringBuilder();
		 * htmlCampos.append(novoParagrafo(bundle, "label.dadosleitura",
		 * TreatDate.formatDefaultDate(dados.getData())));
		 * htmlCampos.append(novoParagrafo(bundle, "dadosLeitura.valor",
		 * dados.getValor()));
		 * 
		 * StringBuilder secaoDadosBancarios = novaSecao(bundle, "label.dadosleitura");
		 * TreatString.replace("{htmlCampos}", secaoDadosBancarios,
		 * htmlCampos.toString()); TreatString.replace("{secaoDadosLeitura}", template,
		 * secaoDadosBancarios.toString()); } else {
		 * TreatString.replace("{secaoDadosLeitura}", template, ""); }
		 */
		if (TreatString.isNotBlank(solicitacao.getObservacoes())) {
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "solicitacao.observacoes", solicitacao.getObservacoes()));
			StringBuilder secaoDadosBancarios = novaSecao(bundle, "solicitacao.observacoes");
			TreatString.replace("{htmlCampos}", secaoDadosBancarios, htmlCampos.toString());
			TreatString.replace("{secaoObservacoes}", template, secaoDadosBancarios.toString());
		} else {
			TreatString.replace("{secaoObservacoes}", template, "");
		}
		
		//TODO:DEMANDA1313
//		if(tipoServico.getVulneravel()) {
//			StringBuilder htmlCampos = new StringBuilder();
//			htmlCampos.append(novoParagrafo(bundle, "solicitacao.nrFornecimento", solicitacao.getNrFornecimento()));
//			TreatString.replace("{campoNrFornecimento}", template, htmlCampos.toString());
//		} else {
//			TreatString.replace("{campoNrFornecimento}", template, "");
//		}
		
		if (TreatString.isNotBlank(solicitacao.getNrFornecimento())) {
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "solicitacao.nrFornecimento", solicitacao.getNrFornecimento()));
			TreatString.replace("{campoNrFornecimento}", template, htmlCampos.toString());
		} else {
			TreatString.replace("{campoNrFornecimento}", template, "");
		}
			
		if(tipoServico.getAlterarResponsavelContaPFPJ()) {
			
			String declaracao = "Declaro ser inquilino de todas as unidades consumidoras localizadas neste endere�o e abastecidas por este PDE, sendo, portanto, respons�vel pelo pagamento das contas de consumo da liga��o de �gua e/ou esgoto que as abastece. Estou ciente de que, caso deixe de ser respons�vel pelo pagamento das contas do im�vel, ser� necess�rio entrar em contato com a Sabesp para solicitar o encerramento da rela��o contratual, sob pena de se manter respons�vel pelos d�bitos caso n�o avise.";
			
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "solicitacao.declaracao", declaracao));
			TreatString.replace("{campoDeclaracao}", template, htmlCampos.toString());
		} else {
			TreatString.replace("{campoDeclaracao}", template, "");
		}
		
		if(TipoServico.PLA.getCodigo().equals(solicitacao.getTipoServico())) {
			
			String declaracao = "  Declaro que as informa��es prestadas s�o verdadeiras e de minha\r\n" + 
					"responsabilidade. Declaro ainda que as instala��es foram feitas de acordo com as\r\n" + 
					"orienta��es da Sabesp. Se for constatado qualquer diverg�ncia ou necessidade de\r\n" + 
					"documentos adicionais (os quais poder�o ser solicitados via e-mail) o prazo poder� ser\r\n" + 
					"alterado.";
			
			TreatString.replace("{campoAceite}", template, declaracao.toString());
		}
		
		//TODO:DEMANDA1314
		if(TipoServico.PEDIDO_DE_CAIXA_DAGUA.getCodigo().equals(solicitacao.getTipoServico())) {
			
			String declaracao = " <br> "
					+ "- Estou cadastrado na tarifa social unifamiliar ou tarifa vulner�vel; <br>"
					+ "- Estou ciente de que o im�vel est� sujeito a vistoria; <br>"
					+ "- Sou respons�vel pelo bom uso, instala��o e manuten��o da caixa d'�gua; <br>"
					+ "- Que as informa��es prestadas s�o verdadeiras. <br>";
			
			StringBuilder htmlCampos = new StringBuilder();
			htmlCampos.append(novoParagrafo(bundle, "mensagem.declaro.que", declaracao));
			TreatString.replace("{campoPedidoCaixa}", template, htmlCampos.toString());
		} else {
			TreatString.replace("{campoPedidoCaixa}", template, "");
		}
	}

	private StringBuilder novaSecao(ResourceBundle bundle, String tituloI18n) {
		StringBuilder secao = TreatFile.getContent("/templates-email/secao-campos.html");
		TreatString.replace("{titulo}", secao, bundle.getString(tituloI18n));
		return secao;
	}

	private StringBuilder novoParagrafo(ResourceBundle bundle, String labeli18n, Object valor) {
		StringBuilder pCampo = TreatFile.getContent("/templates-email/paragrafo-campo.html");
		TreatString.replace("{label}", pCampo, bundle.getString(labeli18n));
		TreatString.replace("{valor}", pCampo, valor);
		return pCampo;
	}

	@SuppressWarnings("resource")
	private void efetuarEnvioEmail(String assunto, String[] destinatarios, StringBuilder template, String remetente, Termo termo) throws MessagingException, AddressException, NamingException, FileNotFoundException {
		StringBuilder rodape = TreatFile.getContent("/templates-email/rodape.html");
		TreatString.replace("{htmlRodape}", template, rodape);

		String url = Preferencias.get(Propriedades.URL);
		TreatString.replace("{url}", template, url);

		LOG.info("template email [" + template + "]");

		InitialContext context = new InitialContext();
		Session session = (Session) context.lookup(Preferencias.get(Propriedades.EMAIL_NOME_JNDI_SESSION));
		MimeMessage email = new MimeMessage(session);
		for (String dest : destinatarios) {
			email.addRecipients(Message.RecipientType.TO, InternetAddress.parse(dest));
		}
		String replicaTo = null;
		if (TreatString.isNotBlank(replicaTo)) {
			email.setReplyTo(InternetAddress.parse(replicaTo));
		}
		email.setFrom(new InternetAddress(remetente));
		email.setSubject(assunto);

		MimeBodyPart texto = new MimeBodyPart();
		texto.setContent(template.toString(), "text/html; charset=ISO-8859-1");
		//Anexando o Texto e imagem
		MimeBodyPart anexo = null;
		if(termo != null && termo.getTipo() != null) {
			anexo = new MimeBodyPart();
			File file = new File("termo.txt");
			PrintWriter pfile = new PrintWriter(file);
			
			if(termo.getTipo() == 1 || termo.getTipo() == 2) {
				
				pfile.println("Informo que a pessoa abaixo indicada ocupou o im�vel localizado no ");
				pfile.println("endere�o citado acima de " + termo.getData1()  +" a " + termo.getData2()  +", sendo respons�vel pelos ");
				pfile.println("d�bitos do per�odo de " + termo.getData1()  +" a " + termo.getData1()  +":");
				
				pfile.print(" ");
				
				pfile.println("DADOS DO RESPONS�VEL PELOS D�BITOS:");
				
				pfile.print(" ");

				pfile.println("Nome: " + termo.getNome());
				pfile.println("RG: " + termo.getRg());
				pfile.println("CPF: "  + termo.getCpf());
				pfile.println("Telefone:" + termo.getTelefone());
				pfile.println("Endere�o completo (atual):" + termo.getEndereco());
				pfile.println("Data da compra do im�vel: " + termo.getDataCompra());

				
			} else {
				pfile.println("Eu, acima qualificado, informo que ocupo o im�vel acima desde" + termo.getData1()  +", sendo");
				pfile.println("respons�vel pelas contas de consumo deste per�odo e desconhe�o o ocupante do im�vel em outros per�odos.");
				
				pfile.println("Declaro que todas as informa��es acima descritas s�o verdadeiras.");
			}
			
			pfile.flush();
			
			FileDataSource fds = new FileDataSource(file);
			
			anexo.setDataHandler(new DataHandler(fds));
			anexo.setFileName(file.getName());
		}
		
		Multipart corpo = new MimeMultipart();
		
		if(anexo != null) {
			corpo.addBodyPart(anexo);
		}
		corpo.addBodyPart(texto);
		email.setContent(corpo);

		Transport.send(email);
	}
	
	public void enviarEmailFaleConosco(ResourceBundle bundle, FaleConosco faleConosco) {
		FaleConosco edicao = repository.findById(FaleConosco.class, faleConosco.getId());
		if (edicao == null) {
			LOG.error("Solicitacao de fale conosco [" + faleConosco + "] nao foi encontrada na base, talvez ocorreu uma falha para salva-la na base anteriormente");
			return;
		}
		try {
			sendFaleConosco(bundle, faleConosco);
		} catch (Exception e) {
			LOG.error("Falha enviar email solicitacao fale conosco [" + faleConosco + "]", e);
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
		}
	}
	
	private void sendFaleConosco(ResourceBundle bundle, FaleConosco faleConosco) throws AddressException, MessagingException, NamingException, FileNotFoundException {

		String assunto = "SABESP F&Aacute;CIL - Fale Conosco - Protoc&oacute;lo " + faleConosco.getProtocolo();
		String[] destinatarios = new String[] { Preferencias.get(Preferencias.Propriedades.EMAIL_FALE_CONOSCO) };
		
		StringBuilder template = new StringBuilder();

		if(faleConosco.getEmpresa() == null ) {
			template = TreatFile.getContent("/templates-email/solicitacao-fale-conosco.html");
		} else {
			template = TreatFile.getContent("/templates-email/solicitacao-fale-conosco-empresa.html");
		}
		
		TreatString.replace("{protocolo}", template,  faleConosco.getProtocolo());
		TreatString.replace("{rgi}", template, faleConosco.getRgi());
		TreatString.replace("{dataCadastro}", template, TreatDate.formatDefaultDate(faleConosco.getDataCadastro()));
		
		TreatString.replace("{comentario}", template, Comentario.getComentarioByCode(faleConosco.getComentario()));
		TreatString.replace("{assunto}", template, Assunto.getAssuntoByCode(faleConosco.getAssunto()));
		
		TreatString.replace("{tipoPessoa}", template, TipoPessoa.getTipoPessoaByCode(faleConosco.getTipoPessoa()));
		TreatString.replace("{nome}", template, faleConosco.getNome());
		
		if(TipoPessoa.getTipoPessoaByCode(faleConosco.getTipoPessoa()).equals(TipoPessoa.PF)) {
			TreatString.replace("{cpfCnpj}", template, BrasilUtils.formatarCPF(faleConosco.getCpfCnpj()));
		} else {
			TreatString.replace("{cpfCnpj}", template, BrasilUtils.formatarCNPJ(faleConosco.getCpfCnpj()));
		}
		
		TreatString.replace("{telefone}", template, BrasilUtils.formatarTelefoneComDDD(faleConosco.getTelefone()));
		TreatString.replace("{email}", template, faleConosco.getEmail());
		if(faleConosco.getEmpresa() != null ) {
			TreatString.replace("{empresa}", template, faleConosco.getEmpresa());
		} 
		
		TreatString.replace("{nrprotocolo}", template, faleConosco.getProtocoloServico());
		TreatString.replace("{texto}", template, faleConosco.getTexto());

		efetuarEnvioEmail(assunto, destinatarios, template, faleConosco.getEmail(), null);
	}

}
