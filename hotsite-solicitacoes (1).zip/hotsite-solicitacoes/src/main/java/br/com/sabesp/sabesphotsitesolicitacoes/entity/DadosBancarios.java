package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "RESTITUICAO_VALOR_DUPLICIDADE")
public class DadosBancarios implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -2858926054553661695L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;

	@Size(max = 30)
	@Column(name = "NM_INSTITUICAO")
	private String instituicao;

	@Column(name = "CD_TIPO_CONTA")
	private Integer tipoConta;

	@Size(max = 10)
	@Column(name = "NR_AGENCIA")
	private String agencia;

	@Size(max = 15)
	@Column(name = "NR_CONTA")
	private String conta;

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Integer getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(Integer tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getInstituicao() {
		return instituicao;
	}

	public void setInstituicao(String instituicao) {
		this.instituicao = instituicao;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof DadosBancarios)) {
			return false;
		}
		DadosBancarios other = (DadosBancarios) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}
}
