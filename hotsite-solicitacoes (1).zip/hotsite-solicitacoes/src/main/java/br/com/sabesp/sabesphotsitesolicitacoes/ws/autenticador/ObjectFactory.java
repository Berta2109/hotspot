
package br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ExecutaCMEAD_QNAME = new QName("http://cmead.sabesp.com.br/", "executaCMEAD");
    private final static QName _CMEADException_QNAME = new QName("http://cmead.sabesp.com.br/", "CMEADException");
    private final static QName _DesbloquearSenhaResponse_QNAME = new QName("http://cmead.sabesp.com.br/", "desbloquearSenhaResponse");
    private final static QName _DesbloquearSenha_QNAME = new QName("http://cmead.sabesp.com.br/", "desbloquearSenha");
    private final static QName _ExecutaCMEADResponse_QNAME = new QName("http://cmead.sabesp.com.br/", "executaCMEADResponse");
    private final static QName _TrocarSenha_QNAME = new QName("http://cmead.sabesp.com.br/", "trocarSenha");
    private final static QName _TrocarSenhaResponse_QNAME = new QName("http://cmead.sabesp.com.br/", "trocarSenhaResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CMEADException }
     * 
     */
    public CMEADException createCMEADException() {
        return new CMEADException();
    }

    /**
     * Create an instance of {@link ExecutaCMEAD }
     * 
     */
    public ExecutaCMEAD createExecutaCMEAD() {
        return new ExecutaCMEAD();
    }

    /**
     * Create an instance of {@link Webwsto }
     * 
     */
    public Webwsto createWebwsto() {
        return new Webwsto();
    }

    /**
     * Create an instance of {@link DesbloquearSenhaResponse }
     * 
     */
    public DesbloquearSenhaResponse createDesbloquearSenhaResponse() {
        return new DesbloquearSenhaResponse();
    }

    /**
     * Create an instance of {@link TrocarSenhaResponse }
     * 
     */
    public TrocarSenhaResponse createTrocarSenhaResponse() {
        return new TrocarSenhaResponse();
    }

    /**
     * Create an instance of {@link Cmeadto }
     * 
     */
    public Cmeadto createCmeadto() {
        return new Cmeadto();
    }

    /**
     * Create an instance of {@link ExecutaCMEADResponse }
     * 
     */
    public ExecutaCMEADResponse createExecutaCMEADResponse() {
        return new ExecutaCMEADResponse();
    }

    /**
     * Create an instance of {@link TrocarSenha }
     * 
     */
    public TrocarSenha createTrocarSenha() {
        return new TrocarSenha();
    }

    /**
     * Create an instance of {@link Imsshwsto }
     * 
     */
    public Imsshwsto createImsshwsto() {
        return new Imsshwsto();
    }

    /**
     * Create an instance of {@link DesbloquearSenha }
     * 
     */
    public DesbloquearSenha createDesbloquearSenha() {
        return new DesbloquearSenha();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExecutaCMEAD }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "executaCMEAD")
    public JAXBElement<ExecutaCMEAD> createExecutaCMEAD(ExecutaCMEAD value) {
        return new JAXBElement<ExecutaCMEAD>(_ExecutaCMEAD_QNAME, ExecutaCMEAD.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CMEADException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "CMEADException")
    public JAXBElement<CMEADException> createCMEADException(CMEADException value) {
        return new JAXBElement<CMEADException>(_CMEADException_QNAME, CMEADException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesbloquearSenhaResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "desbloquearSenhaResponse")
    public JAXBElement<DesbloquearSenhaResponse> createDesbloquearSenhaResponse(DesbloquearSenhaResponse value) {
        return new JAXBElement<DesbloquearSenhaResponse>(_DesbloquearSenhaResponse_QNAME, DesbloquearSenhaResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesbloquearSenha }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "desbloquearSenha")
    public JAXBElement<DesbloquearSenha> createDesbloquearSenha(DesbloquearSenha value) {
        return new JAXBElement<DesbloquearSenha>(_DesbloquearSenha_QNAME, DesbloquearSenha.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExecutaCMEADResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "executaCMEADResponse")
    public JAXBElement<ExecutaCMEADResponse> createExecutaCMEADResponse(ExecutaCMEADResponse value) {
        return new JAXBElement<ExecutaCMEADResponse>(_ExecutaCMEADResponse_QNAME, ExecutaCMEADResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TrocarSenha }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "trocarSenha")
    public JAXBElement<TrocarSenha> createTrocarSenha(TrocarSenha value) {
        return new JAXBElement<TrocarSenha>(_TrocarSenha_QNAME, TrocarSenha.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TrocarSenhaResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmead.sabesp.com.br/", name = "trocarSenhaResponse")
    public JAXBElement<TrocarSenhaResponse> createTrocarSenhaResponse(TrocarSenhaResponse value) {
        return new JAXBElement<TrocarSenhaResponse>(_TrocarSenhaResponse_QNAME, TrocarSenhaResponse.class, null, value);
    }

}
