
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DetalharResponse_QNAME = new QName("http://crm.sabesp.com.br/", "detalharResponse");
    private final static QName _Detalhar_QNAME = new QName("http://crm.sabesp.com.br/", "detalhar");
    private final static QName _CAPINException_QNAME = new QName("http://crm.sabesp.com.br/", "CAPINException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CapinEntidadePublica }
     * 
     */
    public CapinEntidadePublica createCapinEntidadePublica() {
        return new CapinEntidadePublica();
    }

    /**
     * Create an instance of {@link CapinLigacao }
     * 
     */
    public CapinLigacao createCapinLigacao() {
        return new CapinLigacao();
    }

    /**
     * Create an instance of {@link CapinConsumo }
     * 
     */
    public CapinConsumo createCapinConsumo() {
        return new CapinConsumo();
    }

    /**
     * Create an instance of {@link CAPINException }
     * 
     */
    public CAPINException createCAPINException() {
        return new CAPINException();
    }

    /**
     * Create an instance of {@link CapinHidrometro }
     * 
     */
    public CapinHidrometro createCapinHidrometro() {
        return new CapinHidrometro();
    }

    /**
     * Create an instance of {@link CapinEconomia }
     * 
     */
    public CapinEconomia createCapinEconomia() {
        return new CapinEconomia();
    }

    /**
     * Create an instance of {@link DetalharResponse }
     * 
     */
    public DetalharResponse createDetalharResponse() {
        return new DetalharResponse();
    }

    /**
     * Create an instance of {@link CapinProjeto }
     * 
     */
    public CapinProjeto createCapinProjeto() {
        return new CapinProjeto();
    }

    /**
     * Create an instance of {@link CapinFaturamento }
     * 
     */
    public CapinFaturamento createCapinFaturamento() {
        return new CapinFaturamento();
    }

    /**
     * Create an instance of {@link Capinwsto }
     * 
     */
    public Capinwsto createCapinwsto() {
        return new Capinwsto();
    }

    /**
     * Create an instance of {@link Detalhar }
     * 
     */
    public Detalhar createDetalhar() {
        return new Detalhar();
    }

    /**
     * Create an instance of {@link Webwsto }
     * 
     */
    public Webwsto createWebwsto() {
        return new Webwsto();
    }

    /**
     * Create an instance of {@link CapinLeitura }
     * 
     */
    public CapinLeitura createCapinLeitura() {
        return new CapinLeitura();
    }

    /**
     * Create an instance of {@link CacbyEndereco }
     * 
     */
    public CacbyEndereco createCacbyEndereco() {
        return new CacbyEndereco();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DetalharResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://crm.sabesp.com.br/", name = "detalharResponse")
    public JAXBElement<DetalharResponse> createDetalharResponse(DetalharResponse value) {
        return new JAXBElement<DetalharResponse>(_DetalharResponse_QNAME, DetalharResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Detalhar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://crm.sabesp.com.br/", name = "detalhar")
    public JAXBElement<Detalhar> createDetalhar(Detalhar value) {
        return new JAXBElement<Detalhar>(_Detalhar_QNAME, Detalhar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CAPINException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://crm.sabesp.com.br/", name = "CAPINException")
    public JAXBElement<CAPINException> createCAPINException(CAPINException value) {
        return new JAXBElement<CAPINException>(_CAPINException_QNAME, CAPINException.class, null, value);
    }

}
