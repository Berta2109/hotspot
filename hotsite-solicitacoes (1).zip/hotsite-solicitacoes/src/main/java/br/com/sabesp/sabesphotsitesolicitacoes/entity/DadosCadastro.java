package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatDate;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "ATUALIZACAO_DADOS_CADASTRAIS")
public class DadosCadastro implements Serializable {

    private static final long serialVersionUID = -989091742311630860L;

    @Id
    @OneToOne
    @JoinColumn(name = "CD_SOLICITACAO_SERVICO")
    private SolicitacaoServico solicitacao;

    @Size(max = 100)
    @Column(name = "NM_ATUALIZACAO")
    private String nome;

    @Size(max = 11)
    @Column(name = "NR_TEL_CELULAR_ATUALIZACAO")
    private String telefoneCelular;

    @Column(name = "IN_REPRESENTANTE_LEGAL")
    private Boolean representanteLegal;

    @NotNull
    @Column(name = "CD_TIPO_SOLICITANTE")
    private Integer tipo;

    public void setTipo(Integer tipo) {
        this.tipo = tipo != null && tipo.equals(7) ? 1 : 2;
    }

    public Integer getTipo() {
        return tipo;
    }

    public void setRepresentanteLegal(Boolean representanteLegal) {
        this.representanteLegal = representanteLegal;
    }

    public Boolean getRepresentanteLegal() {
        return representanteLegal;
    }

    @Transient
    @Size(max=20)
    private String telefoneCelularTr;

    public String getDataNascimentoStr() {
        return dataNascimentoStr;
    }

    public void setDataNascimentoStr(String dataNascimentoStr) {
        this.dataNascimentoStr = dataNascimentoStr;
    }

    @Transient
    @Size(max = 10)
    private String dataNascimentoStr;

    @Size(max = 11)
    @Column(name = "NR_TEL_FIXO_ATUALIZACAO")
    private String telefoneFixo;

    public void setTelefoneCelularTr(String telefoneCelularTr) {
        this.telefoneCelularTr = telefoneCelularTr;
    }

    public void setTelefoneFixoTr(String telefoneFixoTr) {
        this.telefoneFixoTr = telefoneFixoTr;
    }

    public String getTelefoneCelularTr() {
        return telefoneCelularTr;
    }

    public String getTelefoneFixoTr() {
        return telefoneFixoTr;
    }

    @Transient
    @Size(max=20)
    private String telefoneFixoTr;

    @Column(name = "DT_NASCIMENTO_ATUALIZACAO")
    private Date dataNascimento;

    @Size(max = 100)
    @Column(name = "DC_EMAIL_ATUALIZACAO")
    private String email;

    @Size(max = 100)
    @Column(name = "DC_LOGRADOURO_ATUALIZACAO")
    private String logradouro;

    @Size(max = 20)
    @Column(name = "NR_ATUALIZACAO")
    private String numero;

    @Size(max = 20)
    @Column(name = "DC_COMPLEMENTO_ATUALIZACAO")
    private String complemento;

    @Size(max = 50)
    @Column(name = "DC_BAIRRO_ATUALIZACAO")
    private String bairro;

    @Size(max = 10)
    @Column(name = "NR_CEP_ATUALIZACAO")
    private String cep;

    @Size(max = 50)
    @Column(name = "DC_CIDADE_ATUALIZACAO")
    private String cidade;
    
    @Column(name = "DT_LEITURA")
    private Date dataLeitura;
    
    @Size(max = 100)
    @Column(name = "VALOR_LEITURA")
    private String valorLeitura;
    
    @Transient
    @Size(max = 10)
    private String dataLeituraStr;
    
    public Date getDataLeitura() {
		return dataLeitura;
	}

	public void setDataLeitura(Date dataLeitura) {
		this.dataLeitura = dataLeitura;
	}

	public String getValorLeitura() {
		return valorLeitura;
	}

	public void setValorLeitura(String valorLeitura) {
		this.valorLeitura = valorLeitura;
	}

	public String getDataLeituraStr() {
        return TreatDate.format("dd/MM/yyyy", new Date());
    }

    public void setDataLeituraStr(String dataLeituraStr) {
        this.dataLeituraStr = dataLeituraStr;
    }
    
    public SolicitacaoServico getSolicitacao() {
        return solicitacao;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefoneCelular() {
        return telefoneCelular;
    }

    public String getTelefoneFixo() {
        return telefoneFixo;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public String getEmail() {
        return email;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCep() {
        return cep;
    }

    public String getCidade() {
        return cidade;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof DadosBancarios)) {
            return false;
        }
        DadosBancarios other = (DadosBancarios) obj;
        if (solicitacao == null) {
            if (other.getSolicitacao() != null) {
                return false;
            }
        } else if (!solicitacao.equals(other.getSolicitacao())) {
            return false;
        }
        return true;
    }

    public void setSolicitacao(SolicitacaoServico solicitacao) {
        this.solicitacao = solicitacao;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTelefoneCelular(String telefoneCelular) {
        this.telefoneCelular = telefoneCelular;
    }

    public void setTelefoneFixo(String telefoneFixo) {
        this.telefoneFixo = telefoneFixo;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public boolean validarTelefoneUnico() {
        if ((this.getTelefoneCelularTr() == null) && (this.getTelefoneFixoTr() == null)) {
            return false;
        }

        if ((this.getTelefoneCelularTr().isEmpty()) && (this.getTelefoneFixoTr().isEmpty())) {
            return false;
        }

        return true;
    }
}
