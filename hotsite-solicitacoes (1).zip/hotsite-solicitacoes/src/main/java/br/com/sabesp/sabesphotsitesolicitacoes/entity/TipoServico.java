package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import br.com.sabesp.sabesphotsitesolicitacoes.business.StatusEnvioEmail;

/**
 * @author Renan
 */
public enum TipoServico {
	//TODO:DEMANDA1313
//	TARIFA_RESIDENCIAL_VULNERAVEL(19, "servicos.info.tarifaresidencialvulneravel", "TRV", 0, "D"),
	
	//TODO:DEMANDA1314
	PEDIDO_DE_CAIXA_DAGUA(20, "servicos.info.pedidocaixadagua", "PCDA", 0, "A"),
	
	DOACAO_POR_MEIO_CONTA_AGUA(11, "servicos.info.doacaopormeiocontaagua", "DPMCA", 1, "D"),
	
	ALTERAR_RESPONSAVEL_CONTA_PF_PJ (18, "servicos.info.alterarresponsavelcontapfpj", "ARCPFPJ", 2, "B"),
	
	DESASSOCIACAO_TITUL_PJ_E_PF (16, "servicos.info.desassociacaotitulpjepf", "DTPP", 3, "A"),
	
	SUPRESSAO_PEDIDO_RELIGACAO_IMOVEL(2, "servicos.info.supressaopedidoreligacaoimovel", "SPRIV", 4, "D"),
	
	CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS(10, "servicos.info.cadastrounidadeconsumomais7economias", "CUCM7E", 5, "B"),

	INFORMAR_PAGAMENTO_CONTAS_SUPERIOR10DIAS(4, "servicos.info.informarpagamentocontassuperior10dias", "IPCS10D", 6, "B"),

	RESTITUICAO_VALORES_PAGOS_DUPLICIDADE(3, "servicos.info.restituicaovalorespagosduplicidade", "RVPD", 7, "B"),

	TRANSFERENCIA_TITULARIDADE_DEBITOS(1, "servicos.info.transferenciatitularidadedebitos", "TTD", 8, "B"),

//	CORRECAO_LEITURA_POR_MEDIA(5, "servicos.info.correcaoleiturapormedia", "CLM", 6, "C"),

	ATESTADOS(6, "servicos.info.atestados", "AT", 9, "A"),

	ENTIDADES_DE_ASSISTENCIA_SOCIAL(8, "servicos.info.entidadesdeassistenciasocial", "EAS", 10, "B"),
	
	TARIFA_SOCIAL_HABITACAO_COLETIVA(9,"servicos.info.tarifasocialhabitacaocoletiva", "TSHC", 11, "B"),
	
	TARIFA_SOCIAL_RESIDENCIA_UNIFAMILIAR(13,"servicos.info.tarifasocialresidenciaunifamiliar", "TSRU", 12, "A"),
	
	TARIFA_SOCIAL_PARA_DESEMPREGADOS(14,"servicos.info.tarifasocialparadesempregados", "TSPD", 13, "A"),

	CERTIDAO_ESGOTAMENTO_SANITARIO(7, "servicos.info.certidaoesgotamentosanitario", "CES", 14, "C"),
	
	PLA(19,"servicos.info.pla", "PLA", 15, "A");

//	ATUALIZAR_DADOS_CADASTRAIS(12, "servicos.info.atualizardadoscadastrais", "ADC", 14, "B"),
	
//	MODIFICACAO_NA_LIGACAO_AGUA_ESGOTO(15, "servicos.info.modificacaonaligacaoaguaesgoto", "MNLAE", 14),
	
	
//	FALE_CONOSCO(17,"servicos.info.faleconosco", "FC", 16);
	
	;

	private Integer codigo;
	private String key18n;
	private String sigla;
	private Integer ordem;
	private String modeloIdCliente;

	private TipoServico(Integer codigo, String key18n, String sigla, Integer ordem, String modeloIdCliente) {
		this.codigo = codigo;
		this.key18n = key18n;
		this.sigla = sigla;
		this.ordem = ordem;
		this.modeloIdCliente = modeloIdCliente;
	}

	public Boolean getPermiteTrocaTipoSolicitante() {
		return is(TRANSFERENCIA_TITULARIDADE_DEBITOS);
	}
	
	public Boolean getPla() {
		return is(PLA);
	}

	public Boolean getRepresentanteLegalEmail() {
		return is(TRANSFERENCIA_TITULARIDADE_DEBITOS) || is(ATESTADOS)
				|| is(CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS) ;
	}

	public Boolean getUsaAnexosCondicionais() {
		return is(TRANSFERENCIA_TITULARIDADE_DEBITOS) || is(ATESTADOS)
				|| is(CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS) ;
	}

	public Boolean getNecessarioDocumentacao() {
		
		//TODO:DEMANDA1313
//		if(getVulneravel()) {
//			return Boolean.FALSE;
//		}
		
		//TODO:DEMANDA1314
		if(getPedidoCaixaDagua()) {
			return Boolean.FALSE;
		}
		
		return Boolean.TRUE;
	}

	public Boolean getUsaDadosBancariosSolicitante() {
		return is(RESTITUICAO_VALORES_PAGOS_DUPLICIDADE);
	}
	
	public Boolean getTransferenciaDebitos() {
		return is(TRANSFERENCIA_TITULARIDADE_DEBITOS);
	}

	public Boolean getAtualizarDadosCadastrais() {
//		return is(ATUALIZAR_DADOS_CADASTRAIS);
		return false;
	}

	public boolean getUsaTiposAtestado() {
		return is(ATESTADOS);
	}

	public Boolean getUsaTiposBeneficio() {
		return is(ENTIDADES_DE_ASSISTENCIA_SOCIAL);
	}

	public Boolean getUsaTiposSupressao() {
		return is(SUPRESSAO_PEDIDO_RELIGACAO_IMOVEL);
	}
	
	public Boolean getUsaServicosSolicitacao() {
		return false;
	}

	public Boolean getUsaObservacoesSolicitacao() {
		return is(CERTIDAO_ESGOTAMENTO_SANITARIO);
	}
	
	//TODO:DEMANDA1313
//	public Boolean getVulneravel() {
//		return is(TARIFA_RESIDENCIAL_VULNERAVEL);
//	}

	public Boolean getUsaTiposDoacao() {
		return is(DOACAO_POR_MEIO_CONTA_AGUA);
	}
	
	public Boolean getUsaTiposFaleConosco() {
		return false;//is(FALE_CONOSCO);
	}
	
	public Boolean getUsaDesassociacao() {
		return is(DESASSOCIACAO_TITUL_PJ_E_PF);
	}
	
	public Boolean getAlterarResponsavelContaPFPJ() {
		return is(ALTERAR_RESPONSAVEL_CONTA_PF_PJ);
	}

	public Boolean getUsaTiposHabitacao() { return is(CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS);}

	public String getKey18nAntesAnexos() {
//		if (is(SUPRESSAO_PEDIDO_RELIGACAO_IMOVEL)) {
//			return "solicitacao.msg.informativoantesanexos.imovelnaopodeapresentardebitos";
//		}
		
		if(is(TARIFA_SOCIAL_HABITACAO_COLETIVA) ) {
			return"solicitacao.msg.informativoantesanexos.naoapresentadebitos";
		}
		
//		if(is(TARIFA_SOCIAL_PARA_DESEMPREGADOS)) {
//			return "solicitacao.msg.informativoantesanexos.naoapresentardebitosexcetonegocia";
//		}
		return null;
	}
	
	
	public String getKey18nAntesAnexos1() {
		if(is(TARIFA_SOCIAL_HABITACAO_COLETIVA) ) {
			return "solicitacao.msg.informativoantesanexos.imovelsujeitovistoria";
		}
		
//		if(is(TARIFA_SOCIAL_PARA_DESEMPREGADOS)) {
//			return "solicitacao.msg.informativoantesanexos.sertitulardacontahamaisde90dias";
//		}
		return null;
	}
	
	
	public String getKey18nAntesAnexos2() {
		if(is(TARIFA_SOCIAL_HABITACAO_COLETIVA) ) {
			return "solicitacao.msg.informativoantesanexos.validadeporperiodo24meses";
		}
		
//		if(is(TARIFA_SOCIAL_PARA_DESEMPREGADOS)) {
//			return "solicitacao.msg.informativoantesanexos.demissaonaopodejustacausa";
//		}
		
		return null;
	}
	
	public String getKey18nAntesAnexos3() {
//		if(is(TARIFA_SOCIAL_PARA_DESEMPREGADOS)) {
//			return "solicitacao.msg.informativoantesanexos.validadeporperiodo12mesesnaorenovado";
//		}
		
		return null;
	}
	
	public String getKey18nAntesAnexos(TipoSupressaoReligacao tipo) {
		return getKey18nAntesAnexosPorReligacao(tipo);
	}

	String getKey18nAntesAnexosPorReligacao(TipoSupressaoReligacao tipo) {
		if (tipo != null && tipo.getId().equals(1)) {
			return "solicitacao.msg.informativoantesanexos.supressaoapedidoimovelvago";
		}
		return null;
	}

	public String getKey18nAntesDadosObrigatorios() {
		if (is(CERTIDAO_ESGOTAMENTO_SANITARIO)) {
			return "servicos.info.certidaoesgotamentosanitario.informativo";
		}
		return null;
	}

	public Integer getStatusEnvioEmailInicial() {
		return StatusEnvioEmail.PENDENTE_ENVIO.getCodigo();
	}

	public String getAbreviacao() {
		return codigo + "_" + sigla;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public String getKey18n() {
		return key18n;
	}

	public String getSigla() {
		return sigla;
	}

	public boolean is(TipoServico test) {
		return this == test;
	}

	public static TipoServico obter(Integer test) {
		for (TipoServico tipo : values()) {
			if (tipo.getCodigo().equals(test)) {
				return tipo;
			}
		}
		return null;
	}
	
	public Boolean getTarifaSocialUnifamiliar() { 
		return is(TipoServico.TARIFA_SOCIAL_RESIDENCIA_UNIFAMILIAR);
	}
	
	public Boolean getTarifaSocialDesempregado() {
		return is(TipoServico.TARIFA_SOCIAL_PARA_DESEMPREGADOS);
	}
	
	public Boolean getTarifaAssistenciaSocial() {
		return is (TipoServico.ENTIDADES_DE_ASSISTENCIA_SOCIAL);
	}

	public Integer getOrdem() {
		return ordem;
	}
	
	public String getModeloIdCliente() {
		return modeloIdCliente;
	}

	public Boolean getInformaPagamento() {
		return is(TipoServico.INFORMAR_PAGAMENTO_CONTAS_SUPERIOR10DIAS);
	}
	
	//TODO:DEMANDA1314
	public Boolean getPedidoCaixaDagua() {
		return is(TipoServico.PEDIDO_DE_CAIXA_DAGUA);
	}
}
