package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.util.Collection;

public class TreatNull {

	public static Boolean isEq(Object valor, Object valor2) {
		return trataNull(valor).equals(trataNull(valor2));
	}

	private static Object trataNull(Object valor) {
		if (valor == null) {
			return "null";
		}
		return valor;
	}

	public static <T> T first(Collection<T> test) {
		if (test == null) {
			return null;
		}
		if(test.iterator().hasNext()) {
			return test.iterator().next();
		}
		return null;
	}

}
