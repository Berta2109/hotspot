package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.xml.ws.soap.SOAPFaultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.sabesp.sabesphotsitesolicitacoes.util.CustomHandlerResolver;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias.Propriedades;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador.CMEAD;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador.CMEADService;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador.Cmeadto;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador.Webwsto;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.CAPIN;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.CAPINService;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.Capinwsto;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

@Stateless
public class IntegracaoWsBusiness implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 7753309012498203564L;
	private static final Logger LOG = LoggerFactory.getLogger(IntegracaoWsBusiness.class);

	/**
	 * Metodo responsavel por fazer autenticacao com o ws sabesp
	 *
	 * @since 11 de abr de 2020 (Projeto)
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @return
	 */
//	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
//	public Webwsto autenticar() {
//		Boolean integrarWs = Preferencias.getBoolean(Propriedades.INTEGRAR_WS_SABESP, true);
//		if (!integrarWs) {
//			return new Webwsto();
//		}
//		try {
//			Cmeadto input = new Cmeadto();
//
//			input.setUserID(Preferencias.get(Propriedades.AUTENTICADOR_USUARIO));
//			input.setPassword(Preferencias.get(Propriedades.AUTENTICADOR_SENHA));
//			input.setWebwsTO(new Webwsto());
//			input.getWebwsTO().setAmbiente(Preferencias.get(Propriedades.AUTENTICADOR_AMBIENTE));
//
//			Cmeadto retorno = proxyAutenticador().executaCMEAD(input);
//			return retorno.getWebwsTO();
//		} catch (MalformedURLException e) {
//			LOG.error("falha preparo url wsd lautenticar", e);
//			throw new IllegalStateException(e);
//		} catch (Exception e) {
//			LOG.error("falha chamada servico autenticacao", e);
//			throw new IllegalStateException(e);
//		}
//	}

	/**
	 * Metodo responsavel por integrar com o servico que retorna os detalhes do RGI informado
	 * @since 11 de abr de 2020 (Projeto)
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @param autenticacao
	 * @param rgi
	 * @return
	 */
//	public DadosRGI obterDetalhesRGI(Webwsto autenticacao, String rgi) {
//		if (TreatString.isBlank(rgi)) {
//			return null;
//		}
//		Boolean integrarWs = Preferencias.getBoolean(Propriedades.INTEGRAR_WS_SABESP, true);
//		if (!integrarWs) {
//			return null;
//		}
//		try {
//			br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.Webwsto autenticacaoParsed = new br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.Webwsto();
//			autenticacaoParsed.setAmbiente(autenticacao.getAmbiente());
//			autenticacaoParsed.setCodigoLocPara(autenticacao.getCodigoLocPara());
//			autenticacaoParsed.setCodigoMunicipio(autenticacao.getCodigoMunicipio());
//			autenticacaoParsed.setCodigoRegResponsavel(autenticacao.getCodigoRegResponsavel());
//			autenticacaoParsed.setCodigoSabesp(autenticacao.getCodigoSabesp());
//			autenticacaoParsed.setCodigoUnidade(autenticacao.getCodigoUnidade());
//			autenticacaoParsed.setComunicacao(autenticacao.getComunicacao());
//			autenticacaoParsed.setListaDeAcessos(autenticacao.getListaDeAcessos());
//			autenticacaoParsed.setNivel(autenticacao.getNivel());
//			autenticacaoParsed.setOrdem(autenticacao.getOrdem());
//			autenticacaoParsed.setUnidade(autenticacao.getUnidade());
//
//			Capinwsto input = new Capinwsto();
//			input.setRgi(Long.valueOf(rgi));
//			Capinwsto retorno = proxyRgi().detalhar(autenticacaoParsed, input);
//			if (retorno == null) {
//				return null;
//			}
//			DadosRGI dados = new DadosRGI(rgi);
//			dados.setAtendimentoComercialATC(retorno.getAtendComercialATC());
//			
//			if (retorno.getEntidadePublica() != null) {
//			    dados.setCodigoEntidadePublica(retorno.getEntidadePublica().getCodigoEntidade());
//			}
//			
//			if (retorno.getLigacao() != null) {
//			    dados.setSituacaoLigacao(retorno.getLigacao().getSitLigacao());
//			}
//
//			dados.setCodigoCliente(retorno.getCodigoCliente());
//			dados.setCodigoMunicipio(retorno.getAtendComercialCodigo());
//			dados.setCpfCnpjVinculado(obterCpfOuCnpj(retorno));
//			
//			return dados;
//		} catch (MalformedURLException e) {
//			LOG.error("falha preparo url wsdl", e);
//			throw new IllegalStateException(e);
//		} catch (SOAPFaultException e) {
//			if (e.getMessage() != null && e.getMessage().contains("NAO ENCONTRADO")) {
//				return null;
//			}
//			LOG.error("SOAPFaultException chamada servico obterDetalhesRGI", e);
//			throw new IllegalStateException(e);
//		} catch (Exception e) {
//			LOG.error("falha chamada servico obterDetalhesRGI", e);
//			throw new IllegalStateException(e);
//		}
//
//	}
//
//	private String obterCpfOuCnpj(Capinwsto retorno) {
//	    return retorno.getCpf() == null || retorno.getCpf().equals("0") ? retorno.getCnpj() : retorno.getCpf();
//	}
//
//	private CAPIN proxyRgi() throws MalformedURLException {
//		URL wsdlLocation = new URL(Preferencias.get(Preferencias.Propriedades.RGI_URL));
//		CAPINService service = new CAPINService(wsdlLocation);
//		if (Preferencias.getBoolean(Propriedades.HABILIAR_LOG_SOAPMSG)) {
//			service.setHandlerResolver(new CustomHandlerResolver());
//		}
//		return service.getCAPINPort();
//	}
//
//	private CMEAD proxyAutenticador() throws MalformedURLException {
//		URL wsdlLocation = new URL(Preferencias.get(Preferencias.Propriedades.AUTENTICADOR_URL));
//		CMEADService service = new CMEADService(wsdlLocation);
//		if (Preferencias.getBoolean(Propriedades.HABILIAR_LOG_SOAPMSG)) {
//			service.setHandlerResolver(new CustomHandlerResolver());
//		}
//		return service.getCMEADPort();
//	}

}
