
package br.com.sabesp.sabesphotsitesolicitacoes.validator;

import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Feedback;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("cpfCnpjValidator")
public class CpfCnpjValidator implements Validator {

    @Override
    public void validate(FacesContext facesContext, UIComponent uiComponent, Object value)
        throws ValidatorException {

        if (TreatString.isBlank(TreatString.filterOnlyNumber(value))) {
            return;
        }

        if ( !BrasilUtils.isCpfOuCnpjValid(value.toString())) {
            throw new ValidatorException(
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    Feedback.getMsg("custom.validator.cpfCnpjValidator", value.toString()), null));
        }
    }
}
