package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SOLICITACAO_DESASSOCIACAO")
public class Desassociacao implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;
	
	@Column(name = "MOTIVO_ENCERRAMENTO")
	private String motivoEncerramento;

	@Column(name = "IN_REPRESENTANTE_LEGAL")
	private Boolean representateLegal;
	
	@Column(name = "IN_ESTATAL_FEDERAL")
	private Boolean estatalFederal;
	
	
	//Get and Set
	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public String getMotivoEncerramento() {
		return motivoEncerramento;
	}

	public void setMotivoEncerramento(String motivoEncerramento) {
		this.motivoEncerramento = motivoEncerramento;
	}

	public Boolean getRepresentateLegal() {
		return representateLegal;
	}

	public void setRepresentateLegal(Boolean representateLegal) {
		this.representateLegal = representateLegal;
	}

	public Boolean getEstatalFederal() {
		return estatalFederal;
	}

	public void setEstatalFederal(Boolean estatalFederal) {
		this.estatalFederal = estatalFederal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Desassociacao)) {
			return false;
		}
		Desassociacao other = (Desassociacao) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}

}
