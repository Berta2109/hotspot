package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.PixelGrabber;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.zip.GZIPInputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.io.IOUtils;

import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias.Propriedades;

public class TreatFile {

	private TreatFile() {
	}

	public static byte[] parseBase64Binary(String base64) {
		if (TreatString.isBlank(base64)) {
			return null;
		}
		return DatatypeConverter.parseBase64Binary(base64);
	}

	public static String parseFromBase64Zip(String base64) {
		byte[] dataZip = parseBase64Binary(base64);
		if (dataZip == null) {
			return null;
		}
		String text = parseZipToString(dataZip);
		return text;
	}

	public static String parseZipToString(byte[] dataZip) {
		try {
			ByteArrayInputStream in = new ByteArrayInputStream(dataZip);
			BufferedReader reader;
			reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(in)));
			StringBuilder to = new StringBuilder();
			String content;
			while ((content = reader.readLine()) != null) {
				to.append(content);
			}
			return to.toString();
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

//	public static String md5(byte[] from) {
//		InputStream inputStream = new ByteArrayInputStream(from);
//
//		try {
//			MessageDigest digester = MessageDigest.getInstance("MD5");
//
//			byte[] buffer = new byte[4096];
//			int r;
//
//			while ((r = inputStream.read(buffer)) > 0) {
//				digester.update(buffer, 0, r);
//			}
//
//			return bytesToString(digester.digest());
//		} catch (Exception e) {
//			throw new IllegalStateException("Falha gerar md5 from array de bytes");
//		} finally {
//			if (inputStream != null) {
//				try {
//					inputStream.close();
//				} catch (IOException e) {
//				}
//			}
//		}
//	}

	private static String bytesToString(byte[] bytes) {
		String result = "";
		for (int i = 0; i < bytes.length; i++) {
			result += Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1);
		}
		return result;
	}

	/**
	 * @deprecated verificar metodos, se estao mantendo qualidade da imagem
	 */
	public static Image convertToImage(byte[] data) {
		return new ImageIcon(data).getImage();
	}

	/**
	 * @deprecated verificar metodos, se estao mantendo qualidade da imagem
	 */
	public static byte[] resize(Image image, Integer width, Integer height, Integer quality, String imgName) {
		double thumbRatio = width.doubleValue() / height.doubleValue();
		int imageWidth = image.getWidth(null);
		int imageHeight = image.getHeight(null);
		double imageRatio = (double) imageWidth / (double) imageHeight;
		if (thumbRatio < imageRatio) {
			height = (int) (width / imageRatio);
		} else {
			width = (int) (height * imageRatio);
		}
		// Create a buffered image using the default color model
		Integer type = BufferedImage.TYPE_INT_RGB;
		if (hasAlpha(image)) {
			type = BufferedImage.TYPE_INT_ARGB;
		}
		BufferedImage resizedImage = new BufferedImage(width, height, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(image, 0, 0, width, height, null);
		g.dispose();

		g.setComposite(AlphaComposite.Src);

		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);

		try {
			// identifica a extensao do arquivo
			String typeFile = TreatFile.getTypeFile(imgName);
			if (TreatString.isBlank(typeFile)) {
				throw new IllegalArgumentException("Nome do arquivo � inv�lido.");
			}
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, typeFile, out);
			return out.toByteArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static boolean hasAlpha(Image image) {
		// If buffered image, the color model is readily available
		if (image instanceof BufferedImage) {
			BufferedImage bimage = (BufferedImage) image;
			return bimage.getColorModel().hasAlpha();
		}

		// Use a pixel grabber to retrieve the image's color model;
		// grabbing a single pixel is usually sufficient
		PixelGrabber pg = new PixelGrabber(image, 0, 0, 1, 1, false);
		try {
			pg.grabPixels();
		} catch (InterruptedException e) {
		}

		// Get the image's color model
		ColorModel cm = pg.getColorModel();
		if (cm == null) {
			return false;
		}
		return cm.hasAlpha();
	}

	public static final Boolean deleteFile(String file) {
		if (TreatString.isBlank(file)) {
			return false;
		}
		return new File(file).delete();
	}

	public static void saveFile(String caminhoCompleto, byte[] conteudo) {
		try {
			InputStream in = new BufferedInputStream(new ByteArrayInputStream(conteudo));
			OutputStream out = new BufferedOutputStream(new FileOutputStream(caminhoCompleto));
			IOUtils.copyLarge(in, out);
			out.flush();
		} catch (Exception e) {
			throw new IllegalStateException("falha salvar arquivo", e);
		}
	}

	public static final String getTypeFile(String fileName) {
		return fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
	}

	public static StringBuilder obterConteudo(String fileResource) throws UnsupportedEncodingException, IOException {
		return null;
	}

	public static File saveTempFile(String extensao, byte[] data) {
		try {
			File raizTemporario = new File(Preferencias.get(Propriedades.CAMINHO_TEMPORARIO_ANEXOS_SOLICITACAO));
			raizTemporario.mkdirs();
			File file = File.createTempFile("_tmp_", "." + extensao, raizTemporario);
			InputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
			OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
			IOUtils.copy(in, out);
			out.flush();
			return file;
		} catch (IOException e) {
			throw new IllegalStateException("falha salvar arquivo temporario", e);
		}
	}

	public static byte[] getBinario(String caminho) {
		try {
			InputStream in;
			in = new BufferedInputStream(new FileInputStream(new File(caminho)));
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			IOUtils.copyLarge(in, out);
			out.flush();
			return out.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	public static StringBuilder getContent(String fileResource) {
		InputStream in = TreatFile.class.getResourceAsStream(fileResource);
		if (in == null) {
			throw new IllegalArgumentException("Arquivo [" + fileResource + "] nao encontrado");
		}
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(in, "ISO-8859-1"));
			String contentLine = null;
			StringBuilder content = new StringBuilder();
			while ((contentLine = reader.readLine()) != null) {
				content.append(contentLine);
			}
			return content;
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	public static String trocarExtensaoArquivo(String aliasArquivo, String novaExtensao, String... extensoesAIgnorar) {
		String extensaoArquivo = getTypeFile(aliasArquivo);
		if (Arrays.asList(extensoesAIgnorar).contains(extensaoArquivo)) {
			return aliasArquivo;
		}
		return TreatString.replace("." + extensaoArquivo, new StringBuilder(aliasArquivo), "." + novaExtensao).toString();
	}
}