package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "TRANSFERENCIA_TITULARIDADE_DEB")
public class TransferenciaTitularidadeDebitos implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -2858926054553661695L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;

	@NotNull
	@Column(name = "CD_TIPO_SOLICITANTE")
	private Integer tipo;

	@Column(name = "IN_REPRESENTANTE_LEGAL")
	private Boolean representateLegal;

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}

	public Boolean getRepresentateLegal() {
		return representateLegal;
	}

	public void setRepresentateLegal(Boolean representateLegal) {
		this.representateLegal = representateLegal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TransferenciaTitularidadeDebitos)) {
			return false;
		}
		TransferenciaTitularidadeDebitos other = (TransferenciaTitularidadeDebitos) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}

}
