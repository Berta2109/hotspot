package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;
import java.util.Random;

import javax.persistence.Transient;

import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;

public class Anexo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8747595288029328726L;

	private String documentoI18n;
	private String nome;
	private String nomeUnico;
	private String informativoI18n;

	private String caminho;

	private TipoAnexo tipo;

	private Boolean obrigatorio;

	@Transient
	private String caminhoTemporario;
	
	@Transient
	private Boolean exibeAnexo;
	
	private Integer contador;
	
	private Boolean renderizaAnexo;

	public Anexo() {
	}

	public Anexo(TipoAnexo tipo) {
		this.tipo = tipo;
		this.documentoI18n = tipo.getKey18n();
		this.obrigatorio = false;
		this.informativoI18n = tipo.getInformativo18n();
	}

	public Anexo(TipoAnexo tipo, String informativoI18n) {
		this(tipo);
		this.informativoI18n = informativoI18n;
	}

	public Anexo(TipoAnexo tipo, Boolean obrigatorio) {
		this(tipo);
		this.obrigatorio = obrigatorio;
	}
	
	public Anexo(String informativoI18n, TipoAnexo tipo, Boolean obrigatorio) {
		this(tipo);
		this.informativoI18n = informativoI18n;
		this.obrigatorio = obrigatorio;
	}
	
	public Anexo(TipoAnexo tipo, Boolean obrigatorio, Boolean renderizaAnexo) {
		this(tipo);
		this.obrigatorio = obrigatorio;
		this.renderizaAnexo = renderizaAnexo;
	}

	public Boolean getIsInformado() {
		return TreatString.isNotBlank(caminhoTemporario);
	}

	public TipoAnexo getTipo() {
		return tipo;
	}

	public void setTipo(TipoAnexo tipo) {
		this.tipo = tipo;
	}

	public String getCaminho() {
		return caminho;
	}

	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}

	public String getInformativoI18n() {
		return informativoI18n;
	}

	public void setInformativoI18n(String informativoI18n) {
		this.informativoI18n = informativoI18n;
	}

	public String getDocumentoI18n() {
		return documentoI18n;
	}

	public void setDocumentoI18n(String documentoI18n) {
		this.documentoI18n = documentoI18n;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNomeUnico() {
		return nomeUnico;
	}

	public void setNomeUnico(String nomeUnico) {
		this.nomeUnico = nomeUnico;
	}

	public String getCaminhoTemporario() {
		return caminhoTemporario;
	}

	public void setCaminhoTemporario(String caminhoTemporario) {
		this.caminhoTemporario = caminhoTemporario;
	}

	public Boolean getObrigatorio() {
		return obrigatorio;
	}

	public void setObrigatorio(Boolean obrigatorio) {
		this.obrigatorio = obrigatorio;
	}
	public Boolean getExibeAnexo() {
		if(exibeAnexo == null) {
			exibeAnexo = Boolean.TRUE;
		}
		return exibeAnexo;
	}
	public void setExibeAnexo(Boolean exibeAnexo) {
		this.exibeAnexo = exibeAnexo;
	}

//	public Integer getContador() {
//		return new Random().nextInt();
//	}

	public void setContador(Integer contador) {
		this.contador = contador;
	}

	public Boolean getRenderizaAnexo() {
		if(renderizaAnexo == null) {
			renderizaAnexo = false;
		}
		return renderizaAnexo;
	}

	public void setRenderizaAnexo(Boolean renderizaAnexo) {
		this.renderizaAnexo = renderizaAnexo;
	}
}
