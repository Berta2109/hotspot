
package br.com.sabesp.sabesphotsitesolicitacoes.exception;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class SabespFacilServiceException extends SabespFacilException {

    private static final long serialVersionUID = 758993946547205494L;

    public SabespFacilServiceException() {
        this(null);
    }

    public SabespFacilServiceException(String mensagem) {
        super(mensagem);
    }
}
