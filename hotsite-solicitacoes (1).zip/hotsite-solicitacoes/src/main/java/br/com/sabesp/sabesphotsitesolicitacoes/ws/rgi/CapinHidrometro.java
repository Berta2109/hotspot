
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for capinHidrometro complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="capinHidrometro">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CPH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CPHLig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cavaleteLocal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cavaleteTipo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataInstalacao" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataRetirada" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="diametroLig" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="qtdDigitos" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="UMA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="validade" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "capinHidrometro", propOrder = {
    "cph",
    "cphLig",
    "cavaleteLocal",
    "cavaleteTipo",
    "codigo",
    "dataInstalacao",
    "dataRetirada",
    "diametroLig",
    "qtdDigitos",
    "uma",
    "validade"
})
public class CapinHidrometro {

    @XmlElement(name = "CPH")
    protected String cph;
    @XmlElement(name = "CPHLig")
    protected String cphLig;
    protected String cavaleteLocal;
    protected String cavaleteTipo;
    protected String codigo;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataInstalacao;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataRetirada;
    protected Integer diametroLig;
    protected Integer qtdDigitos;
    @XmlElement(name = "UMA")
    protected String uma;
    protected String validade;

    /**
     * Gets the value of the cph property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPH() {
        return cph;
    }

    /**
     * Sets the value of the cph property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPH(String value) {
        this.cph = value;
    }

    /**
     * Gets the value of the cphLig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPHLig() {
        return cphLig;
    }

    /**
     * Sets the value of the cphLig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPHLig(String value) {
        this.cphLig = value;
    }

    /**
     * Gets the value of the cavaleteLocal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCavaleteLocal() {
        return cavaleteLocal;
    }

    /**
     * Sets the value of the cavaleteLocal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCavaleteLocal(String value) {
        this.cavaleteLocal = value;
    }

    /**
     * Gets the value of the cavaleteTipo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCavaleteTipo() {
        return cavaleteTipo;
    }

    /**
     * Sets the value of the cavaleteTipo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCavaleteTipo(String value) {
        this.cavaleteTipo = value;
    }

    /**
     * Gets the value of the codigo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Sets the value of the codigo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    /**
     * Gets the value of the dataInstalacao property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataInstalacao() {
        return dataInstalacao;
    }

    /**
     * Sets the value of the dataInstalacao property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataInstalacao(XMLGregorianCalendar value) {
        this.dataInstalacao = value;
    }

    /**
     * Gets the value of the dataRetirada property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataRetirada() {
        return dataRetirada;
    }

    /**
     * Sets the value of the dataRetirada property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataRetirada(XMLGregorianCalendar value) {
        this.dataRetirada = value;
    }

    /**
     * Gets the value of the diametroLig property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDiametroLig() {
        return diametroLig;
    }

    /**
     * Sets the value of the diametroLig property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDiametroLig(Integer value) {
        this.diametroLig = value;
    }

    /**
     * Gets the value of the qtdDigitos property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQtdDigitos() {
        return qtdDigitos;
    }

    /**
     * Sets the value of the qtdDigitos property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQtdDigitos(Integer value) {
        this.qtdDigitos = value;
    }

    /**
     * Gets the value of the uma property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUMA() {
        return uma;
    }

    /**
     * Sets the value of the uma property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUMA(String value) {
        this.uma = value;
    }

    /**
     * Gets the value of the validade property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidade() {
        return validade;
    }

    /**
     * Sets the value of the validade property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidade(String value) {
        this.validade = value;
    }

}
