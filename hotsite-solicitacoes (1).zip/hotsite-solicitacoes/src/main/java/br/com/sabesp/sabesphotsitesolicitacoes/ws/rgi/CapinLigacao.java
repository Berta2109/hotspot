
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for capinLigacao complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="capinLigacao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="carencia" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataLigacaoAgua" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataLigacaoEsgoto" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataSupressao" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataSupressaoSist" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="sitLigacao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="situacaoAgua" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="situacaoEsgoto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "capinLigacao", propOrder = {
    "carencia",
    "dataLigacaoAgua",
    "dataLigacaoEsgoto",
    "dataSupressao",
    "dataSupressaoSist",
    "sitLigacao",
    "situacaoAgua",
    "situacaoEsgoto",
    "tl"
})
public class CapinLigacao {

    protected String carencia;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataLigacaoAgua;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataLigacaoEsgoto;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataSupressao;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataSupressaoSist;
    protected String sitLigacao;
    protected String situacaoAgua;
    protected String situacaoEsgoto;
    @XmlElement(name = "TL")
    protected String tl;

    /**
     * Gets the value of the carencia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCarencia() {
        return carencia;
    }

    /**
     * Sets the value of the carencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCarencia(String value) {
        this.carencia = value;
    }

    /**
     * Gets the value of the dataLigacaoAgua property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataLigacaoAgua() {
        return dataLigacaoAgua;
    }

    /**
     * Sets the value of the dataLigacaoAgua property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataLigacaoAgua(XMLGregorianCalendar value) {
        this.dataLigacaoAgua = value;
    }

    /**
     * Gets the value of the dataLigacaoEsgoto property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataLigacaoEsgoto() {
        return dataLigacaoEsgoto;
    }

    /**
     * Sets the value of the dataLigacaoEsgoto property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataLigacaoEsgoto(XMLGregorianCalendar value) {
        this.dataLigacaoEsgoto = value;
    }

    /**
     * Gets the value of the dataSupressao property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataSupressao() {
        return dataSupressao;
    }

    /**
     * Sets the value of the dataSupressao property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataSupressao(XMLGregorianCalendar value) {
        this.dataSupressao = value;
    }

    /**
     * Gets the value of the dataSupressaoSist property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataSupressaoSist() {
        return dataSupressaoSist;
    }

    /**
     * Sets the value of the dataSupressaoSist property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataSupressaoSist(XMLGregorianCalendar value) {
        this.dataSupressaoSist = value;
    }

    /**
     * Gets the value of the sitLigacao property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSitLigacao() {
        return sitLigacao;
    }

    /**
     * Sets the value of the sitLigacao property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSitLigacao(String value) {
        this.sitLigacao = value;
    }

    /**
     * Gets the value of the situacaoAgua property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituacaoAgua() {
        return situacaoAgua;
    }

    /**
     * Sets the value of the situacaoAgua property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituacaoAgua(String value) {
        this.situacaoAgua = value;
    }

    /**
     * Gets the value of the situacaoEsgoto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituacaoEsgoto() {
        return situacaoEsgoto;
    }

    /**
     * Sets the value of the situacaoEsgoto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituacaoEsgoto(String value) {
        this.situacaoEsgoto = value;
    }

    /**
     * Gets the value of the tl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTL() {
        return tl;
    }

    /**
     * Sets the value of the tl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTL(String value) {
        this.tl = value;
    }

}
