package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import java.io.Serializable;

import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;

public class DadosRGI implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1684426465486292382L;

	private boolean origemDadosWs;
	private String numero;
	private String cpfCnpjVinculado;
	private Integer atendimentoComercialATC;
	private Integer codigoEntidadePublica;
	private Integer codigoMunicipio;
	private String codigoCliente;
	private String situacaoLigacao;

	public DadosRGI() {
	}

	public DadosRGI(String numero) {
		super();
		this.numero = numero;
	}
	
	public DadosRGI(Integer atendimentoComercialATC) {
		super();
		this.atendimentoComercialATC = atendimentoComercialATC;
	}
	
	public DadosRGI(Integer atendimentoComercialATC, String numero) {
		super();
		this.atendimentoComercialATC = atendimentoComercialATC;
		this.numero = numero;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	

	public boolean isNaoValidado() {
		return TreatString.isNotBlank(numero);
	}

	public Integer getAtendimentoComercialATC() {
		return atendimentoComercialATC;
	}

	public void setAtendimentoComercialATC(Integer atendimentoComercialATC) {
		this.atendimentoComercialATC = atendimentoComercialATC;
	}

    public String getCpfCnpjVinculado() {
        return cpfCnpjVinculado;
    }

    public void setCpfCnpjVinculado(String cpfCnpjVinculado) {
        this.cpfCnpjVinculado = cpfCnpjVinculado;
    }

    public String getSituacaoLigacao() {
        return situacaoLigacao;
    }

    public void setSituacaoLigacao(String situacaoLigacao) {
        this.situacaoLigacao = situacaoLigacao;
    }
    
    public boolean isLigacaoAtiva() {
        return TreatString.isNotBlank(situacaoLigacao) && (situacaoLigacao.equalsIgnoreCase("O")
                || situacaoLigacao.equalsIgnoreCase("R") || situacaoLigacao.equalsIgnoreCase("C"));
    }
    
    public boolean isEntidadePublica() {
        return codigoEntidadePublica != null && codigoEntidadePublica.intValue() != 0;
    }

    public Integer getCodigoEntidadePublica() {
        return codigoEntidadePublica;
    }

    public void setCodigoEntidadePublica(Integer codigoEntidadePublica) {
        this.codigoEntidadePublica = codigoEntidadePublica;
    }

    public boolean isOrigemDadosWs() {
        return origemDadosWs;
    }

    public void setOrigemDadosWs(boolean origemDadosWs) {
        this.origemDadosWs = origemDadosWs;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public Integer getCodigoMunicipio() {
        return codigoMunicipio;
    }

    public void setCodigoMunicipio(Integer codigoMunicipio) {
        this.codigoMunicipio = codigoMunicipio;
    }
}
