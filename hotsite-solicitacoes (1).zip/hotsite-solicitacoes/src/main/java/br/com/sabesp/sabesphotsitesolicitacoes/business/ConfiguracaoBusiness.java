package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoAtestado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoBeneficio;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoHabitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoOng;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoSupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.util.GenericRepository;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatDate;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Anexo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.ServicoSolicitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.TipoAnexo;


@Stateless
public class ConfiguracaoBusiness implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8909564626553818285L;

	@EJB
	private GenericRepository repository;

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<TipoAtestado> listarTiposAtestado() {
		return repository.search(TipoAtestado.class, "select t from TipoAtestado t where t.id <> 3 and t.id <> 4 order by t.descricao asc");
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<TipoBeneficio> listarTiposBeneficio() {
		return repository.search(TipoBeneficio.class, "select t from TipoBeneficio t order by t.descricao asc");
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<TipoHabitacao> listarTiposHabitacao(){
		return repository.search(TipoHabitacao.class, "select t from TipoHabitacao t where t.id <> 2 order by t.descricao asc");
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<TipoSupressaoReligacao> listarTiposSupressao() {
		return repository.search(TipoSupressaoReligacao.class, "select t from TipoSupressaoReligacao t order by t.descricao asc");
	}
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public ServicoSolicitacao[] listarServicoSolicitacao() {
		return ServicoSolicitacao.values();
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<Anexo> listarDocumentosServico(TipoServico test) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		prepararAnexos(test, anexos);
		return anexos;
	}
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<Anexo> listarDocumentosDesassociacao(String tipo) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		
		if(tipo.equals("1")) {
			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, true));
		} else {
			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, true));
			anexos.add(new Anexo(TipoAnexo.CARTAOCNPJ, true));
			anexos.add(new Anexo(TipoAnexo.CONTRATOSOCIAL, true));
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUALSEHOUVER, false));
		}
		
		return anexos;
	}

	private Collection<Anexo> getTransferenciaTitulariedadeDebitosIptu() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_1));
		return anexos;
	}

	private Collection<Anexo> getTransferenciaTitulariedadeDebitosContratoFirma() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_2, true));
		return anexos;
	}

	private Collection<Anexo> getTransferenciaTitulariedadeDebitosDocumentoPropriedade() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_IPTU_CONTRATO, true));
		
		return anexos;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<Anexo> listarDocumentosTransferenciaTitularidadeDebitos(Integer tipo) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		Collection<Anexo> anexosTransf = tipo.equals(1) ? getTransferenciaTitulariedadeDebitosIptu()
				: tipo.equals(2) ? getTransferenciaTitulariedadeDebitosContratoFirma() : getTransferenciaTitulariedadeDebitosDocumentoPropriedade();

		anexos.addAll(anexosTransf);

		anexos.add(rgRneCpfCnh());

		if (tipo.equals(3)){
			anexos.add(new Anexo(TipoAnexo.TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_2, true));
			anexos.add(new Anexo(TipoAnexo.ENTREGACHAVESOUACAOJUDICIAL, false));
		}
		return anexos;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<Anexo> listarDocumentosUnidadeConsumo(Integer tipo){
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		if (tipo.equals(4)){
			anexos.addAll(getAnexosDocumentoPropriedade());

		} else if (tipo.equals(5)){
			anexos.add (new Anexo(TipoAnexo.PROCURACAOVIGENTE));
			anexos.add(new  Anexo(TipoAnexo.ESTATUTOSOCIALEMPRESA));
		} else {
			anexos.add(new Anexo(TipoAnexo.ATAASSEMBLEIADENTROPRAZO));
		}
		anexos.add(rgCpfOuCnh());
		anexos.add(rgCpfOuCnhOpcional());
		return anexos;
	}

	private Collection<Anexo> getAnexosDocumentoPropriedade() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.DOCUMENTOPROPRIEDADE));
		anexos.add(new Anexo(TipoAnexo.DOCUMENTOPROPRIEDADEIPTU_2, false));
		anexos.add(new Anexo(TipoAnexo.DOCUMENTOPROPRIEDADEIPTU_3, false));
		return anexos;
	}

	private Collection<Anexo> getAnexosContratoLocacaoFirma() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.CONTRATODELOCACAO));
		anexos.add(new Anexo(TipoAnexo.CONTRATODELOCACAO_2, false));
		anexos.add(new Anexo(TipoAnexo.CONTRATODELOCACAO_3, false));
		return anexos;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Collection<TipoOng> listarOngs() {
	    String consulta = "SELECT t FROM TipoOng t WHERE t.dataInicioVigencia <= :_param1 AND (t.dataFimVigencia >= :_param2 OR t.dataFimVigencia IS NULL)";

        return repository.search(TipoOng.class, consulta, TreatDate.minDateTime(new Date()), TreatDate.maxDateTime(new Date()));
    }

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Anexo procuracaoComFirmaReconhecida() {
		return new Anexo(TipoAnexo.PROCURACAOCOMFIRMARECONHECIDA);
	}

	private Anexo rgCpfOuCnh() {
		return new Anexo(TipoAnexo.RGCPFOUCNH);
	}
	
	private Anexo rgCpfCnh() {
		return new Anexo(TipoAnexo.RGCPFCNH, true);
	}
	
	private Anexo rgRneCpfCnh() {
		return new Anexo(TipoAnexo.RGRNECPFCNH, true);
	}
	
	private Anexo rgCpfOuCnhOpcional() {
		return new Anexo(TipoAnexo.RGCPFOUCNHOPCIONAL, false);
	}
	
	private Anexo contaEnergiaAtual170kwhm() {
		return new Anexo(TipoAnexo.CONTAENERGIAATUALATE170KWHM);
	}
	
	private Anexo comprovanteDeRendaAte3SalariosMinimos() {
		return new Anexo(TipoAnexo.COMPROVANTERENDAFAMILIARATE3SALARIOSMINIMOS);
	}
	
	private Anexo comprovanteAreaUtilAte60MetrosQuadrados() {
		return new Anexo(TipoAnexo.COMPROVANTEAREAUTILDOIMOVELATE60METROSQUADRADOS);
	}
	
	private Anexo carteiraProfissionalOuRecisaoContrato() {
		return new Anexo(TipoAnexo.CARTEIRAPROFISSIONALOUTERMORESCISAOCONTRATO);
	}
	
	private Anexo comprovanteSeguroDesemprego() {
		return new Anexo(TipoAnexo.COMPROVANTESEGURODESEMPREGO);
	}
	
	private Anexo comprovanteDeRendaUltimoSalarioAte3SalariosMinimos() {
		return new Anexo(TipoAnexo.COMPROVANTERENDAULTIMOSALRIOATE3MESES);
	}
	
	private Anexo contaAguaAtualMediaConsumo15Dias() {
		return new Anexo(TipoAnexo.CONTADEAGUAATUALCOMMEDIACONSUMO15METROSCUBICOS);
	}
	

	public Anexo documentoTipoHabitacao(Integer tipoHabitacao) {
		Anexo  anexo = null;
		if(tipoHabitacao.equals(1)) {
			anexo = new Anexo(TipoAnexo.HABITACAOCOLETIVA);
		} else if (tipoHabitacao.equals(2)){
			anexo = new Anexo(TipoAnexo.PREDIOCOMMAISSETEUNIDADES);
		} else if (tipoHabitacao.equals(3)){
		 	anexo = new Anexo(TipoAnexo.PREDIOSEMCONDOMINIO);
		} else if (tipoHabitacao.equals(4)){
			anexo = new Anexo(TipoAnexo.COOPERATIVASHABITACIONAIS);
		}
		return anexo;
	}
	
	public Collection<Anexo> adicionarAnexosServicoSolicitacao(ServicoSolicitacao servicoSolicitacao) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		if (servicoSolicitacao!= null && (servicoSolicitacao.getCodigo().equals(4) || servicoSolicitacao.getCodigo().equals(5))) {
			anexos.add(new Anexo(TipoAnexo.RG, true));
			anexos.add(new Anexo(TipoAnexo.CPFCNPJ, true));
			anexos.add(new Anexo(TipoAnexo.DOCUMENTOPROPRIEDADEIMOVEL, true));
		} else {
			anexos.add(new Anexo(TipoAnexo.RG, true));
			anexos.add(new Anexo(TipoAnexo.CPFCNPJ, true));
		}
		return anexos;
	}
	
	public Collection<Anexo> adicionarAnexosTarifaSocialResidenciaUnifamiliar() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(comprovanteDeRendaAte3SalariosMinimos());
		anexos.add(contaEnergiaAtual170kwhm());
		anexos.add(comprovanteAreaUtilAte60MetrosQuadrados());
		anexos.add(rgRneCpfCnh());
		return anexos;
	}
	
	public Collection<Anexo> adicionarAnexosTarifaSocialParaDesempregados() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(carteiraProfissionalOuRecisaoContrato());
		anexos.add(comprovanteSeguroDesemprego());
		anexos.add(contaAguaAtualMediaConsumo15Dias());
		anexos.add(comprovanteDeRendaUltimoSalarioAte3SalariosMinimos());
		anexos.add(rgRneCpfCnh());
		return anexos;
	}

	private void prepararAnexos(TipoServico tipoServico, Collection<Anexo> anexos) {
		if (tipoServico.is(TipoServico.SUPRESSAO_PEDIDO_RELIGACAO_IMOVEL)) {
			anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, true));
			return;
		}
		
		if(tipoServico.is(TipoServico.TARIFA_SOCIAL_RESIDENCIA_UNIFAMILIAR)) {
			anexos.addAll(adicionarAnexosTarifaSocialResidenciaUnifamiliar());
			return;
		}
		
		if(tipoServico.is(TipoServico.TARIFA_SOCIAL_PARA_DESEMPREGADOS)) {
			anexos.addAll(adicionarAnexosTarifaSocialParaDesempregados());
			return;
		}

		/*
		 * if (tipoServico.is(TipoServico.CORRECAO_LEITURA_POR_MEDIA)) {
		 * anexos.add(contaReclamada()); anexos.add(new
		 * Anexo(TipoAnexo.FOTOATUALLEITURAHIDROMETRO)); anexos.add(new
		 * Anexo(TipoAnexo.FOTONUMEROHIDROMETRO)); anexos.add(rgCpfOuCnh());
		 * anexos.add(rgCpfOuCnhOpcional()); return; }
		 */

		if (tipoServico.is(TipoServico.ENTIDADES_DE_ASSISTENCIA_SOCIAL)) {
//			anexos.add(new Anexo(TipoAnexo.CMASCOMAS, "anexosolicitacao.campo.cmascomas.informativo"));

			anexos.add(new Anexo(TipoAnexo.ATAELEICAOMEMBROSDIRETORIA));
			anexos.add(new Anexo(TipoAnexo.FORMULARIOSOLICITACAODONATIVOS));
			anexos.add(new Anexo("anexosolicitacao.campo.crce.informativo", TipoAnexo.CRCE, false));
			// op
			anexos.add(new Anexo(TipoAnexo.COPIACNPJENTIDADEMANTENEDORA, true));

			anexos.add(new Anexo(TipoAnexo.COPIAESTATUTOSOCIAL));
			anexos.add(new Anexo(TipoAnexo.CEBASCMASCOMAS, false));
			anexos.add(new Anexo(TipoAnexo.DECLARACAOCONTENDOUNIDADES));

			anexos.add(rgCpfCnh());
			return;
		}

		if (tipoServico.is(TipoServico.ATESTADOS)){
			anexos.add(rgCpfOuCnhOpcional());
			return;
		}

		if (tipoServico.is(TipoServico.TARIFA_SOCIAL_HABITACAO_COLETIVA)){
			anexos.add(new Anexo(TipoAnexo.OFICIOORGAOIMOVELSITUACAOCARATERSOCIAL));
			anexos.add(rgRneCpfCnh());
			anexos.add(new Anexo(TipoAnexo.CNPJSEHOUVER, false));
			return;
		}

//		if(tipoServico.is(TipoServico.MODIFICACAO_NA_LIGACAO_AGUA_ESGOTO)) {
//			anexos.add(new Anexo(TipoAnexo.RG, true));
//			anexos.add(new Anexo(TipoAnexo.CPFCNPJ, true));
//			return;
//		}
		if (tipoServico.is(TipoServico.CADASTRO_UNIDADE_CONSUMO_MAIS_7_ECONOMIAS)){
			anexos.add(new Anexo(TipoAnexo.RG, false));
			anexos.add(new Anexo(TipoAnexo.CPFCNPJ, false));
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, false));
			anexos.add(new Anexo(TipoAnexo.ESCRITURAESPECIFICACAO, false));
			return;
		}

	}

	private Anexo contaReclamada() {
		return new Anexo(TipoAnexo.CONTARECLAMADA);
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<Anexo> listarDocumentosAtualizarDadosCadastrais(Integer tipo, Integer naturezaJuridicaSolicitante) {
		return (tipo.equals(7)) ?
				getAnexosAtualizarDadosCadastraisPorProprietario(naturezaJuridicaSolicitante) :
				getAnexosAtualizarDadosCadastraisPorLocatario(naturezaJuridicaSolicitante);
	}

	private Collection<Anexo> getAnexosAtualizarDadosCadastraisPorLocatario(Integer naturezaJuridicaSolicitante) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.RG, true));
		anexos.add(new Anexo(TipoAnexo.CPFCNPJ, true));
		
		if(naturezaJuridicaSolicitante.equals(1)) {
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, false));
		} else {
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, false));
		}
		
		return anexos;
	}

	private Collection<Anexo> getAnexosAtualizarDadosCadastraisPorProprietario(Integer naturezaJuridicaSolicitante) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.RG, true));
		anexos.add(new Anexo(TipoAnexo.CPFCNPJ, true));
		
		if(naturezaJuridicaSolicitante.equals(1)) {
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, false));
		} else {
			anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, false));
		}
		return anexos;
	}

	@SuppressWarnings("unused")
	private Collection<Anexo> getAnexosRg() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.RG_1, true));
		anexos.add(new Anexo(TipoAnexo.RG_2, false));
		return anexos;
	}

	@SuppressWarnings("unused")
	private Collection<Anexo> getAnexosCpf() {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.CPF_1, true));
		anexos.add(new Anexo(TipoAnexo.CPF_2, false));
		return anexos;
	}
	
	public Collection<Anexo> listaAnexoRestituicao(boolean rg, boolean cpfCnpj, boolean inscricaoEstadual) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		anexos.add(new Anexo(TipoAnexo.RGRNECPFCNH, rg));
//		anexos.add(new Anexo(TipoAnexo.INSCRICAOESTADUAL, inscricaoEstadual));
		anexos.add(new Anexo( TipoAnexo.COMPROVANTEPAGAMENTO, true));
		anexos.add(new Anexo( TipoAnexo.COMPROVANTEPAGAMENTO, false));
		anexos.add(new Anexo( TipoAnexo.CONTARECLAMADA, true));
		return anexos;
	}

}
