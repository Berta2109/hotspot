package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.util.Iterator;

import javax.faces.application.ViewExpiredException;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;

public class MyExceptionHandler extends ExceptionHandlerWrapper {

	private ExceptionHandler wrapped;

    FacesContext fc;

    public MyExceptionHandler(ExceptionHandler exceptionHandler) {
        wrapped = exceptionHandler;
        fc = FacesContext.getCurrentInstance();
    }

    @Override
    public ExceptionHandler getWrapped() {
        return wrapped;
    }

    @Override
    public void handle() {

        Iterator<ExceptionQueuedEvent> i = super.getUnhandledExceptionQueuedEvents().iterator();

        while (i.hasNext()) {

            Throwable t = i.next().getContext().getException();

            if (t instanceof ViewExpiredException) {
                try {
                    Feedback.jsfError18n("sessao.msg.expirada");
                    fc.getApplication().getNavigationHandler().handleNavigation(fc, null, "viewExpired");
                }
                finally {
                    i.remove();
                }
            }

        }

        // let the parent handle the rest
        getWrapped().handle();
    }
}
