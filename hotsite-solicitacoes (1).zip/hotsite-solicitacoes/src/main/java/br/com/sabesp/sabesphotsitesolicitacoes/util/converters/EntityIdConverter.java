package br.com.sabesp.sabesphotsitesolicitacoes.util.converters;

import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Named;

import br.com.sabesp.sabesphotsitesolicitacoes.util.DescricaoEntidade;


@Named
@FacesConverter(forClass = DescricaoEntidade.class)
public class EntityIdConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if (value != null) {
			return this.getAttributesFrom(component).get(value);
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null && !"".equals(value)) {
			DescricaoEntidade entity = (DescricaoEntidade) value;

			// adiciona item como atributo do componente
			this.addAttribute(component, entity);

			String nome = entity.getDescricao();
			if (nome == null) {
				return "";
			}

			return String.valueOf(nome);
		}

		return (String) value;
	}

	private void addAttribute(UIComponent component, DescricaoEntidade entity) {
		if (entity.getDescricao() == null) {
			return;
		}
		String key = entity.getDescricao().toString();

		this.getAttributesFrom(component).put(key, entity);
	}

	protected Map<String, Object> getAttributesFrom(UIComponent component) {
		return component.getAttributes();
	}

}
