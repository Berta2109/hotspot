
package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "DOACAO_CONTA_AGUA")
public class DoacaoContaAgua implements Serializable {

    private static final long serialVersionUID = -6903243885161184700L;

    @Id
    @SequenceGenerator(name = "SEQ_DOACAO_CONTA_AGUA", sequenceName = "SEQ_DOACAO_CONTA_AGUA", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_DOACAO_CONTA_AGUA")
    @Column(name = "CD_DOACAO_CONTA_AGUA", nullable = false)
    private Long id;

    @Column(name = "CD_TIPO_SERVICO", nullable = false)
    private Integer tipoServico;

    @Column(name = "CD_TIPO_ONG_CSI")
    private Integer codigoTipoOng;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "CD_ATENDIMENTO_COMERCIAL")
    private AtendimentoComercial atendimentoComercial;

    @Column(name = "NR_RGI_PDE", nullable = false)
    private Long rgi;

    @Column(name = "IN_DOACAO_ATIVA", nullable = false)
    private Boolean doacaoAtiva;

    @Column(name = "DT_ADESAO_DOACAO", nullable = false)
    private Date dataDoacao;

    @Column(name = "DT_CANCELAMENTO_DOACAO")
    private Date dataCancelamento;

    @Column(name = "NR_ENDERECO_IP", length = 30, nullable = false)
    private String enderecoIp;

    @Column(name = "SG_TIPO_PESSOA")
    private String tipoPessoa;

    @Column(name = "NR_CPF_CNPJ", length = 14, nullable = false)
    private String cpfCnpj;

    @Column(name = "NM_COMPLETO_TITULAR", length = 100, nullable = false)
    private String nome;

    @Column(name = "NR_TELEFONE_CONTATO", length = 11, nullable = false)
    private String telefone;

    @Column(name = "DC_EMAIL", length = 100, nullable = false)
    private String email;

    @Column(name = "VL_DOACAO", nullable = false)
    private BigDecimal valorDoacao;

    @Column(name = "DC_PROTOCOLO_ATENDIMENTO", length = 30, nullable = false)
    private String protocolo;

    @Transient
    private String codigoCliente;

    @Transient
    private Integer codigoMunicipio;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(Integer tipoServico) {
        this.tipoServico = tipoServico;
    }

    public AtendimentoComercial getAtendimentoComercial() {
        return atendimentoComercial;
    }

    public void setAtendimentoComercial(AtendimentoComercial atendimentoComercial) {
        this.atendimentoComercial = atendimentoComercial;
    }

    public Long getRgi() {
        return rgi;
    }

    public void setRgi(Long rgi) {
        this.rgi = rgi;
    }

    public Boolean getDoacaoAtiva() {
        return doacaoAtiva;
    }

    public void setDoacaoAtiva(Boolean doacaoAtiva) {
        this.doacaoAtiva = doacaoAtiva;
    }

    public Date getDataDoacao() {
        return dataDoacao;
    }

    public void setDataDoacao(Date dataDoacao) {
        this.dataDoacao = dataDoacao;
    }

    public Date getDataCancelamento() {
        return dataCancelamento;
    }

    public void setDataCancelamento(Date dataCancelamento) {
        this.dataCancelamento = dataCancelamento;
    }

    public String getEnderecoIp() {
        return enderecoIp;
    }

    public void setEnderecoIp(String enderecoIp) {
        this.enderecoIp = enderecoIp;
    }

    public String getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public BigDecimal getValorDoacao() {
        return valorDoacao;
    }

    public void setValorDoacao(BigDecimal valorDoacao) {
        this.valorDoacao = valorDoacao;
    }

    public String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(String protocolo) {
        this.protocolo = protocolo;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DoacaoContaAgua other = (DoacaoContaAgua) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

    public Integer getCodigoTipoOng() {
        return codigoTipoOng;
    }

    public void setCodigoTipoOng(Integer codigoTipoOng) {
        this.codigoTipoOng = codigoTipoOng;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public Integer getCodigoMunicipio() {
        return codigoMunicipio;
    }

    public void setCodigoMunicipio(Integer codigoMunicipio) {
        this.codigoMunicipio = codigoMunicipio;
    }
}
