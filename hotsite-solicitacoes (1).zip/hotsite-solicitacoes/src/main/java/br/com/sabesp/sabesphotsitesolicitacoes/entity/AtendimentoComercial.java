package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "ATENDIMENTO_COMERCIAL_EMAIL")
public class AtendimentoComercial {

	@Id
	@Column(name = "CD_ATENDIMENTO_COMERCIAL")
	private Integer id;

	@Column(name = "DC_EMAIL_ATENDIMENTO_COMERCIAL")
	private String email;

	@Column(name="NM_ABREVIADO_ATEND_COMERCIAL")
	private String municipio;

	@Column(name="NM_ATEND_COMERCIAL")
	private String nome;
	
	@Transient
	private String codMunicipio;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCodMunicipio() {
		return codMunicipio;
	}

	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AtendimentoComercial)) {
			return false;
		}
		AtendimentoComercial other = (AtendimentoComercial) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
