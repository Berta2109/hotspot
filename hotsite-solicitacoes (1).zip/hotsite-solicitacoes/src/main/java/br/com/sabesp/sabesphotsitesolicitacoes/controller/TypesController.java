package br.com.sabesp.sabesphotsitesolicitacoes.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;

@Named
@ApplicationScoped
public class TypesController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 7125546313641364150L;

	public Collection<TipoServico> getTiposServico() {
		TipoServico[] todos = TipoServico.values();
		Collection<TipoServico> selecionados = new ArrayList<TipoServico>();
		for (TipoServico tipoServico : todos) {
			if (tipoServico.is(TipoServico.CERTIDAO_ESGOTAMENTO_SANITARIO)) {
				continue;
			}
			
			if(tipoServico.is(TipoServico.PLA)) {
				continue;
			}
			
			selecionados.add(tipoServico);
		}
		
		return selecionados;
	}

}
