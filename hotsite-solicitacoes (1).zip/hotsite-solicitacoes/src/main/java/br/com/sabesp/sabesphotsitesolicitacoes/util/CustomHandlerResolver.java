package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

public class CustomHandlerResolver implements HandlerResolver {

	public CustomHandlerResolver() {
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<Handler> getHandlerChain(PortInfo arg0) {
		List<Handler> list = new ArrayList<Handler>(0);
		list.add(new SoapHandler());
		return list;
	}
}
