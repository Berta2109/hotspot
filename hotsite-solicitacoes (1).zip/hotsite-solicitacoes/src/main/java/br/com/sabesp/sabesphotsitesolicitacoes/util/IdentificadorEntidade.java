package br.com.sabesp.sabesphotsitesolicitacoes.util;

public interface IdentificadorEntidade {
	public String getIdentificador();
}
