package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ENDERECO_PRECADASTRO")
public class EnderecoPreCadastro implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;
	
	@Column(name = "CD_LOGRADOURO")
	private String codlogradouro;
	
	@Column(name = "NUMERO")
    private String numero;
	
	@Column(name = "COMPLEMENTO")
    private String complemento;
	
	@Column(name = "CD_VIZINHO")
    private String codVizinho;
	
	@Column(name = "NUM_PROCESSO")
    private String numProcesso;
	

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public String getCodlogradouro() {
		return codlogradouro;
	}

	public void setCodlogradouro(String codlogradouro) {
		this.codlogradouro = codlogradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getCodVizinho() {
		return codVizinho;
	}

	public void setCodVizinho(String codVizinho) {
		this.codVizinho = codVizinho;
	}

	public String getNumProcesso() {
		return numProcesso;
	}

	public void setNumProcesso(String numProcesso) {
		this.numProcesso = numProcesso;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof EnderecoPreCadastro)) {
			return false;
		}
		EnderecoPreCadastro other = (EnderecoPreCadastro) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}

}
