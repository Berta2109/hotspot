package br.com.sabesp.sabesphotsitesolicitacoes.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.sabesp.sabesphotsitesolicitacoes.business.SolicitacaoBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatNumber;

/**
 * classe responsavel por efetuar o download dos anexos o qual foram enviados no
 * email
 *
 * @author Renan
 *
 */
@WebServlet(urlPatterns = "/publico/solicitacao/anexo")
public class DownloadAnexosSolicitacaoSerlvet extends HttpServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = -4176210316632014251L;

	private static Logger LOG = LoggerFactory.getLogger(DownloadAnexosSolicitacaoSerlvet.class);

	@EJB
	private SolicitacaoBusiness business;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InputStream in = null;
		try {
			File arquivo = business.obterArquivoAnexo(TreatNumber.toLong(request.getParameter("id")), request.getParameter("hash"));
			if (arquivo == null) {
				throw new IllegalArgumentException("Arquivo nao encontrado para download");
			}
			response.setContentType("application/octet-stream");
			response.addHeader("Content-Disposition", "attachment; filename=\"" + arquivo.getName() + "\"");
			in = new BufferedInputStream(new FileInputStream(arquivo));
			IOUtils.copyLarge(in, response.getOutputStream());
			response.getOutputStream().flush();
		} catch (Exception e) {
			LOG.error("falha download arquivo solicitacao", e);
			response.sendError(404, "conteudo nao disponivel");
		} finally {
			IOUtils.closeQuietly(in);
		}
	}

}
