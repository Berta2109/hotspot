package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

import br.com.sabesp.sabesphotsitesolicitacoes.util.GenericRepository;

@Stateless
public class VulneravelBusiness implements Serializable {

	private static final long serialVersionUID = 305547308867984458L;
	private static final String POST_VULNERAVEL = "http://spo-info2626.spo.sabesp.com.br/cadunico/api_consulta";

	@EJB
	private GenericRepository repository;
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Boolean verificarCpfVulneravel(String cpf) throws Exception {
		try {
			URL obj = new URL(POST_VULNERAVEL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json");
			con.addRequestProperty("cpf", cpf);

			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.flush();
			os.close();

			int codResposta = con.getResponseCode();
			if (codResposta == HttpURLConnection.HTTP_ACCEPTED) {
//				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
//				String inputLine;
//				StringBuffer response = new StringBuffer();
//
//				while ((inputLine = in.readLine()) != null) {
//					response.append(inputLine);
//				}
//				in.close();
//				System.out.println(response.toString());
				return Boolean.TRUE; // CPF Elegivel 
			} else {
				return Boolean.FALSE; // CPF n�o elegivel 
			}
		} catch (Exception e) {
			throw new Exception();
		}
	}
	
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Boolean validarFornecimento(String pde, String fornecimento) {
		
		Integer codigo = null;
		
		try {
			String sql = "SELECT " + 
					"	DISTINCT 1 " + 
					"FROM " + 
					"	ora_viario.s_pde@bdi a " + 
					"WHERE " + 
					"	a.cod_pde = ?1 " + 
					"	AND " +
					" a.cod_fornecimento = ?2 ";
	
			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, pde);
			query.setParameter(2, fornecimento);
	
			@SuppressWarnings("unchecked")
			List<Object[]> lista = query.getResultList();
			for (Object object : lista ) {
				codigo = Integer.parseInt(object.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return codigo == null ? true : false;
	}
}
