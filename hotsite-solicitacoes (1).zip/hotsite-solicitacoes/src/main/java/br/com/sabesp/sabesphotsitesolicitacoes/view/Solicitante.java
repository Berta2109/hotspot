package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosBancarios;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosCadastro;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoHabitacao;

public class Solicitante implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 3548026028817565029L;

	@Size(min = 1)
	private String cpf;
	
	@Size(min = 1)
	private String cpfCnpj;

	@NotNull
	@Size(min = 1, max = 100)
	private String nome;

	@NotNull
	@Size(min = 1, max = 20)
	private String telefone;

	@NotNull
	@Size(min = 1, max = 100)
	private String email;

	private Integer tipo;
	private Boolean representanteLegal;
	private Anexo documentoRepresentateLegal;

	private TipoHabitacao tipoHabitacao;
	private Anexo documentoTipoHabitacao;

	private DadosBancarios dadosBancarios;
	private DadosCadastro dadosCadastro;

	public void setDadosCadastro(DadosCadastro dadosCadastro) {
		this.dadosCadastro = dadosCadastro;
	}

	public DadosCadastro getDadosCadastro() {
		return dadosCadastro;
	}

	public DadosBancarios getDadosBancarios() {
		return dadosBancarios;
	}

	public void setDadosBancarios(DadosBancarios dadosBancarios) {
		this.dadosBancarios = dadosBancarios;
	}

	public Anexo getDocumentoRepresentateLegal() {
		return documentoRepresentateLegal;
	}

	public void setDocumentoRepresentateLegal(Anexo documentoRepresentateLegal) {
		this.documentoRepresentateLegal = documentoRepresentateLegal;
	}

	public Boolean getRepresentanteLegal() {
		return representanteLegal;
	}

	public void setRepresentanteLegal(Boolean representanteLegal) {
		this.representanteLegal = representanteLegal;
	}

	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public TipoHabitacao getTipoHabitacao() {
		return tipoHabitacao;
	}

	public void setTipoHabitacao(TipoHabitacao tipoHabitacao) {
		this.tipoHabitacao = tipoHabitacao;
	}

	public Anexo getDocumentoTipoHabitacao() {
		return documentoTipoHabitacao;
	}

	public void setDocumentoTipoHabitacao(Anexo documentoTipoHabitacao) {
		this.documentoTipoHabitacao = documentoTipoHabitacao;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	
}
