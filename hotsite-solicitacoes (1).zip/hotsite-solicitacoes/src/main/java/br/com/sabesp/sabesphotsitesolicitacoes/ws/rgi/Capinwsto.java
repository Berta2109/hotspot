
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for capinwsto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="capinwsto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="atendComercialATC" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="atendComercialCodigo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="autorizaEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="autorizaMsgInstitucional" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="autorizaSms" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bairroLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="celular" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cnpj" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codificacao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoCliente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="complementoLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="consumoMedia" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cpf" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataCadastramento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataNascimento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descricaoDocumento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="economia" type="{http://crm.sabesp.com.br/}capinEconomia" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="enderecoCorrespondencia" type="{http://crm.sabesp.com.br/}cacbyEndereco" minOccurs="0"/>
 *         &lt;element name="entidadePublica" type="{http://crm.sabesp.com.br/}capinEntidadePublica" minOccurs="0"/>
 *         &lt;element name="faturamento" type="{http://crm.sabesp.com.br/}capinFaturamento" minOccurs="0"/>
 *         &lt;element name="hidrometro" type="{http://crm.sabesp.com.br/}capinHidrometro" minOccurs="0"/>
 *         &lt;element name="inscricaoEstadual" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="irregularidade" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="leitura" type="{http://crm.sabesp.com.br/}capinLeitura" minOccurs="0"/>
 *         &lt;element name="ligacao" type="{http://crm.sabesp.com.br/}capinLigacao" minOccurs="0"/>
 *         &lt;element name="logradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="medicaoIndividual" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mes1" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes10" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes11" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes12" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes2" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes3" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes4" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes5" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes6" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes7" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes8" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="mes9" type="{http://crm.sabesp.com.br/}capinConsumo" minOccurs="0"/>
 *         &lt;element name="municipio" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="nomeRazao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numeroDocumento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numeroLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numeroRg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="orgaoExpeditor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="preposicaoLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="projeto" type="{http://crm.sabesp.com.br/}capinProjeto" minOccurs="0"/>
 *         &lt;element name="proprietarioImovel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rgi" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sexo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="telefoneResidencial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoCliente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoDocumento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoPessoaJuridica" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tituloLogradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "capinwsto", propOrder = {
    "atendComercialATC",
    "atendComercialCodigo",
    "autorizaEmail",
    "autorizaMsgInstitucional",
    "autorizaSms",
    "bairroLogradouro",
    "celular",
    "cnpj",
    "codificacao",
    "codigoCliente",
    "codigoLogradouro",
    "complementoLogradouro",
    "consumoMedia",
    "cpf",
    "dataCadastramento",
    "dataNascimento",
    "descricaoDocumento",
    "economia",
    "email",
    "enderecoCorrespondencia",
    "entidadePublica",
    "faturamento",
    "hidrometro",
    "inscricaoEstadual",
    "irregularidade",
    "leitura",
    "ligacao",
    "logradouro",
    "medicaoIndividual",
    "mes1",
    "mes10",
    "mes11",
    "mes12",
    "mes2",
    "mes3",
    "mes4",
    "mes5",
    "mes6",
    "mes7",
    "mes8",
    "mes9",
    "municipio",
    "nomeRazao",
    "numeroDocumento",
    "numeroLogradouro",
    "numeroRg",
    "orgaoExpeditor",
    "preposicaoLogradouro",
    "projeto",
    "proprietarioImovel",
    "rgi",
    "sexo",
    "status",
    "telefoneResidencial",
    "tipoCliente",
    "tipoDocumento",
    "tipoLogradouro",
    "tipoPessoaJuridica",
    "tituloLogradouro"
})
public class Capinwsto {

    protected Integer atendComercialATC;
    protected int atendComercialCodigo;
    protected String autorizaEmail;
    protected String autorizaMsgInstitucional;
    protected String autorizaSms;
    protected String bairroLogradouro;
    protected String celular;
    protected String cnpj;
    protected String codificacao;
    protected String codigoCliente;
    protected String codigoLogradouro;
    protected String complementoLogradouro;
    protected String consumoMedia;
    protected String cpf;
    protected String dataCadastramento;
    protected String dataNascimento;
    protected String descricaoDocumento;
    protected CapinEconomia economia;
    protected String email;
    protected CacbyEndereco enderecoCorrespondencia;
    protected CapinEntidadePublica entidadePublica;
    protected CapinFaturamento faturamento;
    protected CapinHidrometro hidrometro;
    protected String inscricaoEstadual;
    protected String irregularidade;
    protected CapinLeitura leitura;
    protected CapinLigacao ligacao;
    protected String logradouro;
    protected String medicaoIndividual;
    protected CapinConsumo mes1;
    protected CapinConsumo mes10;
    protected CapinConsumo mes11;
    protected CapinConsumo mes12;
    protected CapinConsumo mes2;
    protected CapinConsumo mes3;
    protected CapinConsumo mes4;
    protected CapinConsumo mes5;
    protected CapinConsumo mes6;
    protected CapinConsumo mes7;
    protected CapinConsumo mes8;
    protected CapinConsumo mes9;
    protected Integer municipio;
    protected String nomeRazao;
    protected String numeroDocumento;
    protected String numeroLogradouro;
    protected String numeroRg;
    protected String orgaoExpeditor;
    protected String preposicaoLogradouro;
    protected CapinProjeto projeto;
    protected String proprietarioImovel;
    protected Long rgi;
    protected String sexo;
    protected String status;
    protected String telefoneResidencial;
    protected String tipoCliente;
    protected String tipoDocumento;
    protected String tipoLogradouro;
    protected String tipoPessoaJuridica;
    protected String tituloLogradouro;

    /**
     * Gets the value of the atendComercialATC property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAtendComercialATC() {
        return atendComercialATC;
    }

    /**
     * Sets the value of the atendComercialATC property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAtendComercialATC(Integer value) {
        this.atendComercialATC = value;
    }

    /**
     * Gets the value of the atendComercialCodigo property.
     * 
     */
    public int getAtendComercialCodigo() {
        return atendComercialCodigo;
    }

    /**
     * Sets the value of the atendComercialCodigo property.
     * 
     */
    public void setAtendComercialCodigo(int value) {
        this.atendComercialCodigo = value;
    }

    /**
     * Gets the value of the autorizaEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutorizaEmail() {
        return autorizaEmail;
    }

    /**
     * Sets the value of the autorizaEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutorizaEmail(String value) {
        this.autorizaEmail = value;
    }

    /**
     * Gets the value of the autorizaMsgInstitucional property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutorizaMsgInstitucional() {
        return autorizaMsgInstitucional;
    }

    /**
     * Sets the value of the autorizaMsgInstitucional property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutorizaMsgInstitucional(String value) {
        this.autorizaMsgInstitucional = value;
    }

    /**
     * Gets the value of the autorizaSms property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutorizaSms() {
        return autorizaSms;
    }

    /**
     * Sets the value of the autorizaSms property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutorizaSms(String value) {
        this.autorizaSms = value;
    }

    /**
     * Gets the value of the bairroLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBairroLogradouro() {
        return bairroLogradouro;
    }

    /**
     * Sets the value of the bairroLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBairroLogradouro(String value) {
        this.bairroLogradouro = value;
    }

    /**
     * Gets the value of the celular property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCelular() {
        return celular;
    }

    /**
     * Sets the value of the celular property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCelular(String value) {
        this.celular = value;
    }

    /**
     * Gets the value of the cnpj property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * Sets the value of the cnpj property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCnpj(String value) {
        this.cnpj = value;
    }

    /**
     * Gets the value of the codificacao property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodificacao() {
        return codificacao;
    }

    /**
     * Sets the value of the codificacao property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodificacao(String value) {
        this.codificacao = value;
    }

    /**
     * Gets the value of the codigoCliente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoCliente() {
        return codigoCliente;
    }

    /**
     * Sets the value of the codigoCliente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoCliente(String value) {
        this.codigoCliente = value;
    }

    /**
     * Gets the value of the codigoLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoLogradouro() {
        return codigoLogradouro;
    }

    /**
     * Sets the value of the codigoLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoLogradouro(String value) {
        this.codigoLogradouro = value;
    }

    /**
     * Gets the value of the complementoLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComplementoLogradouro() {
        return complementoLogradouro;
    }

    /**
     * Sets the value of the complementoLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComplementoLogradouro(String value) {
        this.complementoLogradouro = value;
    }

    /**
     * Gets the value of the consumoMedia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumoMedia() {
        return consumoMedia;
    }

    /**
     * Sets the value of the consumoMedia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumoMedia(String value) {
        this.consumoMedia = value;
    }

    /**
     * Gets the value of the cpf property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Sets the value of the cpf property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCpf(String value) {
        this.cpf = value;
    }

    /**
     * Gets the value of the dataCadastramento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataCadastramento() {
        return dataCadastramento;
    }

    /**
     * Sets the value of the dataCadastramento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataCadastramento(String value) {
        this.dataCadastramento = value;
    }

    /**
     * Gets the value of the dataNascimento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataNascimento() {
        return dataNascimento;
    }

    /**
     * Sets the value of the dataNascimento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataNascimento(String value) {
        this.dataNascimento = value;
    }

    /**
     * Gets the value of the descricaoDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescricaoDocumento() {
        return descricaoDocumento;
    }

    /**
     * Sets the value of the descricaoDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescricaoDocumento(String value) {
        this.descricaoDocumento = value;
    }

    /**
     * Gets the value of the economia property.
     * 
     * @return
     *     possible object is
     *     {@link CapinEconomia }
     *     
     */
    public CapinEconomia getEconomia() {
        return economia;
    }

    /**
     * Sets the value of the economia property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinEconomia }
     *     
     */
    public void setEconomia(CapinEconomia value) {
        this.economia = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the enderecoCorrespondencia property.
     * 
     * @return
     *     possible object is
     *     {@link CacbyEndereco }
     *     
     */
    public CacbyEndereco getEnderecoCorrespondencia() {
        return enderecoCorrespondencia;
    }

    /**
     * Sets the value of the enderecoCorrespondencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link CacbyEndereco }
     *     
     */
    public void setEnderecoCorrespondencia(CacbyEndereco value) {
        this.enderecoCorrespondencia = value;
    }

    /**
     * Gets the value of the entidadePublica property.
     * 
     * @return
     *     possible object is
     *     {@link CapinEntidadePublica }
     *     
     */
    public CapinEntidadePublica getEntidadePublica() {
        return entidadePublica;
    }

    /**
     * Sets the value of the entidadePublica property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinEntidadePublica }
     *     
     */
    public void setEntidadePublica(CapinEntidadePublica value) {
        this.entidadePublica = value;
    }

    /**
     * Gets the value of the faturamento property.
     * 
     * @return
     *     possible object is
     *     {@link CapinFaturamento }
     *     
     */
    public CapinFaturamento getFaturamento() {
        return faturamento;
    }

    /**
     * Sets the value of the faturamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinFaturamento }
     *     
     */
    public void setFaturamento(CapinFaturamento value) {
        this.faturamento = value;
    }

    /**
     * Gets the value of the hidrometro property.
     * 
     * @return
     *     possible object is
     *     {@link CapinHidrometro }
     *     
     */
    public CapinHidrometro getHidrometro() {
        return hidrometro;
    }

    /**
     * Sets the value of the hidrometro property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinHidrometro }
     *     
     */
    public void setHidrometro(CapinHidrometro value) {
        this.hidrometro = value;
    }

    /**
     * Gets the value of the inscricaoEstadual property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    /**
     * Sets the value of the inscricaoEstadual property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInscricaoEstadual(String value) {
        this.inscricaoEstadual = value;
    }

    /**
     * Gets the value of the irregularidade property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIrregularidade() {
        return irregularidade;
    }

    /**
     * Sets the value of the irregularidade property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIrregularidade(String value) {
        this.irregularidade = value;
    }

    /**
     * Gets the value of the leitura property.
     * 
     * @return
     *     possible object is
     *     {@link CapinLeitura }
     *     
     */
    public CapinLeitura getLeitura() {
        return leitura;
    }

    /**
     * Sets the value of the leitura property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinLeitura }
     *     
     */
    public void setLeitura(CapinLeitura value) {
        this.leitura = value;
    }

    /**
     * Gets the value of the ligacao property.
     * 
     * @return
     *     possible object is
     *     {@link CapinLigacao }
     *     
     */
    public CapinLigacao getLigacao() {
        return ligacao;
    }

    /**
     * Sets the value of the ligacao property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinLigacao }
     *     
     */
    public void setLigacao(CapinLigacao value) {
        this.ligacao = value;
    }

    /**
     * Gets the value of the logradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogradouro() {
        return logradouro;
    }

    /**
     * Sets the value of the logradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogradouro(String value) {
        this.logradouro = value;
    }

    /**
     * Gets the value of the medicaoIndividual property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicaoIndividual() {
        return medicaoIndividual;
    }

    /**
     * Sets the value of the medicaoIndividual property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicaoIndividual(String value) {
        this.medicaoIndividual = value;
    }

    /**
     * Gets the value of the mes1 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes1() {
        return mes1;
    }

    /**
     * Sets the value of the mes1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes1(CapinConsumo value) {
        this.mes1 = value;
    }

    /**
     * Gets the value of the mes10 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes10() {
        return mes10;
    }

    /**
     * Sets the value of the mes10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes10(CapinConsumo value) {
        this.mes10 = value;
    }

    /**
     * Gets the value of the mes11 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes11() {
        return mes11;
    }

    /**
     * Sets the value of the mes11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes11(CapinConsumo value) {
        this.mes11 = value;
    }

    /**
     * Gets the value of the mes12 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes12() {
        return mes12;
    }

    /**
     * Sets the value of the mes12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes12(CapinConsumo value) {
        this.mes12 = value;
    }

    /**
     * Gets the value of the mes2 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes2() {
        return mes2;
    }

    /**
     * Sets the value of the mes2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes2(CapinConsumo value) {
        this.mes2 = value;
    }

    /**
     * Gets the value of the mes3 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes3() {
        return mes3;
    }

    /**
     * Sets the value of the mes3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes3(CapinConsumo value) {
        this.mes3 = value;
    }

    /**
     * Gets the value of the mes4 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes4() {
        return mes4;
    }

    /**
     * Sets the value of the mes4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes4(CapinConsumo value) {
        this.mes4 = value;
    }

    /**
     * Gets the value of the mes5 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes5() {
        return mes5;
    }

    /**
     * Sets the value of the mes5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes5(CapinConsumo value) {
        this.mes5 = value;
    }

    /**
     * Gets the value of the mes6 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes6() {
        return mes6;
    }

    /**
     * Sets the value of the mes6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes6(CapinConsumo value) {
        this.mes6 = value;
    }

    /**
     * Gets the value of the mes7 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes7() {
        return mes7;
    }

    /**
     * Sets the value of the mes7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes7(CapinConsumo value) {
        this.mes7 = value;
    }

    /**
     * Gets the value of the mes8 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes8() {
        return mes8;
    }

    /**
     * Sets the value of the mes8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes8(CapinConsumo value) {
        this.mes8 = value;
    }

    /**
     * Gets the value of the mes9 property.
     * 
     * @return
     *     possible object is
     *     {@link CapinConsumo }
     *     
     */
    public CapinConsumo getMes9() {
        return mes9;
    }

    /**
     * Sets the value of the mes9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinConsumo }
     *     
     */
    public void setMes9(CapinConsumo value) {
        this.mes9 = value;
    }

    /**
     * Gets the value of the municipio property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMunicipio() {
        return municipio;
    }

    /**
     * Sets the value of the municipio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMunicipio(Integer value) {
        this.municipio = value;
    }

    /**
     * Gets the value of the nomeRazao property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeRazao() {
        return nomeRazao;
    }

    /**
     * Sets the value of the nomeRazao property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeRazao(String value) {
        this.nomeRazao = value;
    }

    /**
     * Gets the value of the numeroDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Sets the value of the numeroDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDocumento(String value) {
        this.numeroDocumento = value;
    }

    /**
     * Gets the value of the numeroLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroLogradouro() {
        return numeroLogradouro;
    }

    /**
     * Sets the value of the numeroLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroLogradouro(String value) {
        this.numeroLogradouro = value;
    }

    /**
     * Gets the value of the numeroRg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroRg() {
        return numeroRg;
    }

    /**
     * Sets the value of the numeroRg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroRg(String value) {
        this.numeroRg = value;
    }

    /**
     * Gets the value of the orgaoExpeditor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgaoExpeditor() {
        return orgaoExpeditor;
    }

    /**
     * Sets the value of the orgaoExpeditor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgaoExpeditor(String value) {
        this.orgaoExpeditor = value;
    }

    /**
     * Gets the value of the preposicaoLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreposicaoLogradouro() {
        return preposicaoLogradouro;
    }

    /**
     * Sets the value of the preposicaoLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreposicaoLogradouro(String value) {
        this.preposicaoLogradouro = value;
    }

    /**
     * Gets the value of the projeto property.
     * 
     * @return
     *     possible object is
     *     {@link CapinProjeto }
     *     
     */
    public CapinProjeto getProjeto() {
        return projeto;
    }

    /**
     * Sets the value of the projeto property.
     * 
     * @param value
     *     allowed object is
     *     {@link CapinProjeto }
     *     
     */
    public void setProjeto(CapinProjeto value) {
        this.projeto = value;
    }

    /**
     * Gets the value of the proprietarioImovel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProprietarioImovel() {
        return proprietarioImovel;
    }

    /**
     * Sets the value of the proprietarioImovel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProprietarioImovel(String value) {
        this.proprietarioImovel = value;
    }

    /**
     * Gets the value of the rgi property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRgi() {
        return rgi;
    }

    /**
     * Sets the value of the rgi property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRgi(Long value) {
        this.rgi = value;
    }

    /**
     * Gets the value of the sexo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * Sets the value of the sexo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSexo(String value) {
        this.sexo = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the telefoneResidencial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelefoneResidencial() {
        return telefoneResidencial;
    }

    /**
     * Sets the value of the telefoneResidencial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelefoneResidencial(String value) {
        this.telefoneResidencial = value;
    }

    /**
     * Gets the value of the tipoCliente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoCliente() {
        return tipoCliente;
    }

    /**
     * Sets the value of the tipoCliente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoCliente(String value) {
        this.tipoCliente = value;
    }

    /**
     * Gets the value of the tipoDocumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * Sets the value of the tipoDocumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoDocumento(String value) {
        this.tipoDocumento = value;
    }

    /**
     * Gets the value of the tipoLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoLogradouro() {
        return tipoLogradouro;
    }

    /**
     * Sets the value of the tipoLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoLogradouro(String value) {
        this.tipoLogradouro = value;
    }

    /**
     * Gets the value of the tipoPessoaJuridica property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoPessoaJuridica() {
        return tipoPessoaJuridica;
    }

    /**
     * Sets the value of the tipoPessoaJuridica property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoPessoaJuridica(String value) {
        this.tipoPessoaJuridica = value;
    }

    /**
     * Gets the value of the tituloLogradouro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTituloLogradouro() {
        return tituloLogradouro;
    }

    /**
     * Sets the value of the tituloLogradouro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTituloLogradouro(String value) {
        this.tituloLogradouro = value;
    }

}
