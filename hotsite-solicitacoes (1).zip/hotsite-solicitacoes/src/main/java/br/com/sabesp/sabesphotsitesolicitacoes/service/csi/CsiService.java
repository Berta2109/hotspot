
package br.com.sabesp.sabesphotsitesolicitacoes.service.csi;

//import com.unisys.jellybeans.IspecModel;

public interface CsiService {

//    boolean isConectado();
//
//    int executar();
//
//    void autorizar();
//
//    IspecModel autorizar(String ispec);
//
//    IspecModel getIspec();
}
