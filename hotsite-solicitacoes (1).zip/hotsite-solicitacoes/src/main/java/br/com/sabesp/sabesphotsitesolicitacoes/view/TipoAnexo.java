package br.com.sabesp.sabesphotsitesolicitacoes.view;

import org.apache.commons.lang3.StringUtils;

public enum TipoAnexo {

	PROCURACAOCOMFIRMARECONHECIDA(1, "anexosolicitacao.campo.procuracaocomfirmareconhecida", StringUtils.EMPTY),//Procura��o com Firma Reconhecida
	RGCPFOUCNH(2, "anexosolicitacao.campo.rgcpfoucnh",StringUtils.EMPTY),//RG, CPF ou CNH - 1
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_1(3, "anexosolicitacao.campo.transferenciatitularidadedebitos.1",StringUtils.EMPTY),//IPTU, Contrato de Compra com firma reconhecida, Escritura ou Matr�cula do Im�vel
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_2(4, "anexosolicitacao.campo.transferenciatitularidadedebitos.firma",StringUtils.EMPTY),//Contrato de Loca��o com firma reconhecida
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_3(5, "anexosolicitacao.campo.transferenciatitularidadedebitos.3", "solicitante.tipo.3.informativo"),//Documento de Propriedade - 1
	COMPROVANTEPAGAMENTOEXTRADOCC(6, "anexosolicitacao.campo.comprovantepagamentoextradocc", StringUtils.EMPTY),//Comprovante de Pagamento ou Extrato da Conta Corrente Completo
	CONTARECLAMADA(7, "anexosolicitacao.campo.contareclamada",StringUtils.EMPTY),//Conta Reclamada
	COMPROVANTEPAG10DIASAPOS(8, "anexosolicitacao.campo.comprovantepag10diasapos",StringUtils.EMPTY),//Comprovante de Pagamento ou Extrato da Conta Corrente da Data do Pagamento at� 10 Dias Ap�s
	FOTOATUALLEITURAHIDROMETRO(9, "anexosolicitacao.campo.fotoatualleiturahidrometro",StringUtils.EMPTY),//Foto da Leitura Atual do Hidr�metro com Identifica��o da Data em que Foi Capturada
	FOTONUMEROHIDROMETRO(10, "anexosolicitacao.campo.fotonumerohidrometro",StringUtils.EMPTY),//Foto do N�mero do Hidr�metro (na frente da parte met�lica do hidr�metro)
	CMASCOMAS(11,  "anexosolicitacao.campo.cmascomas",StringUtils.EMPTY),//CMAS/COMAS
	ATAELEICAOMEMBROSDIRETORIA(12, "anexosolicitacao.campo.ataeleicaomembrosdiretoria",StringUtils.EMPTY),//Ata de elei��o e posse de membros da Diretoria, atualizada e registrada em cart�rio
	FORMULARIOSOLICITACAODONATIVOS(13, "anexosolicitacao.campo.formulariosolicitacaodonativos",StringUtils.EMPTY),
	CRCE(14, "anexosolicitacao.campo.crce",StringUtils.EMPTY),
	COPIACNPJENTIDADEMANTENEDORA(15, "anexosolicitacao.campo.copiacnpjentidademantenedora",StringUtils.EMPTY),
	COPIAESTATUTOSOCIAL(16, "anexosolicitacao.campo.copiaestatutosocial",StringUtils.EMPTY),
	DECLARACAOCONTENDOUNIDADES(17, "anexosolicitacao.campo.declaracaocontendounidades",StringUtils.EMPTY),
	CEBAS(18, "anexosolicitacao.campo.cebas",StringUtils.EMPTY),
	OFICIOORGAOIMOVELSITUACAOCARATERSOCIAL(19, "anexosolicitacao.campo.oficioorgaoimovelsituacaocaratersocial",StringUtils.EMPTY),
	CONTRATODELOCACAO(20,"anexosolicitacao.campo.contratodelocacao",StringUtils.EMPTY),
	ENTREGACHAVESOUACAOJUDICIAL(21, "anexosolicitacao.campo.entregachavesouacaojudicial", StringUtils.EMPTY),
	DOCUMENTOPROPRIEDADE(22,"anexosolicitacao.campo.documentopropriedade", StringUtils.EMPTY),
	PROCURACAOVIGENTE (23, "anexosolicitacao.campo.procuracaovigente", StringUtils.EMPTY),
	ESTATUTOSOCIALEMPRESA(24, "anexosolicitacao.campo.estatutosocialempresa", StringUtils.EMPTY),
	ATAASSEMBLEIADENTROPRAZO(25, "anexosolicitacao.campo.ataassembleiadentroprazo", StringUtils.EMPTY),
	HABITACAOCOLETIVA(26, "anexosolicitacao.campo.habitacaocoletiva", StringUtils.EMPTY),
	PREDIOCOMMAISSETEUNIDADES(27, "anexosolicitacao.campo.prediocommaisseteunidades", StringUtils.EMPTY),
	PREDIOSEMCONDOMINIO(28, "anexosolicitacao.campo.prediosemcondominio", StringUtils.EMPTY),
	COOPERATIVASHABITACIONAIS(29, "anexosolicitacao.campo.cooperativashabitacionais", StringUtils.EMPTY),

	RGCPFOUCNHOPCIONAL(30, "anexosolicitacao.campo.rgcpfoucnhopcional", StringUtils.EMPTY),
	DOCUMENTOPROPRIEDADEIPTU_2(31, "anexosolicitacao.campo.documentoprop.2", StringUtils.EMPTY),
	DOCUMENTOPROPRIEDADEIPTU_3(32, "anexosolicitacao.campo.documentoprop.3", StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_OP_2(33, "anexosolicitacao.campo.transferenciatitularidadedebitos.op.2" ,StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_OP_3(34, "anexosolicitacao.campo.transferenciatitularidadedebitos.op.3", StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_CL_2(35, "anexosolicitacao.campo.transferenciatitularidadedebitos.cl.2", StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_CL_3(36, "anexosolicitacao.campo.transferenciatitularidadedebitos.cl.3", StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_DP_2(37, "anexosolicitacao.campo.transferenciatitularidadedebitos.dp.2", StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_CAMPO_TP_DP_3(38, "anexosolicitacao.campo.transferenciatitularidadedebitos.dp.3", StringUtils.EMPTY),
	CONTRATODELOCACAO_2(39, "anexosolicitacao.campo.contratodelocacao.2", StringUtils.EMPTY),
	CONTRATODELOCACAO_3(40, "anexosolicitacao.campo.contratodelocacao.3", StringUtils.EMPTY),
	RG_1(41, "anexosolicitacao.campo.rg.1", StringUtils.EMPTY),
	RG_2(42, "anexosolicitacao.campo.rg.2", StringUtils.EMPTY),
	CPF_1(43, "anexosolicitacao.campo.cpf.1", StringUtils.EMPTY),
	CPF_2(44, "anexosolicitacao.campo.cpf.2", StringUtils.EMPTY),
	
	//US016
	
	CONTAENERGIAATUALATE170KWHM(45, "anexosolicitacao.campo.contaenergiaatualate170kwhm", StringUtils.EMPTY),
	COMPROVANTERENDAFAMILIARATE3SALARIOSMINIMOS(46, "anexosolicitacao.campo.comprovantederendafamiliarate3salariosminimos", StringUtils.EMPTY),
	COMPROVANTEAREAUTILDOIMOVELATE60METROSQUADRADOS(47, "anexosolicitacao.campo.comprovantedaareautildoimovelate60metrosquadrados", StringUtils.EMPTY),
	COMPROVANTERENDAULTIMOSALRIOATE3MESES(48, "anexosolicitacao.campo.comprovantedarendaultimosalarioate3salariosominimos", StringUtils.EMPTY),
	CONTADEAGUAATUALCOMMEDIACONSUMO15METROSCUBICOS(49, "anexosolicitacao.campo.contadeaguaatualmediaconsumoate15dias", StringUtils.EMPTY),
	COMPROVANTESEGURODESEMPREGO(50, "anexosolicitacao.campo.comprovantedesemprego", StringUtils.EMPTY),
	CARTEIRAPROFISSIONALOUTERMORESCISAOCONTRATO(51, "anexosolicitacao.campo.carteiraprofissionaloutermoderecisaodetrabalho", StringUtils.EMPTY),
	
	//atualizar tela Dados Cadastrais
	RG(52, "anexosolicitacao.campo.rg", StringUtils.EMPTY),
	CPFCNPJ(53, "anexosolicitacao.campo.cpfCnpj", StringUtils.EMPTY),
	INSCRICAOESTADUAL(54, "anexosolicitacao.campo.inscricaoestadual", StringUtils.EMPTY),
	COMPROVANTEPAGAMENTO(55, "anexosolicitacao.campo.comprovantepagamento", StringUtils.EMPTY),
	CONTRATOSOCIALATUALIZADO(56, "anexosolicitacao.campo.contratosocialatualizado", StringUtils.EMPTY),
	RGRNESOCIO(57, "anexosolicitacao.campo.rgrnesocio", StringUtils.EMPTY),
	COMPROVANTEPAGAMENTOAUTENTICADOBANCO(58, "comprovante.pagamento.autenticado.banco", StringUtils.EMPTY),
	DOCUMENTOPROPRIEDADEIMOVEL(59, "anexosolicitacao.campo.documento.propriedade.imovel", StringUtils.EMPTY),
	OFICIO(60, "anexo.oficio", StringUtils.EMPTY),
	ESCRITURAESPECIFICACAO(61, "anexo.escritura.especificacao", StringUtils.EMPTY),
	RGRNECPFCNH(62, "anexosolicitacao.campo.rgcpfoucnhopcional",StringUtils.EMPTY),
	TRANSFERENCIATITULARIDADEDEBITOS_IPTU_CONTRATO(63, "anexosolicitacao.campo.transferenciatitularidadedebitos.iptu.contrato",StringUtils.EMPTY),
	EXTRATOCONTACORRENTEDATAPAGAMENTO10DIAS(64, "anexosolicitacao.campo.extratocontacorrentedata", StringUtils.EMPTY),
	RGCPFCNH(65, "anexosolicitacao.campo.rgcpfcnh", StringUtils.EMPTY),
	CNPJSEHOUVER(66, "anexosolicitacao.campo.cnpjsehouver", StringUtils.EMPTY),
	INSCRICAOESTADUALSEHOUVER(67, "anexosolicitacao.campo.inscricaoestadualsehouver", StringUtils.EMPTY),
	CARTAOCNPJ(68, "anexosolicitacao.campo.cartaocnpj",StringUtils.EMPTY),
	CONTRATOSOCIAL(69, "anexosolicitacao.campo.contratosocial",StringUtils.EMPTY),
	RGRNECPFCNHSOCIO(70, "anexosolicitacao.campo.rgcpfoucnhopcionalsocio", StringUtils.EMPTY),
	CEBASCMASCOMAS(71, "anexosolicitacao.campo.cebascmascomas", StringUtils.EMPTY),
	RGRNE(72, "label.rgrne", StringUtils.EMPTY),
	IPTUCONTRATO(73, "label.iptu.contrato", StringUtils.EMPTY),
	CNPJMEI(74, "label.cnpj.mei", StringUtils.EMPTY),
	RGCPFCNHPRIMEIRA(75, "anexosolicitacao.campo.recpfcnh.primeira", StringUtils.EMPTY),
	FOTO1(76,"primeira.ligacao.foto1", StringUtils.EMPTY),
	FOTO2(77,"primeira.ligacao.foto2", StringUtils.EMPTY),
	FOTO3(78,"primeira.ligacao.foto3", StringUtils.EMPTY),
	FOTO4(79,"primeira.ligacao.foto4", StringUtils.EMPTY),
	FOTO5(80,"primeira.ligacao.foto5", StringUtils.EMPTY),
	FOTO6(81,"primeira.ligacao.foto6", StringUtils.EMPTY),
	FOTO7(82,"primeira.ligacao.foto7", StringUtils.EMPTY),
	FOTO8(83,"primeira.ligacao.foto8", StringUtils.EMPTY),
	RGRNECPFCNHPRIMEIRA(84,"anexosolicitacao.campo.rgrnecpfcnh", StringUtils.EMPTY);
	
	private Integer codigo;
	private String key18n;
	private String informativo18n;

	private TipoAnexo(Integer codigo, String key18n, String informativo18n) {
		this.codigo = codigo;
		this.key18n = key18n;
		this.informativo18n = informativo18n;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public String getKey18n() {
		return key18n;
	}

	public String getInformativo18n() {return informativo18n; }

	public static TipoAnexo get(Integer test) {
		for (TipoAnexo tipo : values()) {
			if (tipo.getCodigo().equals(test)) {
				return tipo;
			}
		}
		return null;
	}
}
