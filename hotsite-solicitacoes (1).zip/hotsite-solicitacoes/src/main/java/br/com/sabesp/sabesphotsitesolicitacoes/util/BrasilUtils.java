package br.com.sabesp.sabesphotsitesolicitacoes.util;

import static br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString.filterOnlyNumber;
import static br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString.formatString;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

/**
 * Classe utilitaria para manipulacao para documentos aplicados no Brasil, cep, cpf, cnpj, etc
 */
public class BrasilUtils {

    public static final Boolean isEmailValid(String email) {
        if (email == null) {
            return false;
        }
        String regex = "^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$";
        return TreatString.isSequenceStringExists(email, regex);
    }

    public static boolean validarDDDTelefone(String ddd) {
        if (TreatString.isBlank(ddd)) {
            return true;
        }

        Integer num = Integer.parseInt(ddd);
        if (num < 11 || num > 99) {
            return false;
        }
        return true;
    }

    public static String validarTelefoneCelular(String telefone) {
        String t = TreatString.filterOnlyNumber(telefone);
        if (TreatString.isBlank(t)) {
            return null;
        }

        // DDD invalido
        if (!validarDDDTelefone(t.substring(0, 2))) {
            return "custom.validator.telefoneValidatorDDD";
        }
        if (t.length() <= 8) {
            return "custom.validator.telefoneValidator";
        }
        return null;
    }

    /**
     * Verifica se o CEP passado � valido
     *
     * @return Boolean
     */
    public static final Boolean isCepValid(String cep) {
        if (TreatString.isBlank(cep)) {
            return false;
        }

        String test = TreatString.filterOnlyNumber(cep);

        if (TreatString.isBlank(test)) {
            return false;
        }

        if (new Integer(test).equals(0)) {
            return false;
        }

        return test.length() == 8;
    }

    public static final Boolean isCpfOuCnpjValid(String cpfCnpj) {
        return TreatString.isNotBlank(cpfCnpj) && cpfCnpj.length() == 14 ? isCPFValid(cpfCnpj) :isCNPJValid(cpfCnpj);
    }

    /**
     * Verifica se o CPF passado � valido
     *
     * @return Boolean
     */
    public static final Boolean isCPFValid(String valor) {
        valor = TreatString.filterOnlyNumber(valor);
        if (TreatString.isBlank(valor) || valor.length() != 11) {
            return false;
        }
        String c = valor.substring(0, 9);
        String dv = valor.substring(9, 11);
        Integer d1 = 0;
        for (Integer i = 0; i < 9; i++) {
            d1 += Integer.parseInt("" + c.charAt(i)) * (10 - i);
        }
        if (d1 == 0) {
            return false;
        }
        d1 = 11 - (d1 % 11);
        if (d1 > 9) {
            d1 = 0;
        }
        if (Integer.parseInt("" + dv.charAt(0)) != d1) {
            return false;
        }
        d1 *= 2;
        for (Integer i = 0; i < 9; i++) {
            d1 += Integer.parseInt("" + c.charAt(i)) * (11 - i);
        }
        d1 = 11 - (d1 % 11);
        if (d1 > 9) {
            d1 = 0;
        }
        if (Integer.parseInt("" + dv.charAt(1)) != d1 || valor.equals("11111111111") || valor
            .equals("22222222222") || valor.equals("33333333333") || valor.equals("44444444444")
            || valor.equals("55555555555") || valor.equals("66666666666") || valor
            .equals("77777777777") || valor.equals("88888888888") || valor.equals("99999999999")) {
            return false;
        }
        return true;
    }

    public static final Boolean isDocumentoValido(String documento) {
        if (TreatString.isBlank(documento)) {
            return false;
        }
        if (documento.length() <= 11) {
            return isCPFValid(documento);
        }
        return isCNPJValid(documento);
    }

    /**
     * Verifica se o CNPJ passado � valido
     *
     * @return Boolean
     */
    public static final Boolean isCNPJValid(String cnpj) {
        if (cnpj == null) {
            return false;
        }
        cnpj = TreatString.filterOnlyNumber(cnpj);
        if (cnpj.length() < 14) {
            return false;
        }
        List<Integer> a = new ArrayList<Integer>();
        Integer b = 0;
        int[] c = new int[]{6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
        for (int i = 0; i < 12; i++) {
            a.add(i, Integer.parseInt(cnpj.charAt(i) + ""));
            b += a.get(i) * c[i + 1];
        }
        int x = 0;
        if ((x = b % 11) < 2) {
            a.add(12, 0);
        } else {
            a.add(12, 11 - x);
        }
        b = 0;
        for (int y = 0; y < 13; y++) {
            b += (a.get(y) * c[y]);
        }
        if ((x = b % 11) < 2) {
            a.add(13, 0);
        } else {
            a.add(13, 11 - x);
        }
        if ((Integer.parseInt("" + cnpj.charAt(12)) != a.get(12).intValue()) || (
            Integer.parseInt("" + cnpj.charAt(13)) != a.get(13).intValue())) {
            return false;
        }
        return true;
    }

    /**
     * Escapa string com o telefone completo (DD) 9999-9999
     *
     * @param telefone - (DD) 9999-9999
     * @return String
     */
    public static String escapeTelefoneComDDD(String telefone) {
        if (TreatString.isBlank(telefone)) {
            return null;
        }
        String telefoneNumber = filterOnlyNumber(telefone);
        if (TreatString.isNotBlank(telefoneNumber) && telefoneNumber.charAt(0) == '0') {
            return telefoneNumber.substring(1, telefoneNumber.length());
        }
        return telefoneNumber;
    }

    /**
     * Trata CNPJ passado, completa com 0 a esquerda ate 14 posicoes e filtra somente numeros
     */
    public static String escapeCNPJ(String cnpj) {
        cnpj = TreatString.filterOnlyNumber(cnpj);
        if (TreatString.isBlank(cnpj)) {
            return null;
        }
        return TreatString.completeZeroToLeft(cnpj, 14);
    }

    /**
     * Trata CPF passado, completa com 0 a esquerda ate 11 posicoes e filtra somente numeros
     */
    public static String escapeCPF(String cpf) {
        cpf = TreatString.filterOnlyNumber(cpf);
        if (TreatString.isBlank(cpf)) {
            return null;
        }
        return TreatString.completeZeroToLeft(cpf, 11);
    }

    /**
     * Obtem o DDD do telefone
     *
     * @param telefone - deve ser escapada usaddo o metodo escapeTelefoneComDDD(String)
     * @return
     */
    public static String getDDD(String telefone) {
        if (TreatString.isBlank(telefone)) {
            return null;
        }
        if (telefone.length() <= 2) {
            return telefone;
        }
        return telefone.substring(0, 2);
    }

    /**
     * Obtem o telefone da String
     *
     * @param telefone - deve ser escapada usaddo o metodo escapeTelefoneComDDD(String)
     * @return
     */
    public static String getTelefone(String telefone) {
        if (TreatString.isBlank(telefone)) {
            return null;
        }
        if (telefone.length() > 2) {
            return telefone.substring(2, telefone.length());
        }
        return "";
    }

    public static String formatarCEP(String cep) {
        cep = TreatString.filterOnlyNumber(cep);
        return formatString(cep, "##.###-###");
    }

    public static String formatarDocumento(Object doc) {
        if (doc == null) {
            return null;
        }
        String parse = filterOnlyNumber(doc.toString());

        if (parse.length() > 11) {
            return formatarCNPJ(parse);
        }
        return formatarCPF(parse);
    }

    public static String formatarCpfCnpj(String cpfCnpj) {
        return StringUtils.length(cpfCnpj) == 11 ? formatarCPF(cpfCnpj) : formatarCNPJ(cpfCnpj);
    }

    public static String formatarCPF(String cpf) {
        cpf = TreatString.filterOnlyNumber(cpf);
        return formatString(cpf, "###.###.###-##");
    }

    public static String formatarCNPJ(String cnpj) {
        cnpj = TreatString.filterOnlyNumber(cnpj);
        return formatString(cnpj, "##.###.###/####-##");
    }

    public static String formatarTelefoneComDDD(String telefone) {
        if (TreatString.isBlank(telefone)) {
            return "";
        }
        telefone = TreatString.filterOnlyNumber(telefone);
        if (TreatString.isBlank(telefone)) {
            return null;
        }
        Long telefoneLong = new Long(telefone);
        if (telefoneLong.toString().length() == 10) {
            return TreatString.formatString(telefoneLong.toString(), "(##) ####-####");
        }
        return TreatString.formatString(telefoneLong.toString(), "(##) #####-####");
    }

    public static String formatarIP(String ip) {
        ip = TreatString.filterOnlyNumber(ip);
        return formatString(ip, "###.###.###.###");
    }
}