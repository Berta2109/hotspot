
package br.com.sabesp.sabesphotsitesolicitacoes.service.csi;

//import com.unisys.jellybeans.IspecModel;
//import com.unisys.jellybeans.ResponseCodePredicates;

import br.com.sabesp.sabesphotsitesolicitacoes.exception.SabespFacilServiceException;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias.Propriedades;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
//import br.com.unisys.eae.CEBroker;
//import br.com.unisys.eae.CEConfig;
//import br.com.unisys.eae.CEException;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.RequestScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RequestScoped
public class CsiServiceApiImpl /* extends CEBroker */ implements CsiService {

	/*
	 * private static final long serialVersionUID = 2261373513290101325L; private
	 * static final String PACKAGE = "com.sabesp"; private static final String
	 * BUNDLE = "jsp"; private static final String[] WEBWS_COLUNAS = { "CDLOCPARA",
	 * "NRLISTA3", "NRORDEM", "CDSABESP", "NRCOMUNIC", "CDREGRESP", "CDMUNIC1",
	 * "NRNIVEL", "SGUNIDADE", "STAMBIENTE" };
	 * 
	 * private static Logger LOGGER =
	 * LoggerFactory.getLogger(CsiServiceApiImpl.class);
	 * 
	 * private String login; private String senha; private Map<String, String>
	 * autorizacao;
	 * 
	 * @PostConstruct public void inicializar() { conectar(); }
	 * 
	 * @PreDestroy public void destruir() { desconectar(); }
	 * private void conectar() { try { this.login =
	 * Preferencias.get(Propriedades.MAINFRAME_CREDENCIAL_LOGIN); this.senha =
	 * Preferencias.get(Propriedades.MAINFRAME_CREDENCIAL_SENHA);
	 * 
	 * connect(criarConfiguracao().getProperties());
	 * 
	 * } catch (CEException excecao) { throw
	 * registrarLogCriarExcecaoFalha("N�o foi poss�vel conectar ao Mainframe",
	 * excecao); } }
	 * 
	 * private CEConfig criarConfiguracao() { CEConfig configuracao = new
	 * CEConfig();
	 * 
	 * String enderecoServidor =
	 * Preferencias.get(Propriedades.MAINFRAME_SERVIDOR_ENDERECO); String
	 * portaServidor = Preferencias.get(Propriedades.MAINFRAME_SERVIDOR_PORTA);
	 * String nomeCsia = Preferencias.get(Propriedades.MAINFRAME_CSIA_NOME);
	 * 
	 * configuracao.setApplication(nomeCsia); configuracao.setPackage(PACKAGE);
	 * configuracao.setBundle(BUNDLE); configuracao.setView(nomeCsia);
	 * configuracao.setHost(enderecoServidor); configuracao.setPort(portaServidor);
	 * configuracao.setTimeout(30000L);
	 * 
	 * return configuracao; }
	 * 
	 * private void desconectar() { try { disconnect(); } catch (CEException
	 * excecao) { LOGGER.error("N�o foi poss�vel desconectar ao Mainframe",
	 * excecao);
	 * 
	 * fecharTransacao(); } }
	 * 
	 * private void fecharTransacao() { try { getTransactionManager().close(); }
	 * catch (IOException excecao) { throw
	 * registrarLogCriarExcecaoFalha("Falha ao fechar a transa��o", excecao); } }
	 * 
	 * @Override public boolean isConectado() { return isConnected(); }
	 * 
	 * @Override public int executar() { try { doTransaction(); } catch (CEException
	 * excecao) { throw
	 * registrarLogCriarExcecaoFalha("Falha ao executar a transa��o", excecao); }
	 * 
	 * return 100; }
	 * 
	 * @Override public void autorizar() { try { loadIspec("CMEAD");
	 * 
	 * setAttribute("STAMBIENTE", "W"); setAttribute("NMUSERID", getLogin());
	 * setAttribute("CDPASSWOR", getSenha());
	 * 
	 * doTransaction();
	 * 
	 * if (!getCurrentIspecName().equals("WEBWS")) { throw new
	 * SabespFacilServiceException(); }
	 * 
	 * carregarAutorizacaoWebWs();
	 * 
	 * } catch (Exception excecao) { throw
	 * registrarLogCriarExcecaoFalha("Falha ao autorizar", excecao); } }
	 * 
	 * private void carregarAutorizacaoWebWs() { try { autorizacao = new
	 * HashMap<String, String>();
	 * 
	 * for (String campo : WEBWS_COLUNAS) { if
	 * (TreatString.isNotBlank(getAttribute(campo))) { autorizacao.put(campo,
	 * getAttribute(campo)); } }
	 * 
	 * loadIspec("WEBWS");
	 * 
	 * for (Entry<String, String> entry : autorizacao.entrySet()) {
	 * setAttribute(entry.getKey(), entry.getValue()); }
	 * 
	 * if (!ResponseCodePredicates.isOK(doTransactionNoThrowable())) { throw new
	 * SabespFacilServiceException(); } } catch (Exception excecao) { throw
	 * registrarLogCriarExcecaoFalha("Falha ao carregar as autoriza��o", excecao); }
	 * }
	 * 
	 * @Override public IspecModel autorizar(String ispec) { try { loadIspec(ispec);
	 * 
	 * return getCurrentIspec();
	 * 
	 * } catch (CEException excecao) { throw
	 * registrarLogCriarExcecaoFalha("Falha ao autorizar", excecao); } }
	 * 
	 * @Override public IspecModel getIspec() { return getCurrentIspec(); }
	 * 
	 * private String getLogin() { return login; }
	 * 
	 * private String getSenha() { return senha; }
	 * 
	 * private SabespFacilServiceException registrarLogCriarExcecaoFalha(String
	 * mensagemLog, Exception excecao) { LOGGER.error(String.format("[CSI] %s",
	 * mensagemLog), excecao);
	 * 
	 * throw new SabespFacilServiceException(excecao.getMessage()); }
	 */
}
