package br.com.sabesp.sabesphotsitesolicitacoes.entity;

public enum Comentario {
	
	ELOGIO(1, "Elogio"),
	SUGESTAO(2, "Sugest�o"),
	DUVIDA(3, "D�vida"),
	CRITICA(4, "Cr�tica"),
	RECLAMACAO(5, "Reclama��o");
	
	private Comentario(Integer codigo, String valor) {
		this.codigo = codigo;
		this.valor = valor;
	}
	
	private final Integer codigo;
	private final String valor;
	
	public Integer getCodigo() {
		return codigo;
	}
	public String getValor() {
		return valor;
	}
	
	public static String getComentarioByCode(Integer code) {
		
		for (Comentario comentario : Comentario.values()) {
			if (comentario.getCodigo().equals(code) || comentario.getCodigo().equals(code))
				return comentario.getValor();
		}
		
		return null;
	}

}
