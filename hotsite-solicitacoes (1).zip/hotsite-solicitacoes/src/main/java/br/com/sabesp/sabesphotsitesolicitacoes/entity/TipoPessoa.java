package br.com.sabesp.sabesphotsitesolicitacoes.entity;

public enum TipoPessoa {
	
	PF (1, "Pessoa F�sica"),
	PJ (2, "Pessoa Jur�dica");
	
	
	private TipoPessoa(Integer codigo, String valor) {
		this.codigo = codigo;
		this.valor = valor;
	}
	
	private final Integer codigo;
	private final String valor;
	
	public Integer getCodigo() {
		return codigo;
	}
	public String getValor() {
		return valor;
	}
	
	public static String getValorTipoPessoaByCode(Integer code) {
		
		for (TipoPessoa tipoPessoa : TipoPessoa.values()) {
			if (tipoPessoa.getCodigo().equals(code) || tipoPessoa.getCodigo().equals(code))
				return tipoPessoa.getValor();
		}
		
		return null;
	}
	
	public static TipoPessoa getTipoPessoaByCode(Integer code) {
		
		for (TipoPessoa tipoPessoa : TipoPessoa.values()) {
			if (tipoPessoa.getCodigo().equals(code) || tipoPessoa.getCodigo().equals(code))
				return tipoPessoa;
		}
		
		return null;
	}

}
