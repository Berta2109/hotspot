package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "PESQUISA_SATISFACAO")
public class PesquisaSatisfacao implements Serializable{

	private static final long serialVersionUID = -340268161760620761L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;
	
	@NotNull
    @Column(name = "NR_NOTA_PESQUISA")
	private Integer notaPesquisa;
	
    @Column(name = "TX_JUSTIFICATIVA_PESQUISA")
	private String justificativaPesquisa;

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Integer getNotaPesquisa() {
		return notaPesquisa;
	}

	public void setNotaPesquisa(Integer notaPesquisa) {
		this.notaPesquisa = notaPesquisa;
	}

	public String getJustificativaPesquisa() {
		return justificativaPesquisa;
	}

	public void setJustificativaPesquisa(String justificativaPesquisa) {
		this.justificativaPesquisa = justificativaPesquisa;
	}
	
}
