
package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;
import java.util.Date;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoOng;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

public class SolicitacaoDoacao implements Serializable {

    private static final long serialVersionUID = -6235011381818457825L;

    private String tipoPessoa;
    private String tipoDoacao;
    private String cpfCnpj;
    private String nomeSolicitante;
    private String telefone;
    private String email;
    private String protocolo;
    private Integer valorDoacao;
    private Date dataCadastro;
    private DadosRGI dados;
    private TipoOng tipoOng;

    public SolicitacaoDoacao() {
        dataCadastro = new Date();
    }

    public String getTipoDoacao() {
        return tipoDoacao;
    }

    public void setTipoDoacao(String tipoDoacao) {
        this.tipoDoacao = tipoDoacao;
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getNomeSolicitante() {
        return nomeSolicitante;
    }

    public void setNomeSolicitante(String nomeSolicitante) {
        this.nomeSolicitante = nomeSolicitante;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getValorDoacao() {
        return valorDoacao;
    }

    public void setValorDoacao(Integer valorDoacao) {
        this.valorDoacao = valorDoacao;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public DadosRGI getDados() {
        return dados;
    }

    public void setDados(DadosRGI dados) {
        this.dados = dados;
    }

    public TipoOng getTipoOng() {
        return tipoOng;
    }

    public void setTipoOng(TipoOng tipoOng) {
        this.tipoOng = tipoOng;
    }

    public boolean isOperacaoDoacao() {
        return tipoDoacao != null && tipoDoacao.equalsIgnoreCase("D");
    }

    public boolean isOperacaoCancelamento() {
        return tipoDoacao != null && tipoDoacao.equalsIgnoreCase("C");
    }

    public String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(String protocolo) {
        this.protocolo = protocolo;
    }

    public String getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }
}
