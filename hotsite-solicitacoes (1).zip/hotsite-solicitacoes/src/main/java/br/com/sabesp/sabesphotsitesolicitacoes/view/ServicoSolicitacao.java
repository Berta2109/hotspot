package br.com.sabesp.sabesphotsitesolicitacoes.view;

public enum ServicoSolicitacao {
	
	REGULARIZACAO_CAVALETE (1, "Regulariza��o de Cavalete"),
	SUBSTITUICAO_LIGACAO_AGUA(2, "Substitui��o de Liga��o de �gua"),
	SUBSTITUICAO_LIGACAO_ESGOTO(3, "Substitui��o de Liga��o de Esgoto"),
	TRANSFORMACAO_LIGACAO_SIMPLES_CAVALETE_MULT(4, "Transforma��o de Liga��o Simples em Cavalete M�ltiplo"),
	INCLUSAO_CAVALETE_MULT(5, "Inclus�o em Cavalete M�ltiplo");
	
	private Integer codigo;
	private String valor;

	private ServicoSolicitacao(Integer codigo, String valor) {
		this.codigo = codigo;
		this.valor = valor;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public String getValor() {
		return valor;
	}
}
