package br.com.sabesp.sabesphotsitesolicitacoes.entity;

public enum Assunto {
	
	RECURSOS_HUMANOS (1, "Recursos Humanos"),
	FORNECEDORES_SABESP (2, "Fornecedores da Sabesp (Editais, licita��es e contrata��es)"),
	PROJETO_TIETE (3, "Projeto Tiet�"),
	VISITA_ESTACOES (4, "Visita �s Esta��es de Tratamento de Esgotos na RMSP"),
	COMUNICACAO_INSTITUCIONAL (5, "Comunica��o Institucional"),
	SERVICOS_SOLICITADOS (6, "Servi�os Solicitados"),
	VISITA_CANTAREIRA (7, "Visita ao Sistema Cantareira");
	
	
	private Assunto(Integer codigo, String valor) {
		this.codigo = codigo;
		this.valor = valor;
	}
	
	private final Integer codigo;
	private final String valor;
	
	public Integer getCodigo() {
		return codigo;
	}
	public String getValor() {
		return valor;
	}
	
	public static String getAssuntoByCode(Integer code) {
		
		for (Assunto assunto : Assunto.values()) {
			if (assunto.getCodigo().equals(code) || assunto.getCodigo().equals(code))
				return assunto.getValor();
		}
		
		return null;
	}

}
