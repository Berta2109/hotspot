package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Table(name = "CADASTRO_UNIDADE_CONSUMO")
public class CadastroUnidadeConsumo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;

	//Campo n�o � mais utilizado
//	@NotNull
	@Column(name = "CD_TIPO_SOLICITANTE")
	private Integer tipo;
	
	//At� 7 Economias (Somente para im�veis residenciais ou mistos)
	@NotNull
	@Column(name = "CD_TIPO_UNIDADE")
	private String tipoUnidade;

    @Column(name = "QT_UNIDADE_AUTONOMA")
    private Integer qtUnidadeAutonoma;

    @Column(name = "QT_UNIDADE_RESIDENCIAL")
    private Integer qtUnidadeResendencial;
    
    @Column(name = "QT_UNIDADE_NAO_RESIDENCIAL")
    private Integer qtUnidadeNaoResidencial;
	
	@Column(name = "POSSUI_ESCRITURA")
	private Boolean possuiEscritura;

	@Column(name = "NAO_POSSUI_ESCRITURA")
	private Boolean naoPossuiEscritura;
	
	@Column(name = "PROPRIEDADE_EXCLUSIVA")
	private Boolean propriedadeExclusiva;
	
	@Column(name = "RESIDENCIA_COLETIVA")
	private Boolean residenciaColetiva;
	
	@Column(name = "IN_REPRESENTANTE_LEGAL")
	private Boolean representateLegal;
	
	@Column(name = "CD_TIPO_HABITACAO")
	private Integer tipoHabitacao;
	
	//Categoria de Uso( resid�ncia, com�rcio, ind�stria e p�blica) e Tipo de Liga��o (�gua, esgoto ou �gua e esgoto)
	@Column(name = "CD_CADASTRO_CATEGORIA")
	private String cadastroCategoria;

	@Column(name = "CD_TIPO_LIGACAO")
	private String tipoLigacao;
	
	@Column(name = "ENTIDADE_PUBLICA")
	private Boolean entidadePublica;
	
	//Get and Set
	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}

	public String getTipoUnidade() {
		return tipoUnidade;
	}

	public void setTipoUnidade(String tipoUnidade) {
		this.tipoUnidade = tipoUnidade;
	}

	public Integer getQtUnidadeAutonoma() {
		return qtUnidadeAutonoma;
	}

	public void setQtUnidadeAutonoma(Integer qtUnidadeAutonoma) {
		this.qtUnidadeAutonoma = qtUnidadeAutonoma;
	}

	public Integer getQtUnidadeResendencial() {
		return qtUnidadeResendencial;
	}

	public void setQtUnidadeResendencial(Integer qtUnidadeResendencial) {
		this.qtUnidadeResendencial = qtUnidadeResendencial;
	}

	public Integer getQtUnidadeNaoResidencial() {
		return qtUnidadeNaoResidencial;
	}

	public void setQtUnidadeNaoResidencial(Integer qtUnidadeNaoResidencial) {
		this.qtUnidadeNaoResidencial = qtUnidadeNaoResidencial;
	}

	public Boolean getPossuiEscritura() {
		return possuiEscritura;
	}

	public void setPossuiEscritura(Boolean possuiEscritura) {
		this.possuiEscritura = possuiEscritura;
	}

	public Boolean getNaoPossuiEscritura() {
		return naoPossuiEscritura;
	}

	public void setNaoPossuiEscritura(Boolean naoPossuiEscritura) {
		this.naoPossuiEscritura = naoPossuiEscritura;
	}

	public Boolean getPropriedadeExclusiva() {
		return propriedadeExclusiva;
	}

	public void setPropriedadeExclusiva(Boolean propriedadeExclusiva) {
		this.propriedadeExclusiva = propriedadeExclusiva;
	}

	public Boolean getResidenciaColetiva() {
		return residenciaColetiva;
	}

	public void setResidenciaColetiva(Boolean residenciaColetiva) {
		this.residenciaColetiva = residenciaColetiva;
	}

	public Boolean getRepresentateLegal() {
		return representateLegal;
	}

	public void setRepresentateLegal(Boolean representateLegal) {
		this.representateLegal = representateLegal;
	}

	public Integer getTipoHabitacao() {
		return tipoHabitacao;
	}

	public void setTipoHabitacao(Integer tipoHabitacao) {
		this.tipoHabitacao = tipoHabitacao;
	}

	public String getCadastroCategoria() {
		return cadastroCategoria;
	}

	public void setCadastroCategoria(String cadastroCategoria) {
		this.cadastroCategoria = cadastroCategoria;
	}

	public String getTipoLigacao() {
		return tipoLigacao;
	}

	public void setTipoLigacao(String tipoLigacao) {
		this.tipoLigacao = tipoLigacao;
	}
	
	public Boolean getEntidadePublica() {
		return entidadePublica;
	}

	public void setEntidadePublica(Boolean entidadePublica) {
		this.entidadePublica = entidadePublica;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof CadastroUnidadeConsumo)) {
			return false;
		}
		CadastroUnidadeConsumo other = (CadastroUnidadeConsumo) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}

}
