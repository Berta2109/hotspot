package br.com.sabesp.sabesphotsitesolicitacoes.view;

public class Vizinho {
	
	private String codigo;
	private String numero;
	private String complemento;
	private Boolean check; 
	private Integer endValido;
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public Boolean getCheck() {
		return check;
	}
	public void setCheck(Boolean check) {
		this.check = check;
	}
	public Integer getEndValido() {
		return endValido;
	}
	public void setEndValido(Integer endValido) {
		this.endValido = endValido;
	}
	
}
