package br.com.sabesp.sabesphotsitesolicitacoes.util.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;

@FacesConverter(value = "cpfCnpjConverter")
public class CpfCnpjConverter implements Converter {

	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) throws ConverterException {
		if (arg2 == null) {
			return "";
		}
		String cpfCnpj = TreatString.filterOnlyNumber(arg2);
		if (cpfCnpj.length() <= 11) {
			return BrasilUtils.formatarCPF(cpfCnpj);
		}else {
			return BrasilUtils.formatarCNPJ(cpfCnpj);
		}
	}

	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) throws ConverterException {
		if (arg2 == null) {
			return "";
		}
		String cpfCnpj = TreatString.filterOnlyNumber(arg2);
		if (cpfCnpj.length() <= 11) {
			return BrasilUtils.formatarCPF(cpfCnpj);
		}
		return BrasilUtils.formatarCNPJ(cpfCnpj);
	}
}
