package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

import br.com.sabesp.sabesphotsitesolicitacoes.util.GenericRepository;
import br.com.sabesp.sabesphotsitesolicitacoes.view.CidadeDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.view.LogradouroDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Vizinho;

@Stateless
public class PrimeiraLigacaoBusiness {

	@EJB
	private GenericRepository repository;

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public String buscarUnidadeAdminExecServico(String numeroProcesso) {
		
		String unidadeAdminExecServico = "";
		try {
			
			String sql = "select b.unidade_admin_exec_servico " + 
					"from   ora_os.s_dado_primario@bdi b " + 
					"where  b.cod_unico = ?1 AND rownum = 1 ORDER BY b.id_dado_primario desc";

			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, numeroProcesso);

			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (!retorno.isEmpty()) {
				unidadeAdminExecServico = retorno.get(0) != null ? String.valueOf(retorno.get(0)): "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return unidadeAdminExecServico;
	}

	public String buscarCodMunicipio(String unidadeAdminExecServico) {
		String codMunicipio = "";
		try {
			
			String sql = "SELECT " + 
					"	c.cod_municipio " + 
					"FROM " + 
					"	ORA_VIARIO.s_ent_organizacional@bdi c " + 
					"WHERE " + 
					"	c.cod_municipio <> 999 " + 
					"	AND c.cod_municipio IS NOT NULL " + 
					"	AND c.cod_municipio <> 100 " + 
					"	AND c.cod_ent_organizacional = ?1";

			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, unidadeAdminExecServico);

			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (!retorno.isEmpty()) {
				codMunicipio = retorno.get(0) != null ? String.valueOf(retorno.get(0)) : "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return codMunicipio;
	}

	public List<CidadeDTO> buscarCidades() {

		List<CidadeDTO> cidades = new ArrayList<CidadeDTO>();
		
		try {
			
			String sql = "SELECT DISTINCT" + 
					"	id_municipio, " + 
					"	COD_MUNICIPIO, " + 
					"	DESC_MUNICIPIO " + 
					"FROM " + 
					"	ora_viario.vw_s_municipio@bdi " + 
					"WHERE " + 
					"	ID_MUNICIPIO <> 9 " + //sao paulo
					"ORDER BY " + 
					"	desc_municipio ";

			Query query = repository.getEntityManager().createNativeQuery(sql);
			
			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (retorno.isEmpty()) {
				return null;
			}

			for (Object[] objects : retorno) {
				CidadeDTO cidade = new CidadeDTO();
				
				cidade.setId(Integer.valueOf(objects[0].toString()));
				cidade.setCodigo(Integer.valueOf(objects[1].toString()));
				cidade.setNome(String.valueOf(objects[2]));
				
				cidades.add(cidade);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return cidades;
	}
	
	public Collection<LogradouroDTO> buscarLogradouro(String descLogradouro, Integer codCidade) {
		List<LogradouroDTO> logradouros = new ArrayList<LogradouroDTO>();
		try {
			
			String sql = "SELECT " + 
					"	a.cod_logradouro, " + 
					"	a.desc_tipo_logradouro, " + 
					"	a.desc_logradouro, " +
					"	c.desc_bairro " +
					"FROM " + 
					"	ora_viario.s_logradouro@bdi a, " +
					"	ORA_VIARIO.s_bairro@bdi c " +
					"WHERE " + 
					"	a.cod_municipio = ?1 " + 
					"	AND a.desc_logradouro LIKE ?2 " +
					"	AND c.cod_bairro = a.cod_bairro" ;

			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, codCidade);
			query.setParameter(2, descLogradouro.trim().toUpperCase() + "%");
			
			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (retorno.isEmpty()) {
				return logradouros;
			}

			for (Object[] objects : retorno) {
				LogradouroDTO logradouro = new LogradouroDTO();
				
				logradouro.setCodLogradouro(String.valueOf(objects[0].toString()));
				logradouro.setDescTipoLogr(String.valueOf(objects[1]));
				logradouro.setDescLogradouro(String.valueOf(objects[2]));
				logradouro.setDescBairro(String.valueOf(objects[3]));
				
				logradouros.add(logradouro);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return logradouros;
	}

	public Collection<LogradouroDTO> buscarEndereco(String descLogradouro, Integer codCidade) {
		List<LogradouroDTO> logradouros = new ArrayList<LogradouroDTO>();
		try {
			
			String sql = "SELECT " + 
					"	a.cod_endereco, " + 
					"	a.desc_tipo_logr, " + 
					"	a.desc_rua, " + 
					"	b.desc_bairro, " +
					"	a.end_valido " +
					"FROM " + 
					"	ora_viario.s_endereco@bdi a " + 
					"LEFT JOIN ora_viario.s_bairro@bdi b ON " + 
					"	a.cod_bairro = b.cod_bairro " + 
					"WHERE " + 
					"	a.cod_municipio = ?1 " + 
					"	AND a.desc_rua LIKE ?2 ";

			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, codCidade);
			query.setParameter(2, descLogradouro.toUpperCase() + "%");
			
			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (retorno.isEmpty()) {
				return null;
			}

			for (Object[] objects : retorno) {
				LogradouroDTO logradouro = new LogradouroDTO();
				
//				logradouro.setCodEndereco(Integer.valueOf(objects[0].toString()));
//				logradouro.setDescTipoLogr(String.valueOf(objects[1]));
//				logradouro.setDescRua(String.valueOf(objects[2]));
//				logradouro.setEndValido(Integer.valueOf(objects[3].toString()));
				
				logradouros.add(logradouro);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return logradouros;
	}
	
	public Collection<Vizinho> buscarVizinhos(Integer codCidade, String rua, String numero, String complemento) {
		List<Vizinho> vizinhos = new ArrayList<Vizinho>();
		try {
			
			Integer numeroInteiro = Integer.valueOf(numero);
			
			String sql = "SELECT " + 
					"	a.cod_endereco, " + 
					"	a.num_ENDERECO, " + 
					"	a.COMPL_ENDERECO, " +
					"	a.end_valido " +
					"FROM " + 
					"	ora_viario.s_endereco@bdi a " + 
					"LEFT JOIN ora_viario.s_bairro@bdi b ON " + 
					"	a.cod_bairro = b.cod_bairro " + 
					"WHERE " + 
					"	a.cod_municipio = ?1 " + 
					"	AND a.desc_rua LIKE ?2 " + 
					"	AND a.num_ENDERECO BETWEEN ?3 AND ?4 ";
			
			if(complemento != null && !complemento.equals("")) {
				sql += "	AND a.COMPL_ENDERECO LIKE ?5 ";
				
			}

			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, codCidade);
			query.setParameter(2, rua.toUpperCase() + "%");
			query.setParameter(3, numeroInteiro - 5);
			query.setParameter(4, numeroInteiro + 5);
			
			if(complemento != null && !complemento.equals("")) {
				query.setParameter(5, complemento.toUpperCase() + "%");
			}
			
			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (retorno.isEmpty()) {
				return vizinhos;
			}

			for (Object[] objects : retorno) {
				Vizinho vizinho = new Vizinho();
				
				vizinho.setCodigo(String.valueOf(objects[0]));
				vizinho.setNumero(String.valueOf(objects[1]));
				vizinho.setComplemento(objects[2] == null ? "" : String.valueOf(objects[2]));
				vizinho.setEndValido(Integer.valueOf(objects[3].toString()));
				
				vizinhos.add(vizinho);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vizinhos;
	}

	public String buscarPDE(String codigoEndereco) {
		
		String pde = "";
		
		try {
			
			String sql = "SELECT " + 
					"	a.cod_PDE " + 
					"FROM " + 
					"	ora_viario.s_pde@bdi a " + 
					"WHERE " + 
					"	a.cod_endereco = ?1 ";

			Query query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, codigoEndereco);

			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (!retorno.isEmpty()) {
				pde = retorno.get(0) != null ? String.valueOf(retorno.get(0)) : "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return pde;
	}
	
}
