package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SOLICITACAO_MODIF_LIGACAO")
public class ModificacaoLigacao implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;
	
	@Column(name = "SERVICO_REALIZAR")
	private Integer servicoRealizar;

	@Column(name = "IN_REPRESENTANTE_LEGAL")
	private Boolean representateLegal;
	
	
	//Get and Set
	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Integer getServicoRealizar() {
		return servicoRealizar;
	}

	public void setServicoRealizar(Integer servicoRealizar) {
		this.servicoRealizar = servicoRealizar;
	}

	public Boolean getRepresentateLegal() {
		return representateLegal;
	}

	public void setRepresentateLegal(Boolean representateLegal) {
		this.representateLegal = representateLegal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ModificacaoLigacao)) {
			return false;
		}
		ModificacaoLigacao other = (ModificacaoLigacao) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}

}
