package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TARIFA_SOCIAL_RES_UNIFAMILIAR")
public class TarifaSocialUnifamiliar implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7027132360012970498L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;

	@Column(name = "IN_TRABALHADOR_INFORMAL")
    private Boolean trabalhadorInformal;
	
	@Column(name = "IN_NAO_POSSUI_COMPROVANTE_IPTU")
    private Boolean naoPossuiComprovante;

	
	
	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Boolean getTrabalhadorInformal() {
		if(trabalhadorInformal == null) {
			trabalhadorInformal = Boolean.FALSE;
		}
		return trabalhadorInformal;
	}

	public void setTrabalhadorInformal(Boolean trabalhadorInformal) {
		this.trabalhadorInformal = trabalhadorInformal;
	}

	public Boolean getNaoPossuiComprovante() {
		if(naoPossuiComprovante == null) {
			naoPossuiComprovante = Boolean.FALSE;
		}
		return naoPossuiComprovante;
	}

	public void setNaoPossuiComprovante(Boolean naoPossuiComprovante) {
		this.naoPossuiComprovante = naoPossuiComprovante;
	}
	
	
}
