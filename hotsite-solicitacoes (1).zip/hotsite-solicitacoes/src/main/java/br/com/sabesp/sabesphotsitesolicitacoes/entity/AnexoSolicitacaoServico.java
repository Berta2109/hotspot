package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;

@Entity
@Table(name = "ANEXO_SOLICITACAO_SERVICO")
public class AnexoSolicitacaoServico implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8684799166259267862L;

	@Id
	@SequenceGenerator(name = "SEQ_ANEXO_SOLICITACAO_SERVICO", sequenceName = "SEQ_ANEXO_SOLICITACAO_SERVICO", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ANEXO_SOLICITACAO_SERVICO")
	@Column(name = "CD_ANEXO_SOLICITACAO_SERVICO")
	private Long id;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO", nullable = false)
	private SolicitacaoServico solicitacao;

	@NotNull
	@Column(name = "NM_ANEXO_USUARIO")
	private String nome;

	@NotNull
	@Column(name = "DC_CAMINHO_ANEXO")
	private String caminho;

	@NotNull
	@Column(name = "CD_IDENTIFICACAO_ANEXO")
	private Integer tipo;

	@Column(name = "DC_HASH_ANEXO")
	private String identificador;

	public AnexoSolicitacaoServico() {
		identificador = TreatString.randomId();
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCaminho() {
		return caminho;
	}

	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}

	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AnexoSolicitacaoServico)) {
			return false;
		}
		AnexoSolicitacaoServico other = (AnexoSolicitacaoServico) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
