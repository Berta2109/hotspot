@javax.xml.bind.annotation.XmlSchema(namespace = "http://cmead.sabesp.com.br/")
package br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador;
