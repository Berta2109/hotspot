
package br.com.sabesp.sabesphotsitesolicitacoes.service.model;

import java.io.Serializable;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.DoacaoContaAgua;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatDate;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatNumber;

public class DoacaoAguaCsiModel implements Serializable {

    public static final String TELA = "AVDOA";
    public static final String CAMPO_RGI = "NRRGILIG";
    public static final String CAMPO_CPF_CNPJ = "NRTELA14";
    public static final String CAMPO_CODIGO_CLIENTE = "CDCLIENTE";
    public static final String CAMPO_CODIGO_MUNICIPIO = "CDMUNICIP";
    public static final String CAMPO_CODIGO_ONG = "CDONG";
    public static final String CAMPO_DATA_FIM_INTENCAO_DOACAO = "DTGERAL";
    public static final String CAMPO_VALOR_DOACAO = "VLCONTAG";

    private static final long serialVersionUID = -4771597099821759559L;

    private String numeroRgi;
    private String cpfCnpj;
    private String codigoMunicipio;
    private String codigoCliente;
    private String codigoOng;
    private String dataFimIntecaoDoacao;
    private String valorDoacao;

    public DoacaoAguaCsiModel(DoacaoContaAgua doacaoContaAgua) {
        if (doacaoContaAgua != null) {
            setNumeroRgi(doacaoContaAgua.getRgi().toString());
            setCpfCnpj(doacaoContaAgua.getCpfCnpj());
            setCodigoOng(TreatNumber.numeroToString(doacaoContaAgua.getCodigoTipoOng()));
            setValorDoacao(TreatNumber.numeroToString(doacaoContaAgua.getValorDoacao()));
            setCodigoCliente(doacaoContaAgua.getCodigoCliente());
            setCodigoMunicipio(TreatNumber.numeroToString(doacaoContaAgua.getCodigoMunicipio()));
            setDataFimIntecaoDoacao(TreatDate.formatarParaAnoMesDia(doacaoContaAgua.getDataCancelamento()));
        }
    }

    public String getNumeroRgi() {
        return numeroRgi;
    }

    public void setNumeroRgi(String numeroRgi) {
        this.numeroRgi = numeroRgi;
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getCodigoMunicipio() {
        return codigoMunicipio;
    }

    public void setCodigoMunicipio(String codigoMunicipio) {
        this.codigoMunicipio = codigoMunicipio;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getCodigoOng() {
        return codigoOng;
    }

    public void setCodigoOng(String codigoOng) {
        this.codigoOng = codigoOng;
    }

    public String getDataFimIntecaoDoacao() {
        return dataFimIntecaoDoacao;
    }

    public void setDataFimIntecaoDoacao(String dataFimIntecaoDoacao) {
        this.dataFimIntecaoDoacao = dataFimIntecaoDoacao;
    }

    public String getValorDoacao() {
        return valorDoacao;
    }

    public void setValorDoacao(String valorDoacao) {
        this.valorDoacao = valorDoacao;
    }
}
