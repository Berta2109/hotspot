@javax.xml.bind.annotation.XmlSchema(namespace = "http://crm.sabesp.com.br/")
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;
