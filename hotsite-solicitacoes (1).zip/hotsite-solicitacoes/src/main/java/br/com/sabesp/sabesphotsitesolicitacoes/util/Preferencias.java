package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Preferencias {

	public enum Propriedades {
		CAMINHO_TEMPORARIO_ANEXOS_SOLICITACAO("solicitacao.config.caminhotemporario"),
		CAMINHO_ANEXOS_SOLICITACAO("solicitacao.config.caminhoarquivos"),
		AUTENTICADOR_URL("config.ws.autenticador.url"),
		AUTENTICADOR_USUARIO("config.ws.autenticador.usuario"),
		AUTENTICADOR_SENHA("config.ws.autenticador.senha"),
		AUTENTICADOR_AMBIENTE("config.ws.autenticador.ambiente"),
		RGI_URL("config.ws.rgi.url"),
		HABILIAR_LOG_SOAPMSG("config.ws.habilitarlogsoap"),
		INTEGRAR_WS_SABESP("config.ws.habilitarintegracao"),
		INTEGRAR_MAINFRAME("config.mainframe.habilitarintegracao"),
		MAINFRAME_CREDENCIAL_LOGIN("config.mainframe.credencial.login"),
		MAINFRAME_CREDENCIAL_SENHA("config.mainframe.credencial.senha"),
		MAINFRAME_CSIA_NOME("config.mainframe.csia.nome"),
		MAINFRAME_SERVIDOR_ENDERECO("config.mainframe.servidor.endereco"),
		MAINFRAME_SERVIDOR_PORTA("config.mainframe.servidor.porta"),
		SQL_CONSULTA_RGI("solicitacao.config.sqlconsultargi"),
		EMAIL_SOLICITACAO_REMETENTE("email.solicitacao.config.remetente"),
		EMAIL_SOLICITACAO_PREFIXOASSUNTOEMAIL("email.solicitacao.config.prefixoassuntoemail"),
		URL("url.config.contexto"), EMAIL_NOME_JNDI_SESSION("email.config.nomejndisession"),
		EMAIL_FALE_CONOSCO("email.fale.conosco")
		;

		private String key;

		private Propriedades(String n) {
			this.key = n;
		}
	}

	public static String get(Propriedades propriedade) {
		return getProperty(propriedade.key);
	}

	public static String get(String propriedade) {
		return getProperty(propriedade);
	}

	public static boolean getBoolean(Propriedades test) {
		try {
			return Boolean.valueOf(get(test));
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean getBoolean(Propriedades test, Boolean defaultValue) {
		try {
			return Boolean.valueOf(get(test));
		} catch (Exception e) {
			return defaultValue;
		}
	}

	private static final String getProperty(String key) {
		InputStream in = null;
		String resul = null;
		try {
			in = obterProperties();
			if (in == null) {
				throw new IllegalArgumentException("Arquivo de properties do projeto nao encontrado no ambiente");
			}
			Properties prop = new Properties();
			prop.load(in);
			resul = (String) prop.get(key);
			if (resul == null || (resul = resul.trim()).equals("")) {
				throw new IllegalArgumentException("Propriedade " + key + " nao definida no arquivo de propriedades");
			}
			return resul;
		} catch (Exception e) {
			throw new IllegalStateException("Falha usar arquivo de propriedades do ambiente", e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	private static InputStream obterProperties() throws NamingException, FileNotFoundException {
		Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");
		String caminho = (String) envCtx.lookup("sabesphotsite-solicitacoes/propFile");
		if (TreatString.isNotBlank(caminho) && new File(caminho).exists()) {
			return new FileInputStream(caminho);
		}
		String fileName = "/config-padrao.properties";
		return Preferencias.class.getResourceAsStream(fileName);
	}
}
