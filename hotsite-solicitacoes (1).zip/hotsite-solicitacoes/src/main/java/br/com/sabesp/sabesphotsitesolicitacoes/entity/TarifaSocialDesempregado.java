package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "TARIFA_SOCIAL_DESEMPREGADOS")
public class TarifaSocialDesempregado implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 744868455408114628L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;
	
	@Column(name = "IN_TRABALHADOR_INFORMAL")
    private Boolean trabalhadorInformal;
	
	

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	public Boolean getTrabalhadorInformal() {
		if(trabalhadorInformal == null) {
			trabalhadorInformal = Boolean.FALSE;
		}
		return trabalhadorInformal;
	}

	public void setTrabalhadorInformal(Boolean trabalhadorInformal) {
		this.trabalhadorInformal = trabalhadorInformal;
	}
	
}
