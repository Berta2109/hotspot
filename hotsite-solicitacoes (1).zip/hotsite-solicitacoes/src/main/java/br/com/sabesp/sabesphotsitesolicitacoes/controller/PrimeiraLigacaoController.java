package br.com.sabesp.sabesphotsitesolicitacoes.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ResourceBundle;

import javax.ejb.EJB;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.inject.Named;

import org.apache.myfaces.extensions.cdi.core.api.scope.conversation.ViewAccessScoped;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import br.com.sabesp.sabesphotsitesolicitacoes.business.EmailBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.PrimeiraLigacaoBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.business.SolicitacaoBusiness;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.AtendimentoComercial;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.EnderecoPreCadastro;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.PesquisaSatisfacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SolicitacaoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Feedback;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatFile;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
import br.com.sabesp.sabesphotsitesolicitacoes.util.ValidacaoException;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Anexo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.CidadeDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.view.LogradouroDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.view.PreCadastroLigacaoDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.view.PrimeiraLigacaoDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Solicitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Solicitante;
import br.com.sabesp.sabesphotsitesolicitacoes.view.TipoAnexo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Vizinho;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

@Named
@ViewAccessScoped
public class PrimeiraLigacaoController implements Serializable {
	
	@EJB
	private PrimeiraLigacaoBusiness primeiraLigacaoBusiness;
	
	@EJB
	private SolicitacaoBusiness solicitacaoBusiness;
	
	@EJB
	private EmailBusiness emailBusiness;
	
	private AtendimentoComercial atendimentoComercial;
	private PrimeiraLigacaoDTO primeiraLigacaoDTO;
	private PreCadastroLigacaoDTO preCadastroLigacaoDTO;
	private List<Vizinho> vizinhosSelecionados;
	private Collection<CidadeDTO> cidades;
	private Vizinho vizinho;
	private Vizinho vizinhoSelecionado;
	private CidadeDTO cidadeSelecionado;
	private Solicitacao edicao;
	private LogradouroDTO logradouroSelecionado;
	private Collection<Anexo> edicaoAnexos;
	private Collection<Anexo> edicaoFotos;
	private StreamedContent file;
	private Anexo anexo1;
	private Anexo anexo2;
	private Anexo anexo3;
	private Anexo anexo4;
	private Anexo anexo5;
	private Anexo anexo6;
	private Anexo anexo7;
	private Anexo foto1;
	private Anexo foto2;
	private Anexo foto3;
	private Anexo foto4;
	private Anexo foto5;
	private Anexo foto6;
	private Anexo foto7;
	private Anexo foto8;
	private Integer tipoLigacao;
	private Boolean disableEndereco;
	private Boolean liberaPreCadastro;
	private Boolean liberaCadastro;
	private Boolean check1Supressao;
	private Boolean checkAcordo;
	private Boolean atcEncontrado;
	private boolean liberarAnexos;
	private boolean liberaVizinhos;
	private boolean liberaBuscaVizinhos;
	
	private Integer notaFeedback;
	private Boolean habilitaFeedback;
	private String comentarioFeedback;
	private Boolean liberaOk;
	
	private static final long serialVersionUID = 84328036572550904L;
	private static final Integer CIDADE_SAO_PAULO = 100; 

	public String validarNumeroProcesso() {
		
		try {
			getCidades().clear();
			liberaPreCadastro = Boolean.TRUE;
			liberaCadastro = Boolean.FALSE;
			
			if(this.getPrimeiraLigacaoDTO().getNumeroProcesso().equals(null) || this.getPrimeiraLigacaoDTO().getNumeroProcesso().equals("")) {
				Feedback.jsfWarning("mensagem.validacao.processo");
				return null;
			}
			
			Integer numeroProcessoEncontrado = buscarProcesso();
			
			if (numeroProcessoEncontrado != null && numeroProcessoEncontrado.equals(0)) {
				atcEncontrado = Boolean.TRUE;
				
				return carregarTelaCadastro();
				
			} else if (numeroProcessoEncontrado != null && numeroProcessoEncontrado.equals(1)) {
				atcEncontrado = Boolean.FALSE;
				setCidades(buscarCidades());

				PrimeFaces.current().executeScript("PF('modalCidade').show()");
				PrimeFaces.current().ajax().update("modalCidade");
				return null;
			} else if (numeroProcessoEncontrado != null && numeroProcessoEncontrado.equals(2)) {
				PrimeFaces.current().executeScript("PF('modalRgiNaoEncontrado').show()");
				PrimeFaces.current().ajax().update("modalRgiNaoEncontrado");
				return null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void buscarVizinho() {
		preCadastroLigacaoDTO.getVizinhos().clear();
		preCadastroLigacaoDTO.getVizinhos().addAll(primeiraLigacaoBusiness.buscarVizinhos(primeiraLigacaoDTO.getCidade(), getLogradouroSelecionado().getDescLogradouro(), getPreCadastroLigacaoDTO().getNumero(), getPreCadastroLigacaoDTO().getComplemento()));
		
		liberaVizinhos = Boolean.TRUE;
	}
	
	private List<CidadeDTO> buscarCidades() {
		
		List<CidadeDTO> cidades = new ArrayList<CidadeDTO>();
		
		CidadeDTO cidade = new CidadeDTO();
		cidade.setId(9);
		cidade.setCodigo(100);
		cidade.setNome("S�O PAULO");
		
		cidades.add(cidade);
		cidades.addAll(primeiraLigacaoBusiness.buscarCidades());
		
		return cidades;
	}

	private Integer buscarProcesso() {
		String unidadeAdminExecServico = buscarUnidadeAdminExecServico(); 
		
		String codMunicipio = "";
		
		if(unidadeAdminExecServico != null && !unidadeAdminExecServico.equals("")) {
			codMunicipio = buscarMunicipio(unidadeAdminExecServico);
			
			if(codMunicipio != null && !codMunicipio.equals("")) {
				atendimentoComercial = solicitacaoBusiness.definirAtendimentoComercial(new DadosRGI(Integer.parseInt(codMunicipio)));
				atendimentoComercial.setCodMunicipio(codMunicipio);
				
				return 0;
			} else {
				return 1;
			}
		}
		
		return 2;
	}

	private String buscarUnidadeAdminExecServico() {
		String numeroProcessoCompleto = TreatString.filterOnlyNumber(this.getPrimeiraLigacaoDTO().getNumeroProcesso()); 
		String anoBusca = ""; 
		anoBusca = numeroProcessoCompleto.substring(0, 4); 
		anoBusca = anoBusca.substring(anoBusca.length() - 2);
		
		String numeroProcessoBusca = TreatString.filterOnlyNumber(this.getPrimeiraLigacaoDTO().getNumeroProcesso().substring(this.getPrimeiraLigacaoDTO().getNumeroProcesso().length() - 14));
		
		String numeroProcessoPesquisa = anoBusca + numeroProcessoBusca;
		
		return primeiraLigacaoBusiness.buscarUnidadeAdminExecServico(numeroProcessoPesquisa);
		
	}
	
	private String buscarMunicipio(String unidadeAdminExecServico) {
		return primeiraLigacaoBusiness.buscarCodMunicipio(unidadeAdminExecServico);
	}

	public String carregarTelaCadastro() {
		
		try {
			if(CIDADE_SAO_PAULO.equals(this.primeiraLigacaoDTO.getCidade())){
				//redireciona para cadastro dados endere�o
				liberaPreCadastro = Boolean.TRUE;
				liberaCadastro = Boolean.FALSE;
			} else {
				//redireciona para cadastro nova liga��o
				carregarTelaFormulario();
			}
			
			this.disableEndereco = Boolean.TRUE;
			liberarAnexos = Boolean.TRUE;
			liberaBuscaVizinhos = Boolean.FALSE;
			liberaVizinhos = Boolean.FALSE;
			
			return "/pages/publico/primeiraligacao/pre-cadastro";
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "";
	}
	
	
	public void carregarTelaFormulario() {
		try {
			
			if(vizinhoSelecionado == null) {
				
				if(atendimentoComercial != null) {
					DadosRGI dados = new DadosRGI(getAtendimentoComercial().getId(), getAtendimentoComercial().getCodMunicipio());
					getEdicao().setDados(dados);
				} else {
					getAtendimentoComercial().setId(999);
					DadosRGI dados = new DadosRGI(999, primeiraLigacaoDTO.getCidade().toString());
					getEdicao().setDados(dados);
				}
				
			} else if(vizinhoSelecionado != null) {
				if(!vizinhoSelecionado.getEndValido().equals(1)) { 
					DadosRGI dados = new DadosRGI(999, cidadeSelecionado.getCodigo().toString());
					getEdicao().setDados(dados);
				} else {
					String numeroPde = primeiraLigacaoBusiness.buscarPDE(vizinhoSelecionado.getCodigo());
					
					if(numeroPde == null || numeroPde.equals("")) {
						DadosRGI dados = new DadosRGI(999, primeiraLigacaoDTO.getCidade().toString());
						getEdicao().setDados(dados);
					} else {
						DadosRGI dados = new DadosRGI(999, numeroPde);
						getEdicao().setDados(dados);
					}
				}
			} else {
				DadosRGI dados = new DadosRGI(999, primeiraLigacaoDTO.getCidade().toString());
				getEdicao().setDados(dados);
			}
			
			this.liberaPreCadastro = Boolean.FALSE;
			this.liberaCadastro = Boolean.TRUE;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void carregarAnexos(Integer tipo) {
		Collection<Anexo> anexos = new ArrayList<Anexo>();
		
		if(tipo.equals(1)) {
			anexo1 = new Anexo(TipoAnexo.RGRNECPFCNHPRIMEIRA, Boolean.TRUE, Boolean.TRUE);
			anexo2 = new Anexo(TipoAnexo.IPTUCONTRATO, Boolean.TRUE, Boolean.TRUE);
			anexos.add(anexo1);
			anexos.add(anexo2);
		} else if(tipo.equals(2)) {
			anexo1 = new Anexo(TipoAnexo.RGRNECPFCNHSOCIO, Boolean.FALSE, Boolean.TRUE);
			anexo2 = new Anexo(TipoAnexo.CNPJMEI, Boolean.TRUE, Boolean.TRUE);
			anexo3 = new Anexo(TipoAnexo.CONTRATOSOCIAL, Boolean.FALSE, Boolean.TRUE);
			anexo4 = new Anexo(TipoAnexo.IPTUCONTRATO, Boolean.TRUE, Boolean.TRUE);
			//representante
			anexo5 = new Anexo(TipoAnexo.PROCURACAOCOMFIRMARECONHECIDA, Boolean.TRUE, Boolean.TRUE);
			anexo6 = new Anexo(TipoAnexo.RGRNECPFCNHPRIMEIRA, Boolean.TRUE, Boolean.TRUE);
			getEdicao().getSolicitante().setRepresentanteLegal(false);
			//estatal
			anexo7 = new Anexo(TipoAnexo.OFICIO, Boolean.TRUE, Boolean.TRUE);
			getEdicao().setEstatalFederal(false);
			anexos.add(anexo1);
			anexos.add(anexo2);
			anexos.add(anexo3);
			anexos.add(anexo4);
			anexos.add(anexo5);
			anexos.add(anexo6);
			anexos.add(anexo7);
		}
		
		if(edicaoAnexos != null && !edicaoAnexos.isEmpty()) {
			edicaoAnexos.clear();
		}
		edicaoAnexos = anexos;
		
	}
	
	public void carregarFotos() {
		
		Collection<Anexo> fotos = new ArrayList<Anexo>();
		
		limparFotos();
		
		if(this.tipoLigacao == null){
			return;
		} else {
			if(getTipoLigacao().equals(1)) {
				foto1 = new Anexo(TipoAnexo.FOTO1, Boolean.TRUE, Boolean.TRUE);
				foto2 = new Anexo(TipoAnexo.FOTO2, Boolean.TRUE, Boolean.TRUE);
				foto3 = new Anexo(TipoAnexo.FOTO3, Boolean.TRUE, Boolean.TRUE);
				foto4 = new Anexo(TipoAnexo.FOTO4, Boolean.FALSE, Boolean.TRUE);
				foto5 = new Anexo(TipoAnexo.FOTO5, Boolean.FALSE, Boolean.TRUE);
				foto6 = new Anexo(TipoAnexo.FOTO6, Boolean.FALSE, Boolean.TRUE);
				fotos.add(foto1);
				fotos.add(foto2);
				fotos.add(foto3);
				fotos.add(foto4);
				fotos.add(foto5);
				fotos.add(foto6);
			} else if(getTipoLigacao().equals(2)) {
				foto7 = new Anexo(TipoAnexo.FOTO7, Boolean.TRUE, Boolean.TRUE);
				foto8 = new Anexo(TipoAnexo.FOTO8, Boolean.FALSE, Boolean.TRUE);
				fotos.add(foto7);
				fotos.add(foto8);
			} else if(getTipoLigacao().equals(3)) {
				foto1 = new Anexo(TipoAnexo.FOTO1, Boolean.TRUE, Boolean.TRUE);
				foto4 = new Anexo(TipoAnexo.FOTO4, Boolean.TRUE, Boolean.TRUE);
				foto5 = new Anexo(TipoAnexo.FOTO5, Boolean.TRUE, Boolean.TRUE);
				foto6 = new Anexo(TipoAnexo.FOTO6, Boolean.TRUE, Boolean.TRUE);
				fotos.add(foto1);
				fotos.add(foto4);
				fotos.add(foto5);
				fotos.add(foto6);
			} else if(getTipoLigacao().equals(4)) {
				foto7 = new Anexo(TipoAnexo.FOTO7, Boolean.TRUE, Boolean.TRUE);
				foto8 = new Anexo(TipoAnexo.FOTO8, Boolean.FALSE, Boolean.TRUE);
				fotos.add(foto7);
				fotos.add(foto8);
			}
		}
		
		if(edicaoFotos != null && !edicaoFotos.isEmpty()) {
			edicaoFotos.clear();
		}
		edicaoFotos = fotos;
	}
	
	private void limparFotos() {
		foto1 = null;
		foto2 = null;
		foto3 = null;
		foto4 = null;
		foto5 = null;
		foto6 = null;
		foto7 = null;
		foto8 = null;
	}

	public void salvarSolicitacao() {
		
		getEdicao().setTipoServico(TipoServico.PLA);
		
		getEdicaoAnexos().addAll(getEdicaoFotos());
		
		try {
			if (validarSolicitacaoServico()) {
				getEdicao().setIp(Feedback.getIP());
				
				if(getEdicao().getDados() != null && getEdicao().getDados().getNumero() != null ) {
					
					if(getEdicao().getDados().getNumero().length() < 10) {
						getEdicao().getDados().setNumero("9999999" + getEdicao().getDados().getNumero());
					}
					
				}
				
				SolicitacaoServico solicitacaoSalva = solicitacaoBusiness.salvarSolicitacao(getEdicao(), getEdicaoAnexos());
				getEdicao().setProtocolo(solicitacaoSalva.getProtocolo());
				solicitacaoSalva.setNrFornecimento(getEdicao().getFornecimento());
				
				if( (cidadeSelecionado != null && cidadeSelecionado.getCodigo().equals(100)) || (primeiraLigacaoDTO != null && primeiraLigacaoDTO.getCidade() != null && primeiraLigacaoDTO.getCidade().equals(100))) {
					EnderecoPreCadastro enderecoPreCadastro = new EnderecoPreCadastro();
					
					enderecoPreCadastro.setSolicitacao(solicitacaoSalva);
					enderecoPreCadastro.setCodlogradouro(preCadastroLigacaoDTO.getLogradouro().getCodLogradouro());
					enderecoPreCadastro.setNumero(preCadastroLigacaoDTO.getNumero());
					enderecoPreCadastro.setComplemento(preCadastroLigacaoDTO.getComplemento());
					enderecoPreCadastro.setCodVizinho(vizinhoSelecionado.getCodigo());
					enderecoPreCadastro.setNumProcesso(primeiraLigacaoDTO.getNumeroProcesso());
					
					solicitacaoBusiness.salvarEnderecoPreCadastro(enderecoPreCadastro);
					
					solicitacaoSalva.setEndereco(preCadastroLigacaoDTO.getLogradouro().getDescLogradouroExibe() + "," + 
							preCadastroLigacaoDTO.getNumero() + ", " +
							 preCadastroLigacaoDTO.getComplemento() + ", - Bairro: " +
							vizinhoSelecionado.getComplemento() + " - " + "S�o Paulo/SP");
					
				}
				
				AtendimentoComercial atendimentoComercial = solicitacaoBusiness.definirAtendimentoComercial(getEdicao().getDados());

				emailBusiness.enviarEmailCadastroSolicitacao(Feedback.getI18nResourceBundle(), atendimentoComercial, solicitacaoSalva, null);
			
				PrimeFaces.current().executeScript("PF('modalSucesso').show()");
				PrimeFaces.current().ajax().update("modalSucesso");
			} else {
				Feedback.jsfError18n("msg.carencia.pla");
			}
		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}
	
	public Boolean validarSolicitacaoServico() {
		if (getEdicao().getSolicitante().getCpfCnpj() != null
				&& !getEdicao().getSolicitante().getCpfCnpj().trim().equals("")
				&& getEdicao().getSolicitante().getNome() != null
				&& !getEdicao().getSolicitante().getNome().trim().equals("")) {
			if (solicitacaoBusiness.buscarSolitacaoRecente(getEdicao(), -3)) {
				return false;
			}
		}
		return true;
	}
	
	public String index(boolean fluxo) {
		
		if (fluxo) {
			salvarPesquisa();
		}
		
		edicao = null;
		return "entrada";
	}
	
	/**
	 * M�todo respons�vel por salvar a pesquisa de satisfa��o
	 */
	private void salvarPesquisa() {
		try {
			PesquisaSatisfacao pesquisaSatisfacao = new PesquisaSatisfacao();

			pesquisaSatisfacao.setSolicitacao(solicitacaoBusiness.obterSolicitacao(edicao.getProtocolo()));
			if (getNotaFeedback().equals(11)) {
				setNotaFeedback(0);
			}
			pesquisaSatisfacao.setNotaPesquisa(getNotaFeedback());
			pesquisaSatisfacao.setJustificativaPesquisa(getComentarioFeedback());

			solicitacaoBusiness.salvarPesquisaSatisfacao(pesquisaSatisfacao);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}
	
	public void listarLogradouros() {
		preCadastroLigacaoDTO.getLogradouros().clear();
		
		if(validarLogradouroDigitado(preCadastroLigacaoDTO.getLogradouro())) {
			String logradouro = corrigirLogradouro(preCadastroLigacaoDTO.getLogradouro());
			preCadastroLigacaoDTO.getLogradouros().addAll(primeiraLigacaoBusiness.buscarLogradouro(logradouro, primeiraLigacaoDTO.getCidade()));
		} else {
			Feedback.jsfWarning("primeira.ligacao.logradouro.naoaceito");
			return;
		}
		
		PrimeFaces.current().executeScript("PF('modalLogradouro').show()");
		PrimeFaces.current().ajax().update("modalLogradouro");
	}
	
	private String corrigirLogradouro(LogradouroDTO logradouro) {
		
		String desc = logradouro.getDescLogradouroExibe().toUpperCase();
		
		for(String descTipoLogradouro : LogradouroDTO.getDescTipoLogradouro()) {
			desc = desc.replace(descTipoLogradouro.toUpperCase(), " ");
		}
		
		return desc;
	}

	private boolean validarLogradouroDigitado(LogradouroDTO logradouroDigitado) {

		if(logradouroDigitado.getDescLogradouroExibe().isEmpty()) {
			return false;
		} else if(logradouroDigitado.getDescLogradouroExibe().trim().length() < 4) {
			return false;
		}
		
		return true;
	}

	public void logradouroSelecionado() {
		if(getLogradouroSelecionado() != null) {
			preCadastroLigacaoDTO.setLogradouro(getLogradouroSelecionado());
			preCadastroLigacaoDTO.getLogradouro().setDescLogradouroExibe(getLogradouroSelecionado().getDescTipoLogr() + " " + getLogradouroSelecionado().getDescLogradouro());
			disableEndereco = Boolean.FALSE;
			liberaBuscaVizinhos = Boolean.TRUE;
		} else {
			preCadastroLigacaoDTO.setLogradouro(new LogradouroDTO());
			disableEndereco = Boolean.TRUE;
			liberaBuscaVizinhos = Boolean.FALSE;
		}
		
		PrimeFaces.current().executeScript("PF('modalLogradouro').hide()");
		PrimeFaces.current().ajax().update("modalLogradouro");
	}
	
	public void uploadArquivoSolicitacao(FileUploadEvent event) {
		if (!PhaseId.INVOKE_APPLICATION.equals(event.getPhaseId())) {
			event.setPhaseId(PhaseId.INVOKE_APPLICATION);
			event.queue();
			return;
		}
		Anexo anexo = (Anexo) event.getComponent().getAttributes().get("anexo");
		if (anexo == null) {
			return;
		}
		try {
			byte[] data = event.getFile().getContents();
			File caminho = TreatFile.saveTempFile("sabesp_as", data);
			anexo.setNomeUnico(TreatString
					.convertStringToUrl(event.getComponent().getAttributes().get("labelAnexo").toString(), "-"));
			anexo.setNome(event.getFile().getFileName());
			anexo.setCaminhoTemporario(caminho.getAbsolutePath());

		} catch (ValidacaoException e) {
			Feedback.jsfValidationError18n(e);
		} catch (Exception e) {
			Feedback.jsfErroOperacao(this, e);
		}
	}
	
	public void limparAnexo(Anexo anexo) {
		if (anexo != null) {
			TreatFile.deleteFile(anexo.getCaminhoTemporario());
			anexo.setNome(null);
			anexo.setCaminhoTemporario(null);
		}
	}
	
	public void atualizarMascara() {
		String cpfCnpj = getEdicao().getSolicitante().getCpfCnpj();
		cpfCnpj = TreatString.filterOnlyNumber(cpfCnpj);
		if (cpfCnpj.length() == 11) {
			getEdicao().getSolicitante().setCpfCnpj(BrasilUtils.formatarCPF(cpfCnpj));
			liberarAnexos = Boolean.FALSE;
			configurarPf();
		} else {
			liberarAnexos = Boolean.FALSE;
			getEdicao().getSolicitante().setCpfCnpj(BrasilUtils.formatarCNPJ(cpfCnpj));
			configurarPj();
		}

	}
	
	private void configurarPj() {
		limparAnexos();
		carregarAnexos(2);
	}

	private void configurarPf() {
		limparAnexos();
		carregarAnexos(1);
	}
	
	private void limparAnexos() {
		anexo1 = null;
		anexo2 = null;
		anexo3 = null;
		anexo4 = null;
		anexo5 = null;
		anexo6 = null;
		anexo7 = null;
	}

	public void tipoRepresentanteTrocado() {
		if (getEdicao().getSolicitante().getRepresentanteLegal()) {
			return;
		}
		limparAnexo(getEdicao().getSolicitante().getDocumentoRepresentateLegal());
	}
	
	public void estatalFederalTrocado() {
		if (getEdicao().getEstatalFederal()) {
			return;
		}
		limparAnexo(getEdicao().getDocumentoEstatalFederal());
	}

	//get e set
	public AtendimentoComercial getAtendimentoComercial() {
		if(atendimentoComercial == null) {
			atendimentoComercial = new AtendimentoComercial();
		}
		return atendimentoComercial;
	}

	public void setAtendimentoComercial(AtendimentoComercial atendimentoComercial) {
		this.atendimentoComercial = atendimentoComercial;
	}

	public void setFile(StreamedContent file) {
		this.file = file;
	}
	
	public StreamedContent getFile() throws FileNotFoundException {

		String caminhoWebInf = FacesContext.getCurrentInstance().getExternalContext()
				.getRealPath("/resources/modelos/FE-MR0111-V.1.pdf");
		InputStream stream = new FileInputStream(caminhoWebInf); // Caminho onde est�
																	// salvo o arquivo.
		file = new DefaultStreamedContent(stream, "application/pdf", "edital.pdf");

		return file;
	}
	
	public PrimeiraLigacaoDTO getPrimeiraLigacaoDTO() {
		if(primeiraLigacaoDTO == null) {
			primeiraLigacaoDTO = new PrimeiraLigacaoDTO();
		}
		return primeiraLigacaoDTO;
	}

	public void setPrimeiraLigacaoDTO(PrimeiraLigacaoDTO primeiraLigacaoDTO) {
		this.primeiraLigacaoDTO = primeiraLigacaoDTO;
	}

	public PreCadastroLigacaoDTO getPreCadastroLigacaoDTO() {
		if(preCadastroLigacaoDTO == null) {
			preCadastroLigacaoDTO = new PreCadastroLigacaoDTO();
		}
		return preCadastroLigacaoDTO;
	}

	public void setPreCadastroLigacaoDTO(PreCadastroLigacaoDTO preCadastroLigacaoDTO) {
		this.preCadastroLigacaoDTO = preCadastroLigacaoDTO;
	}
	

	public List<Vizinho> getVizinhosSelecionados() {
		if(vizinhosSelecionados == null) {
			vizinhosSelecionados = new ArrayList<Vizinho>();
		}
		return vizinhosSelecionados;
	}

	public void setVizinhosSelecionados(List<Vizinho> vizinhosSelecionados) {
		this.vizinhosSelecionados = vizinhosSelecionados;
	}

	public Vizinho getVizinho() {
		if(vizinho == null) {
			vizinho = new Vizinho();
		}
		return vizinho;
	}

	public void setVizinho(Vizinho vizinho) {
		this.vizinho = vizinho;
	}

	public Boolean getDisableEndereco() {
		return disableEndereco;
	}

	public void setDisableEndereco(Boolean disableEndereco) {
		this.disableEndereco = disableEndereco;
	}

	public Solicitacao getEdicao() {
		if(edicao == null) {
			edicao = new Solicitacao();
			edicao.setSolicitante(new Solicitante());
		}
		return edicao;
	}

	public void setEdicao(Solicitacao edicao) {
		this.edicao = edicao;
	}
	
	public Boolean getLiberaCadastro() {
		if(liberaCadastro == null) {
			liberaCadastro = Boolean.FALSE;
		}
		return liberaCadastro;
	}

	public void setLiberaCadastro(Boolean liberaCadastro) {
		this.liberaCadastro = liberaCadastro;
	}

	public Boolean getLiberaPreCadastro() {
		if(liberaPreCadastro == null) {
			liberaPreCadastro = Boolean.TRUE;
		}
		return liberaPreCadastro;
	}

	public void setLiberaPreCadastro(Boolean liberaPreCadastro) {
		this.liberaPreCadastro = liberaPreCadastro;
	}
	
	public Collection<Anexo> getEdicaoAnexos() {
		if (edicaoAnexos == null) {
			edicaoAnexos = new ArrayList<Anexo>();
		}
		return edicaoAnexos;
	}

	public void setEdicaoAnexos(Collection<Anexo> edicaoAnexos) {
		this.edicaoAnexos = edicaoAnexos;
	}
	
	public Collection<Anexo> getEdicaoFotos() {
		if(edicaoFotos == null) {
			edicaoFotos = new ArrayList<Anexo>();
		}
		return edicaoFotos;
	}

	public void setEdicaoFotos(Collection<Anexo> edicaoFotos) {
		this.edicaoFotos = edicaoFotos;
	}

	public Boolean getCheck1Supressao() {
		return check1Supressao;
	}

	public void setCheck1Supressao(Boolean check1Supressao) {
		this.check1Supressao = check1Supressao;
	}

	public Vizinho getVizinhoSelecionado() {
		return vizinhoSelecionado;
	}

	public void setVizinhoSelecionado(Vizinho vizinhoSelecionado) {
		this.vizinhoSelecionado = vizinhoSelecionado;
	}

	public LogradouroDTO getLogradouroSelecionado() {
		return logradouroSelecionado;
	}

	public void setLogradouroSelecionado(LogradouroDTO logradouroSelecionado) {
		this.logradouroSelecionado = logradouroSelecionado;
	}

	public Anexo getAnexo1() {
		if(anexo1 == null) {
			anexo1 = new Anexo();
		}
		return anexo1;
	}

	public void setAnexo1(Anexo anexo1) {
		this.anexo1 = anexo1;
	}

	public Anexo getAnexo2() {
		if(anexo2 == null) {
			anexo2 = new Anexo();
		}
		return anexo2;
	}

	public void setAnexo2(Anexo anexo2) {
		this.anexo2 = anexo2;
	}

	public Anexo getAnexo3() {
		if(anexo3 == null) {
			anexo3 = new Anexo();
		}
		return anexo3;
	}

	public void setAnexo3(Anexo anexo3) {
		this.anexo3 = anexo3;
	}

	public Anexo getAnexo4() {
		if(anexo4 == null) {
			anexo4 = new Anexo();
		}
		return anexo4;
	}

	public void setAnexo4(Anexo anexo4) {
		this.anexo4 = anexo4;
	}

	public Anexo getAnexo5() {
		if(anexo5 == null) {
			anexo5 = new Anexo();
		}
		return anexo5;
	}

	public void setAnexo5(Anexo anexo5) {
		this.anexo5 = anexo5;
	}

	public Anexo getAnexo6() {
		if(anexo6 == null) {
			anexo6 = new Anexo();
		}
		return anexo6;
	}

	public void setAnexo6(Anexo anexo6) {
		this.anexo6 = anexo6;
	}

	public Anexo getAnexo7() {
		if(anexo7 == null) {
			anexo7 = new Anexo();
		}
		return anexo7;
	}

	public void setAnexo7(Anexo anexo7) {
		this.anexo7 = anexo7;
	}

	public Integer getTipoLigacao() {
		return tipoLigacao;
	}

	public void setTipoLigacao(Integer tipoLigacao) {
		this.tipoLigacao = tipoLigacao;
	}

	public Anexo getFoto1() {
		return foto1;
	}

	public void setFoto1(Anexo foto1) {
		this.foto1 = foto1;
	}

	public Anexo getFoto2() {
		return foto2;
	}

	public void setFoto2(Anexo foto2) {
		this.foto2 = foto2;
	}

	public Anexo getFoto3() {
		return foto3;
	}

	public void setFoto3(Anexo foto3) {
		this.foto3 = foto3;
	}

	public Anexo getFoto4() {
		return foto4;
	}

	public void setFoto4(Anexo foto4) {
		this.foto4 = foto4;
	}

	public Anexo getFoto5() {
		return foto5;
	}

	public void setFoto5(Anexo foto5) {
		this.foto5 = foto5;
	}

	public Anexo getFoto6() {
		return foto6;
	}

	public void setFoto6(Anexo foto6) {
		this.foto6 = foto6;
	}

	public Anexo getFoto7() {
		return foto7;
	}

	public void setFoto7(Anexo foto7) {
		this.foto7 = foto7;
	}

	public Anexo getFoto8() {
		return foto8;
	}

	public void setFoto8(Anexo foto8) {
		this.foto8 = foto8;
	}

	public Boolean getCheckAcordo() {
		return checkAcordo;
	}

	public void setCheckAcordo(Boolean checkAcordo) {
		this.checkAcordo = checkAcordo;
	}

	public Collection<CidadeDTO> getCidades() {
		if(cidades == null) {
			cidades = new ArrayList<CidadeDTO>();
		}
		return cidades;
	}

	public void setCidades(Collection<CidadeDTO> cidades) {
		this.cidades = cidades;
	}

	public Boolean getAtcEncontrado() {
		if(atcEncontrado == null) {
			atcEncontrado = Boolean.FALSE;
		}
		return atcEncontrado;
	}

	public void setAtcEncontrado(Boolean atcEncontrado) {
		this.atcEncontrado = atcEncontrado;
	}

	public CidadeDTO getCidadeSelecionado() {
		return cidadeSelecionado;
	}

	public void setCidadeSelecionado(CidadeDTO cidadeSelecionado) {
		this.cidadeSelecionado = cidadeSelecionado;
	}

	public boolean getLiberarAnexos() {
		return liberarAnexos;
	}

	public void setLiberarAnexos(boolean liberarAnexos) {
		this.liberarAnexos = liberarAnexos;
	}
	
	public boolean isLiberaVizinhos() {
		return liberaVizinhos;
	}

	public void setLiberaVizinhos(boolean liberaVizinhos) {
		this.liberaVizinhos = liberaVizinhos;
	}

	public Integer getNotaFeedback() {
		ResourceBundle bundle = Feedback.getI18nResourceBundle();

		if (notaFeedback == null) {
			this.notaFeedback = Integer.parseInt(bundle.getObject("valor.padr�o.feedback").toString());
		}
		return notaFeedback;
	}

	public void setNotaFeedback(Integer notaFeedback) {
		this.notaFeedback = notaFeedback;
	}

	public Boolean getHabilitaFeedback() {
		if (this.habilitaFeedback == null) {
			this.habilitaFeedback = Boolean.FALSE;
		}
		return habilitaFeedback;
	}

	public void setHabilitaFeedback(Boolean habilitaFeedback) {
		this.habilitaFeedback = habilitaFeedback;
	}
	
	public String getComentarioFeedback() {
		if (this.comentarioFeedback == null) {
			this.comentarioFeedback = "";
		}
		return comentarioFeedback;
	}

	public void setComentarioFeedback(String comentarioFeedback) {
		this.comentarioFeedback = comentarioFeedback;
	}

	public void habilitarDescricaoFeedback() {
		System.out.println(getNotaFeedback());

		if (getNotaFeedback().equals(0)) {
			this.liberaOk = Boolean.TRUE;
		} else {
			this.liberaOk = Boolean.FALSE;
		}

		if ((getNotaFeedback() < 7 || getNotaFeedback().equals(11)) && getNotaFeedback() != 0) {
			this.habilitaFeedback = Boolean.TRUE;
		} else {
			this.habilitaFeedback = Boolean.FALSE;
		}

	}
	
	public Boolean getLiberaOk() {
		if (this.liberaOk == null) {
			this.liberaOk = Boolean.FALSE;
		}
		return liberaOk;
	}

	public void setLiberaOk(Boolean liberaOk) {
		this.liberaOk = liberaOk;
	}

	public boolean isLiberaBuscaVizinhos() {
		return liberaBuscaVizinhos;
	}

	public void setLiberaBuscaVizinhos(boolean liberaBuscaVizinhos) {
		this.liberaBuscaVizinhos = liberaBuscaVizinhos;
	}
	
}