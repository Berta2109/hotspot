
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for capinEntidadePublica complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="capinEntidadePublica">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoEntidade" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="codigoFace" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoOrgao" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "capinEntidadePublica", propOrder = {
    "codigoEntidade",
    "codigoFace",
    "codigoOrgao"
})
public class CapinEntidadePublica {

    protected Integer codigoEntidade;
    protected String codigoFace;
    protected Integer codigoOrgao;

    /**
     * Gets the value of the codigoEntidade property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCodigoEntidade() {
        return codigoEntidade;
    }

    /**
     * Sets the value of the codigoEntidade property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCodigoEntidade(Integer value) {
        this.codigoEntidade = value;
    }

    /**
     * Gets the value of the codigoFace property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoFace() {
        return codigoFace;
    }

    /**
     * Sets the value of the codigoFace property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoFace(String value) {
        this.codigoFace = value;
    }

    /**
     * Gets the value of the codigoOrgao property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCodigoOrgao() {
        return codigoOrgao;
    }

    /**
     * Sets the value of the codigoOrgao property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCodigoOrgao(Integer value) {
        this.codigoOrgao = value;
    }

}
