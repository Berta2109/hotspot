
package br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for capinEconomia complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="capinEconomia">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="comercial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="industrial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="publica" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="residencial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "capinEconomia", propOrder = {
    "comercial",
    "industrial",
    "publica",
    "residencial"
})
public class CapinEconomia {

    protected String comercial;
    protected String industrial;
    protected String publica;
    protected String residencial;

    /**
     * Gets the value of the comercial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComercial() {
        return comercial;
    }

    /**
     * Sets the value of the comercial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComercial(String value) {
        this.comercial = value;
    }

    /**
     * Gets the value of the industrial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndustrial() {
        return industrial;
    }

    /**
     * Sets the value of the industrial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndustrial(String value) {
        this.industrial = value;
    }

    /**
     * Gets the value of the publica property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublica() {
        return publica;
    }

    /**
     * Sets the value of the publica property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublica(String value) {
        this.publica = value;
    }

    /**
     * Gets the value of the residencial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidencial() {
        return residencial;
    }

    /**
     * Sets the value of the residencial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidencial(String value) {
        this.residencial = value;
    }

}
