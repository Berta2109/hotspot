package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.sabesp.sabesphotsitesolicitacoes.util.DescricaoEntidade;

@Entity
@Table(name = "TIPO_ONG_CSI")
public class TipoOng implements Serializable, DescricaoEntidade {

    private static final long serialVersionUID = 7747957103081727971L;

    @Id
    @Column(name = "CD_TIPO_ONG_CSI", nullable = false)
    private Integer id;
    
    @Column(name = "DC_TIPO_ONG_CSI", length = 100, nullable = false)
    private String descricao;
    
    @Column(name = "DT_INICIO_VIGENCIA", nullable = false)
    private Date dataInicioVigencia;
    
    @Column(name = "DT_FIM_VIGENCIA")
    private Date dataFimVigencia;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataInicioVigencia() {
        return dataInicioVigencia;
    }

    public void setDataInicioVigencia(Date dataInicioVigencia) {
        this.dataInicioVigencia = dataInicioVigencia;
    }

    public Date getDataFimVigencia() {
        return dataFimVigencia;
    }

    public void setDataFimVigencia(Date dataFimVigencia) {
        this.dataFimVigencia = dataFimVigencia;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TipoOng other = (TipoOng) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
