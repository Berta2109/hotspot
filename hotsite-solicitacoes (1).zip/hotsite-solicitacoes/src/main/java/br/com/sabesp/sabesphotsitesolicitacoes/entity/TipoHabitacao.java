package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import br.com.sabesp.sabesphotsitesolicitacoes.util.DescricaoEntidade;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "TIPO_HABITACAO")
public class TipoHabitacao implements Serializable, DescricaoEntidade {



	private static final long serialVersionUID = 5718017933820851056L;

	@Id
	@Column(name = "CD_TIPO_HABITACAO")
	private Integer id;

	@Column(name = "DC_TIPO_HABITACAO")
	private String descricao;

	public TipoHabitacao() {
	}

	public TipoHabitacao(Integer id, String descricao) {
		super();
		this.id = id;
		this.descricao = descricao;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TipoHabitacao)) {
			return false;
		}
		TipoHabitacao other = (TipoHabitacao) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
