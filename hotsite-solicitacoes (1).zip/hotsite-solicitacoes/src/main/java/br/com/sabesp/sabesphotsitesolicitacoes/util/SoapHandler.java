package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.LogicalMessage;
import javax.xml.ws.handler.LogicalHandler;
import javax.xml.ws.handler.LogicalMessageContext;
import javax.xml.ws.handler.MessageContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SoapHandler implements  LogicalHandler<LogicalMessageContext> {

	private static final Logger LOG = LoggerFactory.getLogger(SoapHandler.class);

	public SoapHandler() {
	}

	@Override
	public void close(MessageContext arg0) {
	}

	@Override
	public boolean handleFault(LogicalMessageContext arg0) {
		return processMessage(arg0);
	}

	@Override
	public boolean handleMessage(LogicalMessageContext arg0) {
		return processMessage(arg0);
	}

	private boolean processMessage(LogicalMessageContext context) {
		try {
			Boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
			StringBuilder to = new StringBuilder();
			if (outboundProperty) {
				to.append("Massa de entrada SOAP ::: ");
			} else {
				to.append("Massa de retorno SOAP ::: ");
			}
			LogicalMessage lm = context.getMessage();
			Source payload = lm.getPayload();
			String xml = parseToXML(payload);
			to.append("[").append(xml).append("]");

			LOG.error(to.toString());
		} catch (Exception e) {
			LOG.error("falha gerar log mensagem SOAP", e);
		}

		return true;
	}

	private static String parseToXML(Source source) {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			StringWriter sw = new StringWriter();
			transformer.transform(source, new StreamResult(sw));
			return sw.toString();
		} catch (TransformerConfigurationException e) {
			throw new IllegalStateException(e);
		} catch (TransformerException e) {
			throw new IllegalStateException(e);
		}
	}
}
