package br.com.sabesp.sabesphotsitesolicitacoes.entity;

public enum TipoOperacaoDoacaoAgua {

    INDEFINIDO("I"),
    DOACAO("D"),
    CANCELAMENTO("C");

    private final String valor;

    TipoOperacaoDoacaoAgua(String valor) {
        this.valor = valor;
    }

    public String getValor() {
        return valor;
    }

    public static TipoOperacaoDoacaoAgua getPorValor(String valor) {
        if (valor == null) {
            return INDEFINIDO;
        } else {
            for (TipoOperacaoDoacaoAgua tipo : TipoOperacaoDoacaoAgua.values()) {
                if (tipo.valor.equals(valor)) {
                    return tipo;
                }
            }
            
            return INDEFINIDO;
        }
    }
}
