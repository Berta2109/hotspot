package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "SOLICITACAO_SERVICO")
public class SolicitacaoServico implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -165549876777420828L;

    @Id
    @SequenceGenerator(name = "SEQ_SOLICITACAO_SERVICO", sequenceName = "SEQ_SOLICITACAO_SERVICO", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SOLICITACAO_SERVICO")
    @Column(name = "CD_SOLICITACAO_SERVICO")
    private Long id;

    @NotNull
    @Column(name = "CD_TIPO_SERVICO")
    private Integer tipoServico;

    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_SOLICITACAO_SERVICO")
    private Date dataCadastro;

    @NotNull
    @Column(name = "NR_ENDERECO_IP")
    private String enderecoIp;

    @NotNull
    @Column(name = "CD_STATUS_ENVIO_EMAIL")
    private Integer statusEnvioEmail;

    @Column(name = "TX_ERRO_ENVIO_EMAIL")
    private String erroEnvioEmail;

    @NotNull
    @Column(name = "NR_RGI_PDE")
    private Long rgi;

    @NotNull
    @Column(name = "NR_CPF_CNPJ_TITULAR")
    private String cpf;

    @NotNull
    @Column(name = "NM_SOLICITANTE")
    @Size(min = 1, max = 100)
    private String nome;

    @NotNull
    @Column(name = "NR_TELEFONE_CONTATO")
    @Size(min = 1, max = 20)
    private String telefone;

    @NotNull
    @Column(name = "DC_EMAIL")
    @Size(min = 1, max = 100)
    private String email;

    @Column(name = "TX_OBSERVACAO")
    @Size(max = 300)
    private String observacoes;

    @Column(name = "DC_PROTOCOLO_ATENDIMENTO")
    private String protocolo;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "CD_ATENDIMENTO_COMERCIAL")
    private AtendimentoComercial atendimentoComercial;
    
    @Column(name = "NR_FORNECIMENTO")
    private String nrFornecimento;

    @Transient
    private String endereco;

    public SolicitacaoServico() {
        dataCadastro = new Date();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(Integer tipoServico) {
        this.tipoServico = tipoServico;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public String getEnderecoIp() {
        return enderecoIp;
    }

    public void setEnderecoIp(String enderecoIp) {
        this.enderecoIp = enderecoIp;
    }

    public Integer getStatusEnvioEmail() {
        return statusEnvioEmail;
    }

    public void setStatusEnvioEmail(Integer statusEnvioEmail) {
        this.statusEnvioEmail = statusEnvioEmail;
    }

    public String getErroEnvioEmail() {
        return erroEnvioEmail;
    }

    public void setErroEnvioEmail(String erroEnvioEmail) {
        this.erroEnvioEmail = erroEnvioEmail;
    }

    public Long getRgi() {
        return rgi;
    }

    public void setRgi(Long rgi) {
        this.rgi = rgi;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(String protocolo) {
        this.protocolo = protocolo;
    }

    public AtendimentoComercial getAtendimentoComercial() {
        return atendimentoComercial;
    }

    public void setAtendimentoComercial(AtendimentoComercial atendimentoComercial) {
        this.atendimentoComercial = atendimentoComercial;
    }
    
    public String getNrFornecimento() {
		return nrFornecimento;
	}

	public void setNrFornecimento(String nrFornecimento) {
		this.nrFornecimento = nrFornecimento;
	}
	
	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SolicitacaoServico)) {
            return false;
        }
        SolicitacaoServico other = (SolicitacaoServico) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }


}
