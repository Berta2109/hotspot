
package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;
import java.util.Date;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

public class SolicitacaoDesassociacao implements Serializable {

	private static final long serialVersionUID = 1490459210368566107L;
	
	private TipoServico tipoServico;
    private String tipoPessoa;
    private String cpfCnpj;
    private String nomeSolicitante;
    private String telefone;
    private String email;
    private String protocolo;
    private Date dataCadastro;
    private DadosRGI dados;
    private String motivoEncerramento;
    private Boolean representateLegal;
    private Boolean estatalFederal;
    private String PFouPJ;
    
    private Anexo documentoRepresentateLegal;
    private Anexo documentoEstatalFederal;
    
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    
    public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public SolicitacaoDesassociacao() {
        dataCadastro = new Date();
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getNomeSolicitante() {
        return nomeSolicitante;
    }

    public void setNomeSolicitante(String nomeSolicitante) {
        this.nomeSolicitante = nomeSolicitante;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public DadosRGI getDados() {
        return dados;
    }

    public void setDados(DadosRGI dados) {
        this.dados = dados;
    }

    public String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(String protocolo) {
        this.protocolo = protocolo;
    }

	public String getMotivoEncerramento() {
		return motivoEncerramento;
	}

	public void setMotivoEncerramento(String motivoEncerramento) {
		this.motivoEncerramento = motivoEncerramento;
	}

	public Boolean getRepresentateLegal() {
		return representateLegal;
	}

	public void setRepresentateLegal(Boolean representateLegal) {
		this.representateLegal = representateLegal;
	}

	public Boolean getEstatalFederal() {
		return estatalFederal;
	}

	public void setEstatalFederal(Boolean estatalFederal) {
		this.estatalFederal = estatalFederal;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public TipoServico getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(TipoServico tipoServico) {
		this.tipoServico = tipoServico;
	}

	public Anexo getDocumentoEstatalFederal() {
		return documentoEstatalFederal;
	}

	public void setDocumentoEstatalFederal(Anexo documentoEstatalFederal) {
		this.documentoEstatalFederal = documentoEstatalFederal;
	}
	
	public Anexo getDocumentoRepresentateLegal() {
		return documentoRepresentateLegal;
	}

	public void setDocumentoRepresentateLegal(Anexo documentoRepresentateLegal) {
		this.documentoRepresentateLegal = documentoRepresentateLegal;
	}

	public String getPFouPJ() {
		return PFouPJ;
	}

	public void setPFouPJ(String pFouPJ) {
		PFouPJ = pFouPJ;
	}
}
