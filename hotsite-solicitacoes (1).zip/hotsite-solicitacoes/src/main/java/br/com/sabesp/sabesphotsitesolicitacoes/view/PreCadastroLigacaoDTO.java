package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.util.ArrayList;
import java.util.List;

public class PreCadastroLigacaoDTO {
	
	private List<LogradouroDTO> logradouros;
	private LogradouroDTO logradouro;
	private String numero;
	private String complemento;
	private List<Vizinho> vizinhos;
	
	public List<LogradouroDTO> getLogradouros() {
		if(logradouros == null) {
			logradouros = new ArrayList<LogradouroDTO>();
		}
		return logradouros;
	}
	public void setLogradouros(List<LogradouroDTO> logradouros) {
		this.logradouros = logradouros;
	}
	public LogradouroDTO getLogradouro() {
		if(logradouro == null) {
			logradouro = new LogradouroDTO();
		}
		return logradouro;
	}
	public void setLogradouro(LogradouroDTO logradouro) {
		this.logradouro = logradouro;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public List<Vizinho> getVizinhos() {
		if(vizinhos == null) {
			vizinhos = new ArrayList<Vizinho>();
//			Vizinho v = new Vizinho();
//			v.setCodigo("1");
//			v.setNumero("12");
//			v.setComplemento("casa 2");
//			
//			Vizinho v2 = new Vizinho();
//			v2.setCodigo("2");
//			v2.setNumero("11");
//			v2.setComplemento("casa 3");
//			
//			vizinhos.add(v);
//			vizinhos.add(v2);
		}
		return vizinhos;
	}
	public void setVizinhos(List<Vizinho> vizinhos) {
		this.vizinhos = vizinhos;
	}
}
