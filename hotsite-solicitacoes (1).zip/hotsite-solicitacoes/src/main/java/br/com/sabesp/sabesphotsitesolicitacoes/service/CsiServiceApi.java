
package br.com.sabesp.sabesphotsitesolicitacoes.service;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.sabesp.csia.jsp.ispecs.AVDOAIspecModel;
//import com.unisys.jellybeans.IspecModel;
//import com.unisys.jellybeans.ResponseCodePredicates;

import br.com.sabesp.sabesphotsitesolicitacoes.exception.SabespFacilServiceException;
import br.com.sabesp.sabesphotsitesolicitacoes.service.csi.CsiService;
import br.com.sabesp.sabesphotsitesolicitacoes.service.csi.CsiServiceApiImpl;
import br.com.sabesp.sabesphotsitesolicitacoes.service.model.DoacaoAguaCsiModel;

@RequestScoped
public class CsiServiceApi {

    private static Logger LOGGER = LoggerFactory.getLogger(CsiServiceApiImpl.class);

    @Inject
    private CsiService servicoCsi;

    @PostConstruct
    public void inicializar() {
//        servicoCsi.autorizar();
    }

    public void salvarSolicitacaoDoacao(DoacaoAguaCsiModel modeloDoacaoAguaCsi) {
        try {
//            IspecModel ispec = servicoCsi.autorizar(DoacaoAguaCsiModel.TELA);

//            if (!(ispec.getClass().getName().equalsIgnoreCase(AVDOAIspecModel.class.getName()))) {
//                throw new SabespFacilServiceException();
//            }
//
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_RGI, modeloDoacaoAguaCsi.getNumeroRgi());
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_CPF_CNPJ, modeloDoacaoAguaCsi.getCpfCnpj());
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_CODIGO_MUNICIPIO,
//                    modeloDoacaoAguaCsi.getCodigoMunicipio());
//
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_CODIGO_CLIENTE,
//                    modeloDoacaoAguaCsi.getCodigoCliente());
//
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_CODIGO_ONG, modeloDoacaoAguaCsi.getCodigoOng());
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_DATA_FIM_INTENCAO_DOACAO,
//                    modeloDoacaoAguaCsi.getDataFimIntecaoDoacao());
//
//            ispec.setValue(DoacaoAguaCsiModel.CAMPO_VALOR_DOACAO,
//                    modeloDoacaoAguaCsi.getValorDoacao());
//
//            if (!ResponseCodePredicates.isOK(servicoCsi.executar())) {
//                throw new SabespFacilServiceException();
//            }

        } catch (Exception excecao) {
            LOGGER.error("Falha ao salvar a solicita��o de doa��o no CSI", excecao);

            throw new SabespFacilServiceException(excecao.getMessage());
        }
    }
}
