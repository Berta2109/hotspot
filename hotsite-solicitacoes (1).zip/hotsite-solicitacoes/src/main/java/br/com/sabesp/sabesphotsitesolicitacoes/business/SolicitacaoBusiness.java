package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.persistence.Query;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.AnexoSolicitacaoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.AtendimentoComercial;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Atestado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Beneficio;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.CadastroUnidadeConsumo;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosBancarios;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DadosCadastro;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.Desassociacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.DoacaoContaAgua;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.EnderecoDesassociacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.EnderecoPreCadastro;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.FaleConosco;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.LogDoacaoContaAgua;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.ModificacaoLigacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.PesquisaSatisfacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SolicitacaoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.SupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TarifaSocialDesempregado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TarifaSocialUnifamiliar;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoAtestado;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoBeneficio;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoHabitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoOperacaoDoacaoAgua;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoServico;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoSupressaoReligacao;
import br.com.sabesp.sabesphotsitesolicitacoes.entity.TransferenciaTitularidadeDebitos;
import br.com.sabesp.sabesphotsitesolicitacoes.service.CsiServiceApi;
import br.com.sabesp.sabesphotsitesolicitacoes.service.model.DoacaoAguaCsiModel;
import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Feedback;
import br.com.sabesp.sabesphotsitesolicitacoes.util.GenericRepository;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Preferencias.Propriedades;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatDate;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatFile;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatNumber;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;
import br.com.sabesp.sabesphotsitesolicitacoes.util.ValidacaoException;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Anexo;
import br.com.sabesp.sabesphotsitesolicitacoes.view.Solicitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoDesassociacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoDoacao;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoFaleConosco;
import br.com.sabesp.sabesphotsitesolicitacoes.view.SolicitacaoUnidadeConsumo;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

@Stateless
public class SolicitacaoBusiness {

    private static final Integer NAO_HA_HABITACAO = 5;

	@EJB
    private GenericRepository repository;
    
    @Inject
    private CsiServiceApi apiServicoCsi;

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public void validarPreenchimento(Solicitacao solicitacao, Collection<Anexo> anexos) {
        validarPreenchimentoPorTipoServico(solicitacao);
        Collection<Anexo> anexosSelecionados = selecionarAnexosSalvar(solicitacao, anexos);

        for (Anexo test : anexosSelecionados) {
        	if(test != null) {
        		 if (!test.getObrigatorio()) {
                     continue;
                 }
                 if (!test.getIsInformado()) {
                     throw new ValidacaoException("anexosolicitacao.msg.documentonaotevearquivoselecionado", Feedback.getMsg(test.getDocumentoI18n()));
                 }
        	}
        }
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public void validarPreenchimento(SolicitacaoUnidadeConsumo solicitacao, Collection<Anexo> anexos) {
        Collection<Anexo> anexosSelecionados = selecionarAnexosSalvar(solicitacao, anexos);

        for (Anexo test : anexosSelecionados) {
        	if(test != null) {
        		 if (!test.getObrigatorio()) {
                     continue;
                 }
                 if (!test.getIsInformado()) {
                     throw new ValidacaoException("anexosolicitacao.msg.documentonaotevearquivoselecionado", Feedback.getMsg(test.getDocumentoI18n()));
                 }
        	}
        }
    }

    private void validarPreenchimentoPorTipoServico(Solicitacao solicitacao) {
        if (solicitacao.getTipoServico().getAtualizarDadosCadastrais()) {
            if (!solicitacao.getSolicitante().getDadosCadastro().validarTelefoneUnico()){
                throw new ValidacaoException("solicitante.telefone.obrigatorio", StringUtils.EMPTY);
            }
            if(TreatString.filterOnlyNumber(solicitacao.getSolicitante().getCpfCnpj()).length() <= 11) {
            	if(!BrasilUtils.isCPFValid(solicitacao.getSolicitante().getCpfCnpj())) {
            		throw new ValidacaoException("custom.validator.cpfCnpjValidator", StringUtils.EMPTY);
            	}
            } else {
            	if(!BrasilUtils.isCNPJValid(solicitacao.getSolicitante().getCpfCnpj())) {
            		throw new ValidacaoException("custom.validator.cpfCnpjValidator", StringUtils.EMPTY);
            	}
            }
        }
        
        if(solicitacao.getChecagemAvisosDocumentacao().getCheck() != null 
        		&& solicitacao.getChecagemAvisosDocumentacao().getCheck() == Boolean.FALSE) {
        	throw new ValidacaoException("validacao.check.documentacao", StringUtils.EMPTY);
        } else if(solicitacao.getChecagemAvisosDocumentacao().getCheck1() != null 
        		&& solicitacao.getChecagemAvisosDocumentacao().getCheck1() == Boolean.FALSE) {
        	throw new ValidacaoException("validacao.check.documentacao", StringUtils.EMPTY);
        } else if(solicitacao.getChecagemAvisosDocumentacao().getCheck2() != null 
        		&& solicitacao.getChecagemAvisosDocumentacao().getCheck2() == Boolean.FALSE) {
        	throw new ValidacaoException("validacao.check.documentacao", StringUtils.EMPTY);
        } else if(solicitacao.getChecagemAvisosDocumentacao().getCheck3() != null 
        		&& solicitacao.getChecagemAvisosDocumentacao().getCheck3() == Boolean.FALSE) {
        	throw new ValidacaoException("validacao.check.documentacao", StringUtils.EMPTY);
        } else if(solicitacao.getChecagemAvisosDocumentacao().getCheck4() != null 
        		&& solicitacao.getChecagemAvisosDocumentacao().getCheck4() == Boolean.FALSE) {
        	throw new ValidacaoException("validacao.check.documentacao", StringUtils.EMPTY);
        }
    }

    /**
     * Metodo responsavel por salvar a solicitacao
     *
     * @param solicitacao
     * @param anexos
     * @return
     * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
     * @since 12 de abr de 2020 (Projeto)
     */
    public SolicitacaoServico salvarSolicitacao(Solicitacao solicitacao, Collection<Anexo> anexos) {

        try {

            SolicitacaoServico edicao = new SolicitacaoServico();
            edicao.setTipoServico(solicitacao.getTipoServico().getCodigo());
            
        	edicao.setCpf(TreatString.filterOnlyNumber(solicitacao.getSolicitante().getCpfCnpj()));
            
            edicao.setNome(solicitacao.getSolicitante().getNome());
            edicao.setEmail(solicitacao.getSolicitante().getEmail());
            edicao.setTelefone(TreatString.filterOnlyNumber(solicitacao.getSolicitante().getTelefone()));
            edicao.setEnderecoIp(solicitacao.getIp());
            edicao.setObservacoes(solicitacao.getObservacoes());
            edicao.setRgi(Long.valueOf(solicitacao.getDados().getNumero()));
            edicao.setStatusEnvioEmail(solicitacao.getTipoServico().getStatusEnvioEmailInicial());
            edicao.setNrFornecimento(solicitacao.getFornecimento());
            
            AtendimentoComercial atendimentoComercial = repository.findById(AtendimentoComercial.class, solicitacao.getDados().getAtendimentoComercialATC());
            edicao.setAtendimentoComercial(atendimentoComercial);

            edicao.setProtocolo(this.gerarProtocoloAtendimento(atendimentoComercial.getId()));
            repository.insert(edicao);

            if (solicitacao.getTipoServico().getPermiteTrocaTipoSolicitante()) {
                TransferenciaTitularidadeDebitos atestado = new TransferenciaTitularidadeDebitos();
                atestado.setSolicitacao(edicao);
                atestado.setTipo(solicitacao.getSolicitante().getTipo());
                atestado.setRepresentateLegal(
                        solicitacao.getSolicitante().getRepresentanteLegal() != null && solicitacao.getSolicitante().getRepresentanteLegal());
                repository.insert(atestado);
            }
            if (solicitacao.getTipoServico().getUsaDadosBancariosSolicitante()) {
                DadosBancarios dadosBancarios = new DadosBancarios();
                dadosBancarios.setSolicitacao(edicao);
                dadosBancarios.setAgencia(solicitacao.getSolicitante().getDadosBancarios().getAgencia());
                dadosBancarios.setConta(solicitacao.getSolicitante().getDadosBancarios().getConta());
                dadosBancarios.setInstituicao(solicitacao.getSolicitante().getDadosBancarios().getInstituicao());
                dadosBancarios.setTipoConta(solicitacao.getSolicitante().getDadosBancarios().getTipoConta());
                repository.insert(dadosBancarios);
            }

            if (solicitacao.getTipoServico().getAtualizarDadosCadastrais()) {
                DadosCadastro dadosCadastro = new DadosCadastro();
                dadosCadastro.setSolicitacao(edicao);
                dadosCadastro.setNome(solicitacao.getSolicitante().getDadosCadastro().getNome());
                dadosCadastro.setTelefoneCelular(getTelefoneCadastro(solicitacao.getSolicitante().getDadosCadastro().getTelefoneCelularTr()));
                dadosCadastro.setTelefoneFixo(getTelefoneCadastro(solicitacao.getSolicitante().getDadosCadastro().getTelefoneFixoTr()));
                dadosCadastro.setDataNascimento(getDatanascimento(solicitacao.getSolicitante().getDadosCadastro().getDataNascimentoStr()));
                dadosCadastro.setEmail(solicitacao.getSolicitante().getDadosCadastro().getEmail());
                dadosCadastro.setLogradouro(solicitacao.getSolicitante().getDadosCadastro().getLogradouro());
                dadosCadastro.setNumero(solicitacao.getSolicitante().getDadosCadastro().getNumero());
                dadosCadastro.setComplemento(solicitacao.getSolicitante().getDadosCadastro().getComplemento());
                dadosCadastro.setBairro(solicitacao.getSolicitante().getDadosCadastro().getBairro());
                dadosCadastro.setCep(solicitacao.getSolicitante().getDadosCadastro().getCep());
                dadosCadastro.setCidade(solicitacao.getSolicitante().getDadosCadastro().getCidade());
                dadosCadastro.setTipo(solicitacao.getSolicitante().getTipo());
                dadosCadastro.setRepresentanteLegal(solicitacao.getSolicitante().getRepresentanteLegal());
                dadosCadastro.setDataLeitura(getDataLeitura(solicitacao.getSolicitante().getDadosCadastro().getDataLeituraStr()));
                dadosCadastro.setValorLeitura(solicitacao.getSolicitante().getDadosCadastro().getValorLeitura());
                repository.insert(dadosCadastro);
            }

            if (solicitacao.getTipoServico().getUsaTiposAtestado()) {
                Atestado atestado = new Atestado();
                atestado.setSolicitacao(edicao);
                atestado.setAno(solicitacao.getAtestado().getAno());
                atestado.setRepresentateLegal(solicitacao.getSolicitante().getRepresentanteLegal());
                atestado.setTipo(repository.findById(TipoAtestado.class, solicitacao.getAtestado().getTipo().getId()));
                repository.insert(atestado);
            }
            if (solicitacao.getTipoServico().getUsaTiposBeneficio()) {
                Beneficio beneficio = new Beneficio();
                beneficio.setSolicitacao(edicao);
                beneficio.setTipo(repository.findById(TipoBeneficio.class, solicitacao.getBeneficio().getTipo().getId()));
                repository.insert(beneficio);
            }
			/*
			 * if (solicitacao.getTipoServico().is(TipoServico.CORRECAO_LEITURA_POR_MEDIA))
			 * { DadosLeitura leitura = new DadosLeitura(); leitura.setSolicitacao(edicao);
			 * leitura.setData(solicitacao.getDadosLeitura().getData());
			 * leitura.setValor(solicitacao.getDadosLeitura().getValor());
			 * repository.insert(leitura); }
			 */
            if (solicitacao.getTipoServico().getUsaTiposSupressao()) {
                SupressaoReligacao supressao = new SupressaoReligacao();
                supressao.setSolicitacao(edicao);
                supressao.setTipo(repository.findById(TipoSupressaoReligacao.class, solicitacao.getSupressao().getTipo().getId()));
                repository.insert(supressao);
            }

            if (solicitacao.getTipoServico().getUsaTiposHabitacao()){
                CadastroUnidadeConsumo cadastroUnidadeConsumo = new CadastroUnidadeConsumo();
                cadastroUnidadeConsumo.setSolicitacao(edicao);
                cadastroUnidadeConsumo.setTipo(solicitacao.getSolicitante().getTipo());
                cadastroUnidadeConsumo.setRepresentateLegal(solicitacao.getSolicitante().getRepresentanteLegal());
                cadastroUnidadeConsumo.setTipoHabitacao(solicitacao.getSolicitante().getTipoHabitacao().getId());
                repository.insert(cadastroUnidadeConsumo);
            }
            
            if(solicitacao.getTipoServico().getTarifaSocialUnifamiliar()) {
            	TarifaSocialUnifamiliar tarifaSocialUnifamiliar = new TarifaSocialUnifamiliar();
            	tarifaSocialUnifamiliar.setSolicitacao(edicao);
            	tarifaSocialUnifamiliar.setTrabalhadorInformal(solicitacao.getTarifaSocialUnifamiliar().getTrabalhadorInformal());
            	tarifaSocialUnifamiliar.setNaoPossuiComprovante(solicitacao.getTarifaSocialUnifamiliar().getNaoPossuiComprovante());
            	repository.insert(tarifaSocialUnifamiliar);
            }
            
            if(solicitacao.getTipoServico().getTarifaSocialDesempregado()) {
            	TarifaSocialDesempregado tarifaSocialDesempregado = new TarifaSocialDesempregado();
            	tarifaSocialDesempregado.setSolicitacao(edicao);
            	tarifaSocialDesempregado.setTrabalhadorInformal(solicitacao.getTarifaSocialDesempregado().getTrabalhadorInformal());
            	repository.insert(tarifaSocialDesempregado);
            	
            }
            
            if(solicitacao.getTipoServico().getUsaServicosSolicitacao()) {
            	ModificacaoLigacao modificacaoLigacao = new ModificacaoLigacao();
            	modificacaoLigacao.setSolicitacao(edicao);
            	modificacaoLigacao.setRepresentateLegal(solicitacao.getSolicitante().getRepresentanteLegal());
            	modificacaoLigacao.setServicoRealizar(solicitacao.getServicoSolicitacao().getCodigo());
            	repository.insert(modificacaoLigacao);
            }
            
            Collection<Anexo> anexosSelecionados = selecionarAnexosSalvar(solicitacao, anexos);
            persistirAnexosSolicitacao(edicao, solicitacao.getTipoServico(), anexosSelecionados);
            return edicao;
        } catch (Exception e) {
            Feedback.erroOperacao(this, "falha salvar solicitacao", e);
            throw new ValidacaoException("solicitacao.msg.falhasalvar");
        }
    }
    
    public DoacaoContaAgua salvarSolicitacaoDoacaoAgua(SolicitacaoDoacao solicitacaoDoacao) {
        try {
            DoacaoContaAgua doacaoExistente = recuperarDoadorPorContaAgua(solicitacaoDoacao);
            
            return doacaoExistente == null
                    ? incluirDoacaoAgua(solicitacaoDoacao)
                    : atualizarDoacaoAgua(doacaoExistente, solicitacaoDoacao);

        } catch (ValidacaoException e) {
            throw e;
        } catch (Exception e) {
            Feedback.erroOperacao(this, "falha salvar solicitacao", e);
            throw new ValidacaoException("solicitacao.msg.falhasalvar");
        }
    }

    private DoacaoContaAgua recuperarDoadorPorContaAgua(SolicitacaoDoacao solicitacaoDoacao) {
        String consulta = "SELECT d FROM DoacaoContaAgua d WHERE d.rgi = ? AND d.cpfCnpj = ? AND d.codigoTipoOng = ?";

        Long numeroRgi = extrairNumeroRgi(solicitacaoDoacao);
        Integer idOng = solicitacaoDoacao.getTipoOng().getId();
        String cpfCnpj = TreatString.removeSpecialChar(solicitacaoDoacao.getCpfCnpj());

        return repository.searchUniqueResult(DoacaoContaAgua.class, consulta, numeroRgi, cpfCnpj,
                idOng);
    }

    private DoacaoContaAgua atualizarDoacaoAgua(DoacaoContaAgua doacaoContaAgua,
            SolicitacaoDoacao solicitacaoDoacao) {

        if (solicitacaoDoacao.isOperacaoDoacao()) {
            return fazerDoacao(doacaoContaAgua, solicitacaoDoacao);
        } else if (solicitacaoDoacao.isOperacaoCancelamento()) {
            return fazerCancelamento(doacaoContaAgua, solicitacaoDoacao);
        } else {
            Feedback.erroOperacao(this, "Opera��o de solicita��o de doa��o n�o permitida",
                    null);

            throw new ValidacaoException("solicitacao.doacao.msg.operacaonaopermitida");
        }
    }

    private DoacaoContaAgua fazerDoacao(DoacaoContaAgua doacaoContaAgua,
            SolicitacaoDoacao solicitacaoDoacao) {

        if (doacaoContaAgua.getDoacaoAtiva()) {
            Feedback.erroOperacao(this, "Doa��o j� realizada", null);

            throw new ValidacaoException("solicitacao.doacao.msg.doacaonaopermitida");
        } else {
            return realizarDoacaoAgua(doacaoContaAgua, solicitacaoDoacao);
        }
    }

    private DoacaoContaAgua fazerCancelamento(DoacaoContaAgua doacaoContaAgua,
            SolicitacaoDoacao solicitacaoDoacao) {

        if (doacaoContaAgua.getDoacaoAtiva()) {
            return cancelarDoacaoAgua(solicitacaoDoacao, doacaoContaAgua);
        } else {
            Feedback.erroOperacao(this, "Cancelamento j� realizada", null);

            throw new ValidacaoException("solicitacao.doacao.msg.cancelamentonaopermitida");
        }
    } 

    private DoacaoContaAgua incluirDoacaoAgua(SolicitacaoDoacao solicitacaoDoacao) {
        if (solicitacaoDoacao.isOperacaoCancelamento()) {
            throw new ValidacaoException("solicitacao.doacao.msg.cancelamentonaopermitida");
        }

        AtendimentoComercial atendimentoComercial = 
                definirAtendimentoComercial(solicitacaoDoacao.getDados());

        DoacaoContaAgua doacaoContaAgua = new DoacaoContaAgua();

        Long numeroRgi = extrairNumeroRgi(solicitacaoDoacao);
        String cpfCnpj = TreatString.removeSpecialChar(solicitacaoDoacao.getCpfCnpj());
        BigDecimal valorDoacao = BigDecimal.valueOf(solicitacaoDoacao.getValorDoacao());

        doacaoContaAgua.setRgi(numeroRgi);
        doacaoContaAgua.setTipoServico(TipoServico.DOACAO_POR_MEIO_CONTA_AGUA.getCodigo());
        doacaoContaAgua.setCodigoTipoOng(solicitacaoDoacao.getTipoOng().getId());
        doacaoContaAgua.setTipoPessoa(cpfCnpj.length() == 11 ? "F" : "J");
        doacaoContaAgua.setEnderecoIp(Feedback.getIP());
        doacaoContaAgua.setDoacaoAtiva(Boolean.TRUE);
        doacaoContaAgua.setDataDoacao(new Date());
        doacaoContaAgua.setCpfCnpj(cpfCnpj);
        doacaoContaAgua.setNome(solicitacaoDoacao.getNomeSolicitante());
        doacaoContaAgua.setTelefone(TreatString.removeSpecialChar(solicitacaoDoacao.getTelefone()));
        doacaoContaAgua.setEmail(solicitacaoDoacao.getEmail());
        doacaoContaAgua.setValorDoacao(valorDoacao);
        doacaoContaAgua.setAtendimentoComercial(atendimentoComercial);
        doacaoContaAgua.setProtocolo(gerarProtocoloAtendimentoDoacao(atendimentoComercial.getId()));
        doacaoContaAgua.setCodigoCliente(solicitacaoDoacao.getDados().getCodigoCliente());
        doacaoContaAgua.setCodigoMunicipio(solicitacaoDoacao.getDados().getCodigoMunicipio());

        DoacaoContaAgua doacaoContaAguaSalva = repository.insert(doacaoContaAgua);
        incluirLogDoacaoContaAgua(TipoOperacaoDoacaoAgua.DOACAO, doacaoContaAguaSalva);

        enviarSolicitacaoDoacaoMainframe(doacaoContaAguaSalva);

        return doacaoContaAgua;
    }
    
    public SolicitacaoServico salvarUnidadeConsumo(SolicitacaoUnidadeConsumo solicitacaoUnidadeConsumo, Solicitacao solicitacao, Collection<Anexo> anexos) {
    	try {
	    	SolicitacaoServico solicitacaoServico = new SolicitacaoServico();
	    	solicitacaoServico.setTipoServico(solicitacao.getTipoServico().getCodigo());
	    	solicitacaoServico.setCpf(TreatString.filterOnlyNumber(solicitacao.getSolicitante().getCpfCnpj()));
	    	solicitacaoServico.setNome(solicitacaoUnidadeConsumo.getNomeSolicitante());
	    	solicitacaoServico.setEmail(solicitacaoUnidadeConsumo.getEmail());
	    	solicitacaoServico.setTelefone(TreatString.filterOnlyNumber(solicitacaoUnidadeConsumo.getTelefone()));
	    	solicitacaoServico.setEnderecoIp(solicitacao.getIp());
	    	solicitacaoServico.setRgi(Long.valueOf(solicitacao.getDados().getNumero()));
	    	solicitacaoServico.setEnderecoIp(solicitacao.getIp());
	    	solicitacaoServico.setStatusEnvioEmail(solicitacao.getTipoServico().getStatusEnvioEmailInicial());
	        AtendimentoComercial atendimentoComercial = repository.findById(AtendimentoComercial.class, solicitacao.getDados().getAtendimentoComercialATC());
	        solicitacaoServico.setAtendimentoComercial(atendimentoComercial);
	        solicitacaoServico.setProtocolo(this.gerarProtocoloAtendimento(atendimentoComercial.getId()));
	        repository.insert(solicitacaoServico);
	    	
	        CadastroUnidadeConsumo unidadeConsumo = new CadastroUnidadeConsumo();
	        unidadeConsumo.setSolicitacao(solicitacaoServico);
	    	unidadeConsumo.setTipoUnidade(solicitacaoUnidadeConsumo.getTipoUnidade());
	    	unidadeConsumo.setQtUnidadeAutonoma(solicitacaoUnidadeConsumo.getUnidadeAutonoma() != null ? Integer.valueOf(solicitacaoUnidadeConsumo.getUnidadeAutonoma()) : null);
	    	unidadeConsumo.setQtUnidadeResendencial(solicitacaoUnidadeConsumo.getUnidadeResendencial() != null ? Integer.valueOf(solicitacaoUnidadeConsumo.getUnidadeResendencial()) : null);
	    	unidadeConsumo.setQtUnidadeNaoResidencial(solicitacaoUnidadeConsumo.getUnidadeNaoResidencial() != null ? Integer.valueOf(solicitacaoUnidadeConsumo.getUnidadeNaoResidencial()) : null);
	    	unidadeConsumo.setPossuiEscritura(solicitacaoUnidadeConsumo.getPossuiEscritura());
	    	unidadeConsumo.setNaoPossuiEscritura(solicitacaoUnidadeConsumo.getNaoPossuiEscritura());
	    	unidadeConsumo.setPropriedadeExclusiva(solicitacaoUnidadeConsumo.getPropriedadeExclusiva());
	    	unidadeConsumo.setResidenciaColetiva(solicitacaoUnidadeConsumo.getResidenciaColetiva());
	    	unidadeConsumo.setRepresentateLegal(solicitacao.getSolicitante().getRepresentanteLegal());
	    	unidadeConsumo.setTipoHabitacao(solicitacaoUnidadeConsumo.getTipoHabitacao() != null ? solicitacaoUnidadeConsumo.getTipoHabitacao().getId() : NAO_HA_HABITACAO);
	    	unidadeConsumo.setCadastroCategoria(solicitacaoUnidadeConsumo.getCadastroCategoria());
	    	unidadeConsumo.setTipoLigacao(solicitacaoUnidadeConsumo.getTipoLigacao());
	    	unidadeConsumo.setEntidadePublica(solicitacaoUnidadeConsumo.getEntidadePublica());
	    	
	    	repository.insert(unidadeConsumo);
	    	
	    	Collection<Anexo> anexosSelecionados = selecionarAnexosSalvar(solicitacao, anexos);
	        persistirAnexosSolicitacao(solicitacaoServico, solicitacao.getTipoServico(), anexosSelecionados);
	        
	        return solicitacaoServico;
	    } catch (Exception e) {
	        Feedback.erroOperacao(this, "falha salvar unidade consumo", e);
	        throw new ValidacaoException("solicitacao.msg.falhasalvar");
	    }
    }
    
    public SolicitacaoServico salvarDesassociacao(SolicitacaoDesassociacao solicitacaoDesassociacao, Solicitacao solicitacao, Collection<Anexo> anexos) {
    	try {
	    	SolicitacaoServico solicitacaoServico = new SolicitacaoServico();
	    	
	    	solicitacaoServico.setCpf(TreatString.filterOnlyNumber(solicitacao.getSolicitante().getCpfCnpj()));
	    	
	    	solicitacaoServico.setTipoServico(solicitacao.getTipoServico().getCodigo());
	    	solicitacaoServico.setNome(solicitacaoDesassociacao.getNomeSolicitante());
	    	solicitacaoServico.setEmail(solicitacaoDesassociacao.getEmail());
	    	solicitacaoServico.setTelefone(TreatString.filterOnlyNumber(solicitacaoDesassociacao.getTelefone()));
	    	solicitacaoServico.setEnderecoIp(solicitacao.getIp());
	    	solicitacaoServico.setRgi(Long.valueOf(solicitacao.getDados().getNumero()));
	    	solicitacaoServico.setEnderecoIp(solicitacao.getIp());
	    	solicitacaoServico.setStatusEnvioEmail(solicitacao.getTipoServico().getStatusEnvioEmailInicial());
	        AtendimentoComercial atendimentoComercial = repository.findById(AtendimentoComercial.class, solicitacao.getDados().getAtendimentoComercialATC());
	        solicitacaoServico.setAtendimentoComercial(atendimentoComercial);
	        solicitacaoServico.setProtocolo(this.gerarProtocoloAtendimento(atendimentoComercial.getId()));
	        repository.insert(solicitacaoServico);
	    	
	        Desassociacao desassociacao = new Desassociacao();
	        desassociacao.setSolicitacao(solicitacaoServico);
	        desassociacao.setRepresentateLegal(solicitacaoDesassociacao.getRepresentateLegal());
	        desassociacao.setMotivoEncerramento(solicitacaoDesassociacao.getMotivoEncerramento());
	        desassociacao.setEstatalFederal(solicitacaoDesassociacao.getEstatalFederal());
	    	
	    	repository.insert(desassociacao);
	    	
	    	EnderecoDesassociacao enderecoDesassociacao = new EnderecoDesassociacao();
	    	enderecoDesassociacao.setSolicitacao(solicitacaoServico);
	    	enderecoDesassociacao.setLogradouro(solicitacaoDesassociacao.getLogradouro());
	    	enderecoDesassociacao.setNumero(solicitacaoDesassociacao.getNumero());
	    	enderecoDesassociacao.setComplemento(solicitacaoDesassociacao.getComplemento());
	    	enderecoDesassociacao.setBairro(solicitacaoDesassociacao.getBairro());
	    	enderecoDesassociacao.setCep(solicitacaoDesassociacao.getCep());
	    	enderecoDesassociacao.setCidade(solicitacaoDesassociacao.getCidade());
	    	
	    	repository.insert(enderecoDesassociacao);
	    	
	    	Collection<Anexo> anexosSelecionados = selecionarAnexosSalvar(solicitacao, anexos);
	        persistirAnexosSolicitacao(solicitacaoServico, solicitacao.getTipoServico(), anexosSelecionados);
	        
	        return solicitacaoServico;
	    } catch (Exception e) {
	        Feedback.erroOperacao(this, "falha salvar unidade consumo", e);
	        throw new ValidacaoException("solicitacao.msg.falhasalvar");
	    }
    }

    private Long extrairNumeroRgi(SolicitacaoDoacao solicitacaoDoacao) {
        Long numeroRgi = TreatNumber.toLong(solicitacaoDoacao.getDados().getNumero());
        
        if (numeroRgi == null) {
            Feedback.erroOperacao(this, "N�mero de RGI inv�lido", null);
            throw new ValidacaoException("solicitacao.msg.rgiinvalido");
        }

        return numeroRgi;
    }
    
    private DoacaoContaAgua cancelarDoacaoAgua(SolicitacaoDoacao solicitacaoDoacao,
            DoacaoContaAgua doacaoContaAgua) {

        String protocoloCancelamento =
                gerarProtocoloAtendimentoDoacao(doacaoContaAgua.getAtendimentoComercial().getId());

        doacaoContaAgua.setDoacaoAtiva(Boolean.FALSE);
        doacaoContaAgua.setDataDoacao(new Date());
        doacaoContaAgua.setDataCancelamento(new Date());
        doacaoContaAgua.setEnderecoIp(Feedback.getIP());
        doacaoContaAgua.setProtocolo(protocoloCancelamento);
        doacaoContaAgua.setCodigoCliente(solicitacaoDoacao.getDados().getCodigoCliente());
        doacaoContaAgua.setCodigoMunicipio(solicitacaoDoacao.getDados().getCodigoMunicipio());

        DoacaoContaAgua doacaoContaAguaCancelada = repository.update(doacaoContaAgua);
        incluirLogDoacaoContaAgua(TipoOperacaoDoacaoAgua.CANCELAMENTO, doacaoContaAguaCancelada);

        enviarSolicitacaoDoacaoMainframe(doacaoContaAguaCancelada);

        return doacaoContaAguaCancelada;
    }
    
    private DoacaoContaAgua realizarDoacaoAgua(DoacaoContaAgua doacaoContaAgua,
            SolicitacaoDoacao solicitacaoDoacao) {

        BigDecimal valorDoacao = BigDecimal.valueOf(solicitacaoDoacao.getValorDoacao());
        String protocoloDoacao =
                gerarProtocoloAtendimentoDoacao(doacaoContaAgua.getAtendimentoComercial().getId());

        doacaoContaAgua.setDoacaoAtiva(Boolean.TRUE);
        doacaoContaAgua.setDataCancelamento(null);
        doacaoContaAgua.setEnderecoIp(Feedback.getIP());
        doacaoContaAgua.setProtocolo(protocoloDoacao);
        doacaoContaAgua.setNome(solicitacaoDoacao.getNomeSolicitante());
        doacaoContaAgua.setTelefone(TreatString.removeSpecialChar(solicitacaoDoacao.getTelefone()));
        doacaoContaAgua.setEmail(solicitacaoDoacao.getEmail());
        doacaoContaAgua.setValorDoacao(valorDoacao);
        doacaoContaAgua.setCodigoCliente(solicitacaoDoacao.getDados().getCodigoCliente());
        doacaoContaAgua.setCodigoMunicipio(solicitacaoDoacao.getDados().getCodigoMunicipio());

        DoacaoContaAgua doacaoContaAguaAlterada = repository.update(doacaoContaAgua);
        incluirLogDoacaoContaAgua(TipoOperacaoDoacaoAgua.DOACAO, doacaoContaAguaAlterada);

        enviarSolicitacaoDoacaoMainframe(doacaoContaAguaAlterada);

        return doacaoContaAguaAlterada;
    }
    
    private void incluirLogDoacaoContaAgua(TipoOperacaoDoacaoAgua acao,
            DoacaoContaAgua doacaoContaAgua) {

        LogDoacaoContaAgua logDoacao = new LogDoacaoContaAgua();

        logDoacao.setDoacaoContaAgua(doacaoContaAgua);
        logDoacao.setDataLog(new Date());
        logDoacao.setEnderecoIp(doacaoContaAgua.getEnderecoIp());
        logDoacao.setProtocolo(doacaoContaAgua.getProtocolo());
        logDoacao.setAcao(acao.getValor());

        repository.insert(logDoacao);
    }

    private void enviarSolicitacaoDoacaoMainframe(DoacaoContaAgua doacaoContaAgua) {
        if (Preferencias.getBoolean(Propriedades.INTEGRAR_MAINFRAME, true)) {
            apiServicoCsi.salvarSolicitacaoDoacao(new DoacaoAguaCsiModel(doacaoContaAgua));
        }
    }

    private Date getDatanascimento(String dataNascimentoStr) {
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            return formato.parse(dataNascimentoStr);
        } catch (Exception e) {
            return null;
        }
    }
    
    private Date getDataLeitura(String dataLeituraStr) {
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            return formato.parse(dataLeituraStr);
        } catch (Exception e) {
            return null;
        }
    }

    private String getTelefoneCadastro(String telefone) {
        if (telefone == null || telefone.isEmpty()) {
            return "";
        }

        String telefoneSoNumeros = telefone
                .replace("(", "")
                .replace(")", "")
                .replace("-", "")
                .trim().replaceAll("\\s+", "");
        return telefoneSoNumeros;
    }

    /**
     * Metodo responsavel por obter a AtendimentoComercial que recebera o email do servico
     *
     * @param rgi
     * @return
     * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
     * @since 17 de abr de 2020 (Projeto)
     */
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public AtendimentoComercial definirAtendimentoComercial(DadosRGI rgi) {
        if (rgi.getAtendimentoComercialATC() == null) {
            return null;
        }
        return repository.searchUniqueResult(AtendimentoComercial.class, "select a from AtendimentoComercial a where a.id = ?",
                rgi.getAtendimentoComercialATC());
    }
    
    /**
     * Metodo responsavel por obter o anexo de acordo com a solicitacao e identificador
     *
     * @param idSolicitacao
     * @param identificador
     * @return
     * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
     * @since 20 de abr de 2020 (Projeto)
     */
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public File obterArquivoAnexo(Long idSolicitacao, String identificador) {
        if (TreatString.isBlank(identificador) || TreatNumber.isNullOrZero(idSolicitacao)) {
            return null;
        }
        AnexoSolicitacaoServico anexo = repository.searchUniqueResult(AnexoSolicitacaoServico.class, "select a from AnexoSolicitacaoServico a where a.solicitacao.id = ? and a.identificador = ?",
                idSolicitacao, identificador);
        if (anexo == null) {
            return null;
        }
        return new File(anexo.getCaminho());
    }

    /**
     * Metodo responsavel por seleionar/filtrar quais anexos serao validados
     *
     * @param solicitacao
     * @param anexos
     * @return
     * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
     * @since 13 de abr de 2020 (Projeto)
     */
    private Collection<Anexo> selecionarAnexosSalvar(Solicitacao solicitacao, Collection<Anexo> anexos) {
        Collection<Anexo> anexosSelecionados = new ArrayList<Anexo>();
        if (solicitacao.getTipoServico().getNecessarioDocumentacao()) {
            anexosSelecionados.addAll(anexos);
            if (solicitacao.getSolicitante().getRepresentanteLegal() != null && solicitacao.getSolicitante().getRepresentanteLegal()) {
                anexosSelecionados.add(solicitacao.getSolicitante().getDocumentoRepresentateLegal());
            }
            if (solicitacao.getSolicitante().getTipoHabitacao() != null){
                anexosSelecionados.add(solicitacao.getSolicitante().getDocumentoTipoHabitacao());
            }
        }
        return anexosSelecionados;
    }
    
    private Collection<Anexo> selecionarAnexosSalvar(SolicitacaoUnidadeConsumo solicitacao, Collection<Anexo> anexos) {
        Collection<Anexo> anexosSelecionados = new ArrayList<Anexo>();
        anexosSelecionados.addAll(anexos);
        if (solicitacao.getRepresentanteLegal() != null && solicitacao.getRepresentanteLegal()) {
            anexosSelecionados.add(solicitacao.getDocumentoRepresentanteLegal());
        }
        if (solicitacao.getEntidadePublica() != null && solicitacao.getEntidadePublica()){
            anexosSelecionados.add(solicitacao.getDocumentoEntidadePublica());
        }
        return anexosSelecionados;
    }

    /**
     * Metodo responsavel por realizar persistencia logica dos anexos
     *
     * @param edicao
     * @param anexos
     * @throws IOException
     * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
     * @since 13 de abr de 2020 (Projeto)
     */
    private void persistirAnexosSolicitacao(SolicitacaoServico edicao, TipoServico tipoServico, Collection<Anexo> anexos) throws IOException {
        if (anexos.isEmpty()) {
            return;
        }

        String uriSolicitacao = edicao.getRgi()
                + "/" + tipoServico.getAbreviacao()
                + "/" + TreatDate.format("yyyyMMdd_HHmmss", edicao.getDataCadastro());

        File raizAnexos = new File(Preferencias.get(Propriedades.CAMINHO_ANEXOS_SOLICITACAO));
        raizAnexos.mkdirs();

        File raiz = new File(raizAnexos, uriSolicitacao);
        raiz.mkdirs();

        for (Anexo anexo : anexos) {
        	if(anexo != null) {
        		if (!anexo.getObrigatorio() && !anexo.getIsInformado()) {
                    continue;
                }
                InputStream inTemporario = null;
                OutputStream outNovo = null;
                File arquivo = null;

                try {
                    File temporario = new File(anexo.getCaminhoTemporario());
                    inTemporario = new BufferedInputStream(new FileInputStream(temporario));
                    String aliasArquivo = anexo.getNomeUnico() + "." + TreatFile.getTypeFile(anexo.getNome());
                    arquivo = new File(raiz, aliasArquivo);
                    outNovo = new BufferedOutputStream(new FileOutputStream(arquivo));
                    if (IOUtils.copyLarge(inTemporario, outNovo) <= 0l) {
                        throw new IllegalStateException("Falha copiar arquivo solicitacao");
                    }
                } finally {
                    IOUtils.closeQuietly(outNovo);
                    IOUtils.closeQuietly(inTemporario);
                }

                AnexoSolicitacaoServico salvar = new AnexoSolicitacaoServico();
                salvar.setCaminho(arquivo.getAbsolutePath());
                salvar.setNome(anexo.getNome());
                salvar.setSolicitacao(edicao);
                salvar.setTipo(anexo.getTipo().getCodigo());
                repository.insert(salvar);
        	}
            
        }

        // apaga os arquivos temporarios apos o uso, evitando quebra do fluxo caso alguma falha tenha ocorrido durante manipulacao
        for (Anexo anexo : anexos) {
        	if(anexo != null) {
        		TreatFile.deleteFile(anexo.getCaminhoTemporario());
        	}
        }
    }

    private String gerarProtocoloAtendimento(final Integer atendimentoComercial) {
        StringBuilder hql = new StringBuilder();
        hql.append(" FROM SolicitacaoServico ss ");
        hql.append(" WHERE ss.dataCadastro BETWEEN :_param1 AND :_param2");

        Integer ultimoProtocolo = repository.count("ss.id", hql.toString(), TreatDate.minDateTime(new Date()), TreatDate.maxDateTime(new Date())).intValue();
        ultimoProtocolo = ultimoProtocolo + adicionarAtendimentosFaleConosco(atendimentoComercial);
        return new StringBuilder("SF")
                .append(String.format("%06d", atendimentoComercial))
                .append("-")
                .append(TreatDate.format("yyMMdd", new Date()))
                .append(String.format("%05d", ultimoProtocolo + 1))
                .toString();
    }

    private Integer adicionarAtendimentosFaleConosco(Integer atendimentoComercial) {
    	StringBuilder hql = new StringBuilder();
        hql.append(" FROM FaleConosco fc ");
        hql.append(" WHERE fc.dataCadastro BETWEEN :_param1 AND :_param2");

        Integer atendimentosFaleConosco = repository.count("fc.id", hql.toString(), TreatDate.minDateTime(new Date()), TreatDate.maxDateTime(new Date())) != null? 
        		repository.count("fc.id", hql.toString(), TreatDate.minDateTime(new Date()), TreatDate.maxDateTime(new Date())).intValue() : 0;
        
        return atendimentosFaleConosco;
	}

	private String gerarProtocoloAtendimentoDoacao(final Integer atendimentoComercial) {
        StringBuilder hql = new StringBuilder();
        hql.append(" FROM LogDoacaoContaAgua ss ");
        hql.append(" WHERE ss.dataLog BETWEEN :_param1 AND :_param2");

        Integer ultimoProtocolo = repository.count("ss.id", hql.toString(), TreatDate.minDateTime(new Date()), TreatDate.maxDateTime(new Date())).intValue();
        return new StringBuilder("SD")
                .append(String.format("%06d", atendimentoComercial))
                .append("-")
                .append(TreatDate.format("yyMMdd", new Date()))
                .append(String.format("%05d", ultimoProtocolo + 1))
                .toString();
    }

	public SolicitacaoServico obterSolicitacao(String protocolo) {
		try {
			return repository.searchUniqueResult(SolicitacaoServico.class, "select a from SolicitacaoServico a where a.protocolo = ?",
	        		protocolo);
		} catch (Exception e) {
			throw new IllegalStateException("Falha ao obter solicita��o.");
		}
        
	}
	
	public TipoHabitacao obterTipoHabitacao(Integer cdHabitacao) {
		try {
			return repository.searchUniqueResult(TipoHabitacao.class, "select a from TipoHabitacao a where a.id = ?",
					cdHabitacao);
		} catch (Exception e) {
			throw new IllegalStateException("Falha ao obter Tipo Habitacao.");
		}
        
	}
	
	public void salvarPesquisaSatisfacao(PesquisaSatisfacao pesquisaSatisfacao) {
		try {
			repository.insert(pesquisaSatisfacao);
		} catch (Exception e) {
			throw new IllegalStateException("Falha ao salvar Pesquisa Satisfa��o.");
		}
	}

	public FaleConosco salvarSolicitacaoFaleConosco(SolicitacaoFaleConosco edicaoFaleConosco) {
        try {
        	
        	FaleConosco faleConosco = new FaleConosco();
        	
        	faleConosco.setComentario(edicaoFaleConosco.getComentario().getCodigo());
        	faleConosco.setAssunto(edicaoFaleConosco.getAssunto().getCodigo());
        	faleConosco.setTipoPessoa(Integer.parseInt(edicaoFaleConosco.getTipoUsuario()));
        	faleConosco.setNome(edicaoFaleConosco.getNomeSolicitante());
        	faleConosco.setRgi(Long.parseLong(edicaoFaleConosco.getDados().getNumero()));
        	faleConosco.setRgrne(edicaoFaleConosco.getRgrne());
        	faleConosco.setEmail(edicaoFaleConosco.getEmail());
        	faleConosco.setCpfCnpj(TreatString.filterOnlyNumber(edicaoFaleConosco.getCpfCnpj()));
        	faleConosco.setTelefone(TreatString.filterOnlyNumber(edicaoFaleConosco.getTelefone()));
        	faleConosco.setEmpresa(edicaoFaleConosco.getEmpresa());
        	faleConosco.setTexto(edicaoFaleConosco.getComentarioTexto());
        	faleConosco.setProtocoloServico(edicaoFaleConosco.getNrprotocolo());
        	faleConosco.setDataCadastro(new Date());
        	
        	AtendimentoComercial atendimentoComercial = repository.findById(AtendimentoComercial.class, edicaoFaleConosco.getDados().getAtendimentoComercialATC());
        	faleConosco.setProtocolo(this.gerarProtocoloAtendimento(atendimentoComercial.getId()));
        	
        	repository.insert(faleConosco);
            return faleConosco;
        } catch (Exception e) {
            Feedback.erroOperacao(this, "falha salvar solicitacao de fale conosco", e);
            throw new ValidacaoException("solicitacao.msg.falhasalvar");
        }
	}

	public Boolean buscarSolitacaoRecente(Solicitacao solicitacao, Integer dias) {
		Query query = null;
		try {
			String sql = "SELECT 1 FROM SOLICITACAO_SERVICO "
					+ "WHERE NR_RGI_PDE = ?1 "
					+ "AND CD_TIPO_SERVICO = ?2 "
					+ "AND DT_SOLICITACAO_SERVICO >= ?3 ";
			
			query = repository.getEntityManager().createNativeQuery(sql);
			query.setParameter(1, TreatString.filterOnlyNumber(solicitacao.getDados().getNumero()));
			query.setParameter(2, solicitacao.getTipoServico().getCodigo());
			
			GregorianCalendar gc = new GregorianCalendar();
			gc.add(Calendar.DAY_OF_MONTH, dias);
			query.setParameter(3, gc.getTime());
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return query.getResultList().size() > 0 ? true : false;
	}
	
	public void salvarEnderecoPreCadastro (EnderecoPreCadastro enderecoPreCadastro) {
		try {
			repository.insert(enderecoPreCadastro);
		} catch (Exception e) {
			throw new IllegalStateException("Falha ao salvar Endereco Pre Cadastro.");
		}
	}

}
