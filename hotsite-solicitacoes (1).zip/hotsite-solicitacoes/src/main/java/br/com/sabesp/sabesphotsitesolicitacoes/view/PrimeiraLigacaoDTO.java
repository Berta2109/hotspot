package br.com.sabesp.sabesphotsitesolicitacoes.view;


public class PrimeiraLigacaoDTO {
	
	private String numeroProcesso;
//	private CidadeDTO cidade;
	private Integer cidade;

	public String getNumeroProcesso() {
		return numeroProcesso;
	}

	public void setNumeroProcesso(String numeroProcesso) {
		this.numeroProcesso = numeroProcesso;
	}

	public Integer getCidade() {
		return cidade;
	}

	public void setCidade(Integer cidade) {
		this.cidade = cidade;
	}


//	public CidadeDTO getCidade() {
//		return cidade;
//	}
//
//	public void setCidade(CidadeDTO cidade) {
//		this.cidade = cidade;
//	}

	
}
