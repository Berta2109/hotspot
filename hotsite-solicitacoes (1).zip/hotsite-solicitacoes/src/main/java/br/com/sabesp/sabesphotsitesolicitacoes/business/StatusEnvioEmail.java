package br.com.sabesp.sabesphotsitesolicitacoes.business;

public enum StatusEnvioEmail {

	PENDENTE_ENVIO(1),
	SUCESSO_ENVIO(2),
	FALHA_ENVIO(3),
	NAO_APLICADO(4),
	;

	private Integer codigo;

	private StatusEnvioEmail(Integer codigo) {
		this.codigo = codigo;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

}
