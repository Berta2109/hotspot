package br.com.sabesp.sabesphotsitesolicitacoes.entity;

public class Fornecimento {
	
	private String pde;
	private String fornecimento;
	private String codMunicipio;
	private String codAtc;
	
	public String getPde() {
		return pde;
	}
	public void setPde(String pde) {
		this.pde = pde;
	}
	public String getFornecimento() {
		return fornecimento;
	}
	public void setFornecimento(String fornecimento) {
		this.fornecimento = fornecimento;
	}
	public String getCodMunicipio() {
		return codMunicipio;
	}
	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}
	public String getCodAtc() {
		return codAtc;
	}
	public void setCodAtc(String codAtc) {
		this.codAtc = codAtc;
	}
}
