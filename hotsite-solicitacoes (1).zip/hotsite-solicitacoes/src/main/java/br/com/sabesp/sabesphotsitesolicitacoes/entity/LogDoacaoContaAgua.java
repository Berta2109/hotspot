
package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "LOG_DOACAO_CONTA_AGUA")
public class LogDoacaoContaAgua implements Serializable {

    private static final long serialVersionUID = -3326622332382426478L;

    @Id
    @SequenceGenerator(name = "SEQ_LOG_DOACAO_CONTA_AGUA", sequenceName = "SEQ_LOG_DOACAO_CONTA_AGUA", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_LOG_DOACAO_CONTA_AGUA")
    @Column(name = "CD_LOG_DOACAO", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "CD_DOACAO_CONTA_AGUA", referencedColumnName = "CD_DOACAO_CONTA_AGUA", nullable = false)
    private DoacaoContaAgua doacaoContaAgua;

    @Column(name = "DT_LOG_DOACAO", nullable = false)
    private Date dataLog;

    @Column(name = "SG_ACAO_REALIZADA", nullable = false)
    private String acao;

    @Column(name = "NR_ENDERECO_IP", length = 30, nullable = false)
    private String enderecoIp;

    @Column(name = "DC_PROTOCOLO_ATENDIMENTO", length = 30, nullable = false)
    private String protocolo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public DoacaoContaAgua getDoacaoContaAgua() {
        return doacaoContaAgua;
    }

    public void setDoacaoContaAgua(DoacaoContaAgua doacaoContaAgua) {
        this.doacaoContaAgua = doacaoContaAgua;
    }

    public Date getDataLog() {
        return dataLog;
    }

    public void setDataLog(Date dataLog) {
        this.dataLog = dataLog;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }

    public String getEnderecoIp() {
        return enderecoIp;
    }

    public void setEnderecoIp(String enderecoIp) {
        this.enderecoIp = enderecoIp;
    }

    public String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(String protocolo) {
        this.protocolo = protocolo;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        LogDoacaoContaAgua other = (LogDoacaoContaAgua) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
