
package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.TipoHabitacao;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

public class SolicitacaoUnidadeConsumo implements Serializable {

    private static final long serialVersionUID = -6235011381818457825L;

    private String tipoUnidade;
    
    private String cpfTitular;
    private String nomeSolicitante;
    private String telefone;
    private String email;
    
    private String protocolo;
    private DadosRGI dados;

    //At� 7 Economias (Somente para im�veis residenciais ou mistos)
    private String unidadeAutonoma;
    private String unidadeResendencial;
    private String unidadeNaoResidencial;
    private Boolean possuiEscritura = false;
    private Boolean naoPossuiEscritura = false;
    private Boolean propriedadeExclusiva = false;
    private Boolean residenciaColetiva = false;
    private Boolean declaroVeracidade = false;
    private Boolean representanteLegal;
    private TipoHabitacao tipoHabitacao;
    
    private String situacao;
    
    //Categoria de Uso( resid�ncia, com�rcio, ind�stria e p�blica) e Tipo de Liga��o (�gua, esgoto ou �gua e esgoto)
    private String cadastroCategoria;
    private String tipoLigacao;
	private Boolean entidadePublica;
	private Anexo documentoEntidadePublica;
	private Anexo documentoRepresentanteLegal;
	
	private Solicitacao solicitacao;
	private Solicitante solicitante;
    
	public String getTipoUnidade() {
		return tipoUnidade;
	}
	public void setTipoUnidade(String tipoUnidade) {
		this.tipoUnidade = tipoUnidade;
	}
	public String getCpfTitular() {
		return cpfTitular;
	}
	public void setCpfTitular(String cpfTitular) {
		this.cpfTitular = cpfTitular;
	}
	public String getNomeSolicitante() {
		return nomeSolicitante;
	}
	public void setNomeSolicitante(String nomeSolicitante) {
		this.nomeSolicitante = nomeSolicitante;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getProtocolo() {
		return protocolo;
	}
	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}
	public DadosRGI getDados() {
		return dados;
	}
	public void setDados(DadosRGI dados) {
		this.dados = dados;
	}
	public String getUnidadeAutonoma() {
		return unidadeAutonoma;
	}
	public void setUnidadeAutonoma(String unidadeAutonoma) {
		this.unidadeAutonoma = unidadeAutonoma;
	}
	public String getUnidadeResendencial() {
		return unidadeResendencial;
	}
	public void setUnidadeResendencial(String unidadeResendencial) {
		this.unidadeResendencial = unidadeResendencial;
	}
	public String getUnidadeNaoResidencial() {
		return unidadeNaoResidencial;
	}
	public void setUnidadeNaoResidencial(String unidadeNaoResidencial) {
		this.unidadeNaoResidencial = unidadeNaoResidencial;
	}
	public Boolean getPossuiEscritura() {
		return possuiEscritura;
	}
	public void setPossuiEscritura(Boolean possuiEscritura) {
		this.possuiEscritura = possuiEscritura;
	}
	public Boolean getNaoPossuiEscritura() {
		return naoPossuiEscritura;
	}
	public void setNaoPossuiEscritura(Boolean naoPossuiEscritura) {
		this.naoPossuiEscritura = naoPossuiEscritura;
	}
	public Boolean getPropriedadeExclusiva() {
		return propriedadeExclusiva;
	}
	public void setPropriedadeExclusiva(Boolean propriedadeExclusiva) {
		this.propriedadeExclusiva = propriedadeExclusiva;
	}
	public Boolean getResidenciaColetiva() {
		return residenciaColetiva;
	}
	public void setResidenciaColetiva(Boolean residenciaColetiva) {
		this.residenciaColetiva = residenciaColetiva;
	}
	public Boolean getDeclaroVeracidade() {
		return declaroVeracidade;
	}
	public void setDeclaroVeracidade(Boolean declaroVeracidade) {
		this.declaroVeracidade = declaroVeracidade;
	}
	public Boolean getRepresentanteLegal() {
		return representanteLegal;
	}
	public void setRepresentanteLegal(Boolean representanteLegal) {
		this.representanteLegal = representanteLegal;
	}
	public String getCadastroCategoria() {
		return cadastroCategoria;
	}
	public void setCadastroCategoria(String cadastroCategoria) {
		this.cadastroCategoria = cadastroCategoria;
	}
	public String getTipoLigacao() {
		return tipoLigacao;
	}
	public void setTipoLigacao(String tipoLigacao) {
		this.tipoLigacao = tipoLigacao;
	}
	public TipoHabitacao getTipoHabitacao() {
		return tipoHabitacao;
	}
	public void setTipoHabitacao(TipoHabitacao tipoHabitacao) {
		this.tipoHabitacao = tipoHabitacao;
	}
	public Boolean getEntidadePublica() {
		return entidadePublica;
	}
	public void setEntidadePublica(Boolean entidadePublica) {
		this.entidadePublica = entidadePublica;
	}
	public Anexo getDocumentoEntidadePublica() {
		return documentoEntidadePublica;
	}
	public void setDocumentoEntidadePublica(Anexo documentoEntidadePublica) {
		this.documentoEntidadePublica = documentoEntidadePublica;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	public Anexo getDocumentoRepresentanteLegal() {
		return documentoRepresentanteLegal;
	}
	public void setDocumentoRepresentanteLegal(Anexo documentoRepresentanteLegal) {
		this.documentoRepresentanteLegal = documentoRepresentanteLegal;
	}
	public Solicitacao getSolicitacao() {
		return solicitacao;
	}
	public void setSolicitacao(Solicitacao solicitacao) {
		this.solicitacao = solicitacao;
	}
	public Solicitante getSolicitante() {
		return solicitante;
	}
	public void setSolicitante(Solicitante solicitante) {
		this.solicitante = solicitante;
	}
}
