package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;

import br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador.Webwsto;

@SessionScoped
public class SabespSession implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 3382797256747566057L;

	private Webwsto autenticacaoWs;

	public Webwsto getAutenticacaoWs() {
		return autenticacaoWs;
	}

	public void setAutenticacaoWs(Webwsto autenticacaoWs) {
		this.autenticacaoWs = autenticacaoWs;
	}
}
