package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.text.MessageFormat;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Feedback {

	private static final String DEFAULT_I18N = "i18n";

	public static void error(String message) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, message));
	}

	public static void jsfWarning(String key, Object... args) {
		String msg = getMsg(key, args);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "", msg));
	}

	public static void jsfSucesso(String key, Object... args) {
		String msg = getMsg(key, args);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", msg));
	}

	public static void erroOperacao(Object from, Exception e) {
		Logger log = LoggerFactory.getLogger(from.getClass());
		log.error("Erro geral funcionamento", e);
	}

	public static void erroOperacao(Object from, String msg, Exception e) {
		Logger log = LoggerFactory.getLogger(from.getClass());
		log.error(msg, e);
	}

	public static void jsfError18n(String key, Object... args) {
		String msg = getMsg(key, args);
		FacesContext context = FacesContext.getCurrentInstance();
		context.validationFailed();
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msg));
	}

	public static void jsfErroOperacao(Object from, Exception e) {
		erroOperacao(from, e);
		jsfError18n("msg.falhageral");
	}

	public static void jsfValidationError18n(ValidacaoException e) {
		jsfError18n(e.getMessage(), e.getParams());
	}


	private static String formatByParams(String message, Object... objects) {
		if (objects == null || objects.length == 0) {
			return message;
		}
		return MessageFormat.format(message, objects);
	}

	public static String getMsg(String key, Object... args) {
		FacesContext context = FacesContext.getCurrentInstance();
		String msg = context.getApplication().getResourceBundle(context, DEFAULT_I18N).getString(key);
		msg = formatByParams(msg, args);
		return msg;
	}

	public static ResourceBundle getI18nResourceBundle() {
		FacesContext context = FacesContext.getCurrentInstance();
		return  context.getApplication().getResourceBundle(context, DEFAULT_I18N);
	}

	/**
	 * Metodo responsavel por retornar endereco IP do usuario
	 * @return
	 */
	public static String getIP() {
		return ((HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest()).getRemoteAddr();
	}
}