package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.primefaces.model.SortOrder;

@Stateless
public class JpaRepository implements GenericRepository {

	@PersistenceContext(unitName = "default")
	private EntityManager entityManager;

	public JpaRepository() {
	}

	public JpaRepository(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public <T> T insert(T object) {
		if (object == null) {
			throw new IllegalArgumentException("Param object is null");
		}
		entityManager.persist(object);
		return object;
	}

	public <T> T update(T object) {
		if (object == null) {
			throw new IllegalArgumentException("Param object is null");
		}
		return entityManager.merge(object);
	}

	public <T> void remove(T object) {
		if (object == null) {
			throw new IllegalArgumentException("Param object is null");
		}
		entityManager.merge(object);
		entityManager.remove(object);
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public <T> T findById(Class<T> clazz, Object pk) {
		if (pk == null) {
			return null;
		}
		return entityManager.find(clazz, pk);
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public <T> Collection<T> list(Class<T> clazz) {
		TypedQuery<T> query = this.entityManager.createQuery("from " + clazz.getName(), clazz);
		return query.getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public <T> Collection<T> search(Class<T> clazz, String hql, Object... args) {
		hql = treatHql(hql, args);
		TypedQuery<T> query = this.entityManager.createQuery(hql, clazz);
		treatArgs(query, args);
		try {
			return query.getResultList();
		} finally {
			query = null;
			hql = null;
			args = null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public <T> Collection<T> searchWithLimit(Class<T> clazz, String hql, Integer start, Integer limit, Object... args) {
		hql = treatHql(hql, args);
		TypedQuery<T> query = this.entityManager.createQuery(hql, clazz);
		query.setFirstResult(start);
		query.setMaxResults(limit);
		treatArgs(query, args);
		try {
			return query.getResultList();
		} finally {
			query = null;
			hql = null;
			start = null;
			limit = null;
			args = null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public <T> T searchUniqueResult(Class<T> clazz, String hql, Object... args) {
		hql = treatHql(hql, args);
		TypedQuery<T> query = this.entityManager.createQuery(hql, clazz);
		T singleResult = null;
		try {
			query.setFirstResult(0);
			query.setMaxResults(1);
			treatArgs(query, args);
			singleResult = (T) query.getSingleResult();
		} catch (NoResultException noResult) {
			// se nao encontrar entao retorna null
		} catch (NonUniqueResultException noUniqueResult) {
			System.err.println(hql);
			noUniqueResult.printStackTrace();
		} finally {
			query = null;
			hql = null;
			args = null;
			clazz = null;
		}
		return singleResult;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Number count(String fieldCount, String hqlAfterCount, Object... args) {
		hqlAfterCount = treatHql(hqlAfterCount, args);
		Query queryCount = this.entityManager.createQuery("SELECT COUNT(" + fieldCount + ")" + hqlAfterCount);
		treatArgs(queryCount, args);
		try {
			return (Number) queryCount.getSingleResult();
		} finally {
			if (queryCount != null)
				queryCount = null;
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public EntityManager getEntityManager() {
		return entityManager;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public void addOrdenacao(CriteriaBuilder builder, CriteriaQuery<?> query,
			Root<?> root, SortOrder sortOrder, String atributoAOrdenar) {
		atributoAOrdenar = atributoAOrdenar.trim();

		Path<Object> temp = null;

		if (atributoAOrdenar.contains(".")) {
			String[] info = atributoAOrdenar.split("\\.");

			for (String string : info) {
				if (temp == null) {
					temp = root.get(string);
				} else {
					temp = temp.get(string);
				}
			}
		} else {
			temp = root.get(atributoAOrdenar);
		}

		if (sortOrder == SortOrder.ASCENDING) {
			query.orderBy(builder.asc(temp));
		} else {
			query.orderBy(builder.desc(temp));
		}
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	private void treatArgs(Query query, Object... args) {
		if (args == null || args.length == 0) {
			return;
		}
		int i = 1;
		for (Object arg : args)
			query.setParameter("_param" + i++, arg);
	}

	private String treatHql(String hql, Object... params) {
		if (params == null || params.length == 0) {
			return hql;
		}
		for (int i = 0; i < params.length; i++) {
			hql = hql.replaceFirst("\\?", ":_param" + (i + 1));
		}
		return hql;
	}

}
