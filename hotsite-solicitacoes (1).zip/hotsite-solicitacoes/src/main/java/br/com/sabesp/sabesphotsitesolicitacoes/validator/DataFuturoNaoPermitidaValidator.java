package br.com.sabesp.sabesphotsitesolicitacoes.validator;

import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import br.com.sabesp.sabesphotsitesolicitacoes.util.Feedback;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatDate;

@FacesValidator("dataFuturoNaoPermitidaValidator")
public class DataFuturoNaoPermitidaValidator implements Validator {

	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object test) throws ValidatorException {
		if (test == null) {
			return;
		}
		if (TreatDate.clearDateTime(TreatDate.clearDateTime((Date) test)).compareTo(new Date()) > 0) {
			throw new ValidatorException(
					new FacesMessage(FacesMessage.SEVERITY_ERROR, Feedback.getMsg("custom.validator.dataFuturoNaoPermitidaValidator"), null));
		}
	}

}
