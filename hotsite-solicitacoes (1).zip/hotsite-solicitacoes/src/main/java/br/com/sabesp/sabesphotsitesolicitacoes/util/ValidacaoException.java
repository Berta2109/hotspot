package br.com.sabesp.sabesphotsitesolicitacoes.util;

import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class ValidacaoException extends IllegalStateException {

	/**
   *
   */
	private static final long serialVersionUID = -2024946204788769369L;

	private Object[] params = new Object[0];

	private Object target;

	public ValidacaoException(String key18n, Object... params) {
		super(key18n);
		this.params = params;
	}

	public ValidacaoException withTarget(Object o) {
		target = o;
		return this;
	}

	public Object getTarget() {
		return target;
	}

	public Object[] getParams() {
		return params;
	}
}
