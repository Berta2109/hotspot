package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.util.ArrayList;
import java.util.List;

public class LogradouroDTO {

	private String codLogradouro;
	private String descTipoLogr;
	private String descLogradouro;
	private String descLogradouroExibe;
	private String descBairro;
	
	private static List<String> descTipoLogradouro = new ArrayList<String>();
	
	public String getCodLogradouro() {
		return codLogradouro;
	}
	public void setCodLogradouro(String codLogradouro) {
		this.codLogradouro = codLogradouro;
	}
	public String getDescTipoLogr() {
		return descTipoLogr;
	}
	public void setDescTipoLogr(String descTipoLogr) {
		this.descTipoLogr = descTipoLogr;
	}
	public String getDescLogradouro() {
		return descLogradouro;
	}
	public void setDescLogradouro(String descLogradouro) {
		this.descLogradouro = descLogradouro;
	}
	public String getDescLogradouroExibe() {
		return descLogradouroExibe;
	}
	public void setDescLogradouroExibe(String descLogradouroExibe) {
		this.descLogradouroExibe = descLogradouroExibe;
	}
	public String getDescBairro() {
		return descBairro;
	}
	public void setDescBairro(String descBairro) {
		this.descBairro = descBairro;
	}
	public static List<String> getDescTipoLogradouro() {
		
		descTipoLogradouro.add("CAMINHO");
		descTipoLogradouro.add("PONTE");
		descTipoLogradouro.add("AVENIDA");
		descTipoLogradouro.add("PASSEIO");
		descTipoLogradouro.add("RODOVIA");
		descTipoLogradouro.add("LARGO");
		descTipoLogradouro.add("LADEIRA");
		descTipoLogradouro.add("RUA");
		descTipoLogradouro.add("VIELA");
		descTipoLogradouro.add("PARQUE");
		descTipoLogradouro.add("JARDIM");
		descTipoLogradouro.add("PATIO");
		descTipoLogradouro.add("VILA");
		descTipoLogradouro.add("PASSAGEM");
		descTipoLogradouro.add("BECO");
		descTipoLogradouro.add("ESTRADA");
		descTipoLogradouro.add("ALAMEDA");
		descTipoLogradouro.add("TRAVESSA");
		descTipoLogradouro.add("VIA");
		descTipoLogradouro.add("PRACA");
		descTipoLogradouro.add("VICINAL");
		descTipoLogradouro.add("SERVIDAO");
		descTipoLogradouro.add("ACESSO");
		descTipoLogradouro.add("SITIO");
		descTipoLogradouro.add("PASSARELA");
		
		return descTipoLogradouro;
	}
	public static void setDescTipoLogradouro(List<String> descTipoLogradouro) {
		LogradouroDTO.descTipoLogradouro = descTipoLogradouro;
	}
	
}
