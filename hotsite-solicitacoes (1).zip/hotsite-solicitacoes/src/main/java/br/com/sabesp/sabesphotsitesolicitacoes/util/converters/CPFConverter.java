package br.com.sabesp.sabesphotsitesolicitacoes.util.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;

@FacesConverter(value="cpfConverter")
public class CPFConverter implements Converter {

	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) throws ConverterException {
		return arg2;
	}

	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) throws ConverterException {
		if(arg2 == null){
			return "";
		}
		return BrasilUtils.formatarCPF(arg2.toString());
	}
}