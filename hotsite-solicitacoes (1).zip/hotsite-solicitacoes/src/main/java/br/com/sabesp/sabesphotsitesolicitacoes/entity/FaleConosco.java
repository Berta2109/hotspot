
package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "FALE_CONOSCO")
public class FaleConosco implements Serializable {

    private static final long serialVersionUID = -6903243885161184700L;

    @Id
    @SequenceGenerator(name = "SEQ_FALE_CONOSCO", sequenceName = "SEQ_FALE_CONOSCO", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_FALE_CONOSCO")
    @Column(name = "CD_FALE_CONOSCO", nullable = false)
    private Long id;

    @Column(name = "IN_COMENTARIO", nullable = false)
    private Integer comentario;
    
    @Column(name = "IN_ASSUNTO", nullable = false)
    private Integer assunto;
    
    @Column(name = "IN_TIPO_PESSOA", nullable = false)
    private Integer tipoPessoa;
    
    @Column(name = "DC_NOME", length = 60, nullable = false)
    private String nome;

    @Column(name = "NR_RGI_PDE", nullable = false)
    private Long rgi;
    
    @Column(name = "NR_RG_RNE", nullable = false)
    private String rgrne;
    
    @Column(name = "DC_EMAIL", length = 100, nullable = false)
    private String email;
    
    @Column(name = "NR_CPF_CNPJ", length = 14, nullable = false)
    private String cpfCnpj;
    
    @Column(name = "NR_TELEFONE", length = 11, nullable = false)
    private String telefone;
    
    @Column(name = "DC_EMPRESA", length = 200, nullable = false)
    private String empresa;
    
    @Column(name = "DC_TEXTO", length = 2000, nullable = false)
    private String texto;

    @Column(name = "DC_PROTOCOLO_SERVICO", length = 30, nullable = false)
    private String protocoloServico;
    
    @Column(name = "DT_CADASTRO", nullable = false)
    private Date dataCadastro;
    
    @Column(name = "DC_PROTOCOLO_ATENDIMENTO", length = 30, nullable = false)
    private String protocolo;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Integer getComentario() {
		return comentario;
	}

	public void setComentario(Integer comentario) {
		this.comentario = comentario;
	}

	public Integer getAssunto() {
		return assunto;
	}

	public void setAssunto(Integer assunto) {
		this.assunto = assunto;
	}

	public Integer getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(Integer tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public Long getRgi() {
		return rgi;
	}

	public void setRgi(Long rgi) {
		this.rgi = rgi;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public String getProtocoloServico() {
		return protocoloServico;
	}

	public void setProtocoloServico(String protocoloServico) {
		this.protocoloServico = protocoloServico;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(String protocolo) {
        this.protocolo = protocolo;
    }
    
	public String getRgrne() {
		return rgrne;
	}

	public void setRgrne(String rgrne) {
		this.rgrne = rgrne;
	}

	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FaleConosco other = (FaleConosco) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

}
