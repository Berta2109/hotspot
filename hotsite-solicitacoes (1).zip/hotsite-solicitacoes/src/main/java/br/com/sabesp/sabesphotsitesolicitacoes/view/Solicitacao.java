package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;
import java.util.Date;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.*;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

public class Solicitacao implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -6196683353922751664L;

	private DadosRGI dados;

	private TipoServico tipoServico;
	private Solicitante solicitante;
	private String ip;
	private Date dataCadastro;
	private DadosLeitura dadosLeitura;
	private Atestado atestado;
	private Beneficio beneficio;
	private SupressaoReligacao supressao;
	private CadastroUnidadeConsumo cadastroUnidadeConsumo;
	private String observacoes;
	private String protocolo;
	private TarifaSocialUnifamiliar tarifaSocialUnifamiliar;
	private TarifaSocialDesempregado tarifaSocialDesempregado;
	private ChecagemAvisosDocumentacao checagemAvisosDocumentacao;
	private ServicoSolicitacao servicoSolicitacao;
	private String fornecimento;
	
	private String responsavelConta;
	
	private Boolean estatalFederal;
    private Anexo documentoEstatalFederal;
	
	public String getResponsavelConta() {
		return responsavelConta;
	}

	public void setResponsavelConta(String responsavelConta) {
		this.responsavelConta = responsavelConta;
	}

	public Solicitacao() {
		dataCadastro = new Date();
	}

	public SupressaoReligacao getSupressao() {
		return supressao;
	}

	public void setSupressao(SupressaoReligacao supressao) {
		this.supressao = supressao;
	}

	public Beneficio getBeneficio() {
		return beneficio;
	}

	public void setBeneficio(Beneficio beneficio) {
		this.beneficio = beneficio;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	public Atestado getAtestado() {
		return atestado;
	}

	public void setAtestado(Atestado atestado) {
		this.atestado = atestado;
	}

	public DadosLeitura getDadosLeitura() {
		return dadosLeitura;
	}

	public void setDadosLeitura(DadosLeitura dadosLeitura) {
		this.dadosLeitura = dadosLeitura;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public TipoServico getTipoServico() {
		return tipoServico;
	}

	public void setTipoServico(TipoServico tipoServico) {
		this.tipoServico = tipoServico;
	}

	public Solicitante getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(Solicitante solicitante) {
		this.solicitante = solicitante;
	}

	public DadosRGI getDados() {
		return dados;
	}

	public void setDados(DadosRGI dados) {
		this.dados = dados;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public CadastroUnidadeConsumo getCadastroUnidadeConsumo() {
		return cadastroUnidadeConsumo;
	}

	public void setCadastroUnidadeConsumo(CadastroUnidadeConsumo cadastroUnidadeConsumo) {
		this.cadastroUnidadeConsumo = cadastroUnidadeConsumo;
	}

	public TarifaSocialUnifamiliar getTarifaSocialUnifamiliar() {
		return tarifaSocialUnifamiliar;
	}

	public void setTarifaSocialUnifamiliar(TarifaSocialUnifamiliar tarifaSocialUnifamiliar) {
		this.tarifaSocialUnifamiliar = tarifaSocialUnifamiliar;
	}

	public TarifaSocialDesempregado getTarifaSocialDesempregado() {
		return tarifaSocialDesempregado;
	}

	public void setTarifaSocialDesempregado(TarifaSocialDesempregado tarifaSocialDesempregado) {
		this.tarifaSocialDesempregado = tarifaSocialDesempregado;
	}

	public ChecagemAvisosDocumentacao getChecagemAvisosDocumentacao() {
		return checagemAvisosDocumentacao;
	}

	public void setChecagemAvisosDocumentacao(ChecagemAvisosDocumentacao checagemAvisosDocumentacao) {
		this.checagemAvisosDocumentacao = checagemAvisosDocumentacao;
	}

	public ServicoSolicitacao getServicoSolicitacao() {
		return servicoSolicitacao;
	}

	public void setServicoSolicitacao(ServicoSolicitacao servicoSolicitacao) {
		this.servicoSolicitacao = servicoSolicitacao;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getFornecimento() {
		return fornecimento;
	}

	public void setFornecimento(String fornecimento) {
		this.fornecimento = fornecimento;
	}


	public Boolean getEstatalFederal() {
		return estatalFederal;
	}

	public void setEstatalFederal(Boolean estatalFederal) {
		this.estatalFederal = estatalFederal;
	}


	public Anexo getDocumentoEstatalFederal() {
		return documentoEstatalFederal;
	}

	public void setDocumentoEstatalFederal(Anexo documentoEstatalFederal) {
		this.documentoEstatalFederal = documentoEstatalFederal;
	}
	
}
