package br.com.sabesp.sabesphotsitesolicitacoes.business;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

import br.com.sabesp.sabesphotsitesolicitacoes.entity.Fornecimento;
import br.com.sabesp.sabesphotsitesolicitacoes.util.GenericRepository;
import br.com.sabesp.sabesphotsitesolicitacoes.view.CidadeDTO;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.autenticador.Webwsto;
import br.com.sabesp.sabesphotsitesolicitacoes.ws.rgi.DadosRGI;

@Stateless
public class RgiBusiness {

	@EJB
	private IntegracaoWsBusiness wsBusiness;

	@EJB
	private GenericRepository repository;

	/**
	 * Metodo responsavel por obter os detalhes sobre o RGI, verificando na base
	 * de dados e no ws
	 *
	 * @since 11 de abr de 2020 (Projeto)
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @param autenticacao
	 * @param rgi
	 * @return
	 */
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public DadosRGI consultar(Webwsto autenticacao, String rgi) {
		DadosRGI detalhes = integrarBaseExistente(rgi);
		if (detalhes == null) {
			return null;
		}
		return detalhes;
	}


	/**
	 * Metodo responsavel por obter os detalhes do rgi na base
	 *
	 * @since 11 de abr de 2020 (Projeto)
	 * @author Renan Oliveira (renan.oliveira@castgroup.com.br)
	 * @param rgi
	 * @return
	 */
	private DadosRGI integrarBaseExistente(String rgi) {
		if(rgi.length()<10) {
			rgi = String.format("%010d", Integer.parseInt(rgi));
		}

//		SQL DEV
//		String sql = "select cod_pde, cod_municipio from dadosrgi a where a.cod_pde= ?1";
		
//		SQL PROD
		String sql = "SELECT A.COD_PDE, C.COD_MUNICIPIO, C.COD_ATC "
				+ "FROM ORA_VIARIO.S_PDE@BDI A "
				+ "INNER JOIN ORA_VIARIO.S_QUADRA@BDI C ON A.COD_SABESP_QUADRA=C.COD_QUADRA "
				+ "AND A.COD_SABESP_CIDADE=C.COD_MUNICIPIO "
				+ "AND A.COD_SABESP_SETOR=C.COD_SETOR_FISCAL "
				+ "AND COD_SABESP_ROTA=C.COD_ROTA "
				+ "WHERE A.COD_PDE = ?1 ";

		Query query = repository.getEntityManager().createNativeQuery(sql);
		query.setParameter(1, rgi);

		@SuppressWarnings("unchecked")
		List<Object[]> retorno = query.getResultList();
		if (retorno.isEmpty()) {
			return null;
		}

		
		//prod mudar para [ 2 ] e dev [ 1 ]
		for (Object[] objects : retorno) {
			DadosRGI dados = new DadosRGI(rgi);
				if(objects[2] instanceof String) {
					String codigoATCString = (String) objects[2];
					dados.setAtendimentoComercialATC(Integer.valueOf(codigoATCString));
				}else if(objects[2] instanceof Integer) {
					Integer codigoATCInteger = (Integer) objects[2];
					dados.setAtendimentoComercialATC(codigoATCInteger);
				}else if(objects[2] instanceof Number) {
					Number codigoATCNumber = (Number) objects[2];
					dados.setAtendimentoComercialATC(codigoATCNumber.intValue());
				}else if(objects[2] instanceof BigDecimal) {
					BigDecimal codigoATCNumber = (BigDecimal) objects[2];
					dados.setAtendimentoComercialATC(codigoATCNumber.intValue());
				}else if(objects[2] instanceof BigInteger) {
					BigInteger codigoATCNumber = (BigInteger) objects[2];
					dados.setAtendimentoComercialATC(codigoATCNumber.intValue());
				}
			return dados;
		}

		return null;
	}
	
	//buscar fornecimento
	public Fornecimento buscarDadosFornecimento(String numero) {

		Fornecimento fornecimento = new Fornecimento();
		
		try {
			
			String sql = "SELECT " + 
					"	A.COD_PDE, " + 
					"	A.COD_FORNECIMENTO, " + 
					"	C.COD_MUNICIPIO, " + 
					"	C.COD_ATC " + 
					"FROM " + 
					"	ORA_VIARIO.S_PDE@BDI A " + 
					"INNER JOIN ORA_VIARIO.S_QUADRA@BDI C ON " + 
					"	A.COD_SABESP_QUADRA = C.COD_QUADRA " + 
					"	AND A.COD_SABESP_CIDADE = C.COD_MUNICIPIO " + 
					"	AND A.COD_SABESP_SETOR = C.COD_SETOR_FISCAL " + 
					"	AND A.COD_SABESP_ROTA = C.COD_ROTA " + 
					"WHERE " + 
					"	A.COD_FORNECIMENTO = ?1 ";
			
			Query query = repository.getEntityManager().createNativeQuery(sql);
			
			query.setParameter(1, numero);
			
			@SuppressWarnings("unchecked")
			List<Object[]> retorno = query.getResultList();
			if (retorno.isEmpty()) {
				return fornecimento;
			}

			for (Object[] objects : retorno) {
				
				fornecimento.setPde(String.valueOf(objects[0]));
				fornecimento.setFornecimento(String.valueOf(objects[1]));
				fornecimento.setCodMunicipio(String.valueOf(objects[2]));
				fornecimento.setCodAtc(String.valueOf(objects[3]));
				
				return fornecimento;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fornecimento;
	}
}
