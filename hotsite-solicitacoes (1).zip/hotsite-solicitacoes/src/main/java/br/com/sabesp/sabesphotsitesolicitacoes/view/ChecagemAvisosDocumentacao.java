package br.com.sabesp.sabesphotsitesolicitacoes.view;

import java.io.Serializable;

public class ChecagemAvisosDocumentacao implements Serializable{

	private static final long serialVersionUID = -8572242826061194459L;
	
	private Boolean check;
	private Boolean check1;
    private Boolean check2;
    private Boolean check3;
    private Boolean check4;
    
	public Boolean getCheck() {
		return check;
	}
	public void setCheck(Boolean check) {
		this.check = check;
	}
	public Boolean getCheck1() {
		return check1;
	}
	public void setCheck1(Boolean check1) {
		this.check1 = check1;
	}
	public Boolean getCheck2() {
		return check2;
	}
	public void setCheck2(Boolean check2) {
		this.check2 = check2;
	}
	public Boolean getCheck3() {
		return check3;
	}
	public void setCheck3(Boolean check3) {
		this.check3 = check3;
	}
	public Boolean getCheck4() {
		return check4;
	}
	public void setCheck4(Boolean check4) {
		this.check4 = check4;
	}
}
