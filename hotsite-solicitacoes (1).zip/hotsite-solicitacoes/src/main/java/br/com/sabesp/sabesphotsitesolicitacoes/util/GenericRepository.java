package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.primefaces.model.SortOrder;

public interface GenericRepository {

	EntityManager getEntityManager();

	void setEntityManager(EntityManager entityManager);

	<T> T insert(T object);

	<T> T update(T object);

	<T> void remove(T object);

	<T> T findById(Class<T> clazz, Object pk);

	<T> Collection<T> list(Class<T> clazz);

	<T> Collection<T> search(Class<T> clazz, String hql, Object... params);

	<T> Collection<T> searchWithLimit(Class<T> clazz, String hql, Integer start, Integer limit, Object... params);

	<T> T searchUniqueResult(Class<T> clazz, String hql, Object... params);

	Number count(String fieldCount, String hqlAfterCount, Object... params);

	void addOrdenacao(CriteriaBuilder builder, CriteriaQuery<?> query, Root<?> root, SortOrder sortOrder, String atributoAOrdenar);

}