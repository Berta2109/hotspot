package br.com.sabesp.sabesphotsitesolicitacoes.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SUPRESSAO_RELIGACAO_IMOVEL")
public class SupressaoReligacao implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8386020973721677055L;

	@Id
	@OneToOne
	@JoinColumn(name = "CD_SOLICITACAO_SERVICO")
	private SolicitacaoServico solicitacao;

	@ManyToOne
	@JoinColumn(name = "CD_SUPRESSAO_RELIGACAO_IMOV")
	private TipoSupressaoReligacao tipo;

	public TipoSupressaoReligacao getTipo() {
		return tipo;
	}

	public void setTipo(TipoSupressaoReligacao tipo) {
		this.tipo = tipo;
	}

	public SolicitacaoServico getSolicitacao() {
		return solicitacao;
	}

	public void setSolicitacao(SolicitacaoServico solicitacao) {
		this.solicitacao = solicitacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((solicitacao == null) ? 0 : solicitacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SupressaoReligacao)) {
			return false;
		}
		SupressaoReligacao other = (SupressaoReligacao) obj;
		if (solicitacao == null) {
			if (other.solicitacao != null) {
				return false;
			}
		} else if (!solicitacao.equals(other.solicitacao)) {
			return false;
		}
		return true;
	}

}
