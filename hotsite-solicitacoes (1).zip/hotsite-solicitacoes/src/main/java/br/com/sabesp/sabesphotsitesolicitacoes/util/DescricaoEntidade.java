package br.com.sabesp.sabesphotsitesolicitacoes.util;

import java.io.Serializable;

public interface DescricaoEntidade extends Serializable {

	String getDescricao();

}
