package br.com.sabesp.sabesphotsitesolicitacoes.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import br.com.sabesp.sabesphotsitesolicitacoes.util.BrasilUtils;
import br.com.sabesp.sabesphotsitesolicitacoes.util.Feedback;
import br.com.sabesp.sabesphotsitesolicitacoes.util.TreatString;

@FacesValidator("cpfValidator")
public class CpfValidator implements Validator {

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		if (TreatString.isBlank(TreatString.filterOnlyNumber(value))) {
			return;
		}

		if (!BrasilUtils.isCPFValid(value.toString())) {
			throw new ValidatorException(
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							Feedback.getMsg("custom.validator.cpfValidator", value.toString()), null));
		}
	}

}