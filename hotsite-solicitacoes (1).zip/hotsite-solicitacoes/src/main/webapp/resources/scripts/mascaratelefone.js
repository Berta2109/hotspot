/*
 * Mascara telefone com 8 ou 9 digitos
 *
 * Adiconar class telefone ao INPUTTEXT
 *
 * Adicionar import ao xhtml
 *    <script type="text/javascript" src="#{request.contextPath}/resources/scripts/mascaratelefone.js"></script>
 *
 *
 */
jQuery(document).ready(function() {
	habilitarMascarasCustomizadas();
});

function habilitarMascarasCustomizadas() {
	try{
		habilitarMascaraMoeda();
	}catch(e) {
		console.log('falha habilitarMascaraMoeda', e);
	}
	try{
		habilitarMascaraTelefone();
	}catch(e) {
		console.log('falha habilitarMascaraTelefone', e);
	}
}

function habilitarMascaraTelefone() {
	jQuery('input[class*="telefone"]').mask("(99) 9999-9999?9");
	jQuery('input[class*="telefone"]').focusout(function(){
	    var phone, element;
	    element = jQuery(this);
	    element.unmask();
	    phone = element.val().replace(/\D/g, '');
	    if(phone.length > 10) {
	        element.mask("(99) 99999-999?9");
	    } else {
	        element.mask("(99) 9999-9999?9");
	    }
	}).trigger('focusout');
}

function mascarar(){
	jQuery('input[class*="telefone"]').mask("(99) 9999-9999?9");
}

function habilitarMascaraCpfCnpj() {

	var masksCpfCnpj = ['999.999.999-99?999', '99.999.999/9999-99'];
	jQuery('.cpfCnpj').mask(masksCpfCnpj[0]);

	jQuery('.cpfCnpj').focusout(function(){
	    var phone, element;
	    element = jQuery(this);
	    element.unmask();
	    phone = element.val().replace(/\D/g, '');
	    if(phone.length <= 11) {
	    	element.mask(masksCpfCnpj[0]);
	    } else {
	    	element.mask(masksCpfCnpj[1]);
	    }
	}).trigger('focusout');
}

function habilitarMascaraMoeda() {
	jQuery('.moeda').maskMoney({thousands:'.', decimal:',', allowZero:true });
	jQuery('.decimal4casas').maskMoney({ thousands:'.', decimal:',', allowZero:true, precision :4});
}